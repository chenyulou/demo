<?php 
define('NOTIFY_HTPAY','epay');
$C_Patch=$_SERVER['DOCUMENT_ROOT'];

require_once($C_Patch."/includes/common.php");

define('NOTIFY_TYPE','enotify');
//商户订单号
$out_trade_no = $_GET['out_trade_no'];
//支付宝交易号
$trade_no = $_GET['trade_no'];
//交易状态
$trade_status = $_GET['trade_status'];

$srow=$DB->query("SELECT * FROM pay_order WHERE trade_no='{$out_trade_no}' limit 1")->fetch();


require_once(SYSTEM_ROOT."pay/epay/epay.config.php");

require_once(SYSTEM_ROOT."pay/epay/epay_notify.class.php");

//¼ÆËãµÃ³öÍ¨ÖªÑéÖ¤½á¹û
$alipayNotify = new AlipayNotify($alipay_config);
$verify_result = $alipayNotify->verifyNotify();

if($verify_result) {//ÑéÖ¤³É¹¦

	//½»Ò××´Ì¬
    if ($_GET['trade_status'] == 'TRADE_SUCCESS') {
		//¸¶¿îÍê³Éºó£¬Ö§¸¶±¦ÏµÍ³·¢ËÍ¸Ã½»Ò××´Ì¬Í¨Öª
		
		if($srow['status']==0){
			if($DB->exec("update `pay_order` set `status` ='1' where `trade_no`='$out_trade_no'")){
				$DB->exec("update `pay_order` set `endtime` ='$date' where `trade_no`='$out_trade_no'");
				processOrder($srow);
			}
		}
    }

	echo "success";
}
else {
    //ÑéÖ¤Ê§°Ü
    echo "fail";
}


?>
