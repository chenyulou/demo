<?php 
define('NOTIFY_HTPAY','wft');
$C_Patch=$_SERVER['DOCUMENT_ROOT'];
define('NOTIFY_TYPE','wftnotify');
require_once($C_Patch."/includes/common.php");
require(SYSTEM_ROOT.'pay/swiftpass/class/Utils.class.php');
require(SYSTEM_ROOT.'pay/swiftpass/config.php');
require(SYSTEM_ROOT.'pay/swiftpass/class/RequestHandler.class.php');
require(SYSTEM_ROOT.'pay/swiftpass/class/ClientResponseHandler.class.php');
require(SYSTEM_ROOT.'pay/swiftpass/class/PayHttpClient.class.php');

$resHandler = new ClientResponseHandler();
$reqHandler = new RequestHandler();
$pay = new PayHttpClient();
$cfg = new Config();

$reqHandler->setKey($cfg->C('key'));

$xml = file_get_contents('php://input');
		
$resHandler->setContent($xml);

$resHandler->setKey($cfg->C('key'));
if($resHandler->isTenpaySign()){
	
	if($resHandler->getParameter('status') == 0 && $resHandler->getParameter('result_code') == 0){
		$out_trade_no = $resHandler->getParameter('out_trade_no');
		$total_fee = $resHandler->getParameter('total_fee');
		$fee_type = $resHandler->getParameter('fee_type');
		$srow=$DB->query("SELECT * FROM pay_order WHERE trade_no='{$out_trade_no}' limit 1 for update")->fetch();
		if($srow['status']==0){
			if($DB->exec("update `pay_order` set `status` ='1' where `trade_no`='$out_trade_no'")){
				$DB->exec("update `pay_order` set `endtime` ='$date' where `trade_no`='$out_trade_no'");
				processOrder($srow);
			}
		}

		//Utils::dataRecodes('�ӿڻص��յ�֪ͨ����',$resHandler->getAllParameters());
		echo 'success';
		exit();
	}else{
		echo 'failure1';
		exit();
	}
}else{
	echo 'failure2';
}
?>