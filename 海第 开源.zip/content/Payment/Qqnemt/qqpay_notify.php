<?php

//---------------------------------------------------------
//财付通即时到帐支付后台回调示例，商户按照此文档进行开发即可
//---------------------------------------------------------
define('NOTIFY_HTPAY','qq');
$C_Patch=$_SERVER['DOCUMENT_ROOT'];
require_once($C_Patch."/includes/common.php");

define('NOTIFY_TYPE','qqnotify');
$request = file_get_contents("php://input");
$objectxml = simplexml_load_string($request, 'SimpleXMLElement', LIBXML_NOCDATA);//将文件转换成 对象
$xmljson= json_encode($objectxml);//将对象转换个JSON
$row=json_decode($xmljson,true);//将json转换成数组
$srow=$DB->query("SELECT * FROM pay_order WHERE trade_no='{$row['out_trade_no']}' limit 1")->fetch();
// file_put_contents('logpay.txt',"call back:" . $srow['type_id']);
require_once(SYSTEM_ROOT.'pay/qqpay/qpayNotify.class.php');
@header('Content-Type: text/html; charset=UTF-8');

$qpayNotify = new QpayNotify();
$result = $qpayNotify->getParams();

//判断签名
if($qpayNotify->verifySign()) {

//判断签名及结果（即时到帐）
	if($result['trade_state'] == "SUCCESS") {
		//商户订单号
		$out_trade_no = $result['out_trade_no'];
		//QQ钱包订单号
		$transaction_id = $result['transaction_id'];
		//金额,以分为单位
		$total_fee = $result['total_fee'];
		//币种
		$fee_type = $result['fee_type'];
		//用户表示
		$openid = $result['openid'];

		//------------------------------
		//处理业务开始
		//------------------------------
		$srow=$DB->query("SELECT * FROM pay_order WHERE trade_no='{$out_trade_no}' limit 1")->fetch();
		if($srow['status']==0){
		if($DB->exec("update `pay_order` set `status` ='1' where `trade_no`='$out_trade_no'")){
			$DB->exec("update `pay_order` set `endtime` ='$date',`buyer` ='$openid' where `trade_no`='$out_trade_no'");
			processOrder($srow);
		}
		}
		//------------------------------
		//处理业务完毕
		//------------------------------
		echo "<xml>
<return_code>SUCCESS</return_code>
</xml>";
	} else {
		echo "<xml>
<return_code>FAIL</return_code>
</xml>";
	}

} else {
	//回调签名错误
	echo "<xml>
<return_code>FAIL</return_code>
<return_msg>签名失败</return_msg>
</xml>";
} 

?>