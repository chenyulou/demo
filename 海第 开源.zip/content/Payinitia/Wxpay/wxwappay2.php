<?php
$is_defend=true;
$C_Patch=$_SERVER['DOCUMENT_ROOT'];
require_once($C_Patch."/includes/common.php");

@header('Content-Type: text/html; charset=UTF-8');

$trade_no=daddslashes($_GET['trade_no']);
$sitename=base64_decode(daddslashes($_GET['sitename']));
$row=$DB->query("SELECT * FROM pay_order WHERE trade_no='{$trade_no}' limit 1")->fetch();
if(!$row)sysmsg('该订单号不存在，请返回来源地重新发起请求！');

if(isset($_GET['type']))$DB->query("update `pay_order` set `type` ='wxpay',`addtime` ='$date' where `trade_no`='$trade_no'");
$donlx=1;
$name = 'onlinepay-'.time();
require_once SYSTEM_ROOT."pay/wxpay/WxPay.Api.php";
require_once SYSTEM_ROOT."pay/wxpay/WxPay.NativePay.php";

$id=MCHS_W_ID;

$DB->exec("update `pay_order` set `type_id` ='{$id}' where `trade_no`='$trade_no'");

$notify = new NativePay();
$input = new WxPayUnifiedOrder();
$input->SetBody($name);
$input->SetOut_trade_no($trade_no);
$input->SetTotal_fee($row['money']*100);
$input->SetSpbill_create_ip($clientip);
$input->SetTime_start(date("YmdHis"));
$input->SetTime_expire(date("YmdHis", time() + 600));
$input->SetNotify_url($payurl.'content/Payment/Wxnemt/wxpay_notify.php');
$input->SetTrade_type("MWEB");
$result = $notify->GetPayUrl($input);
if($result["result_code"]=='SUCCESS'){
	$redirect_url=$payurl.'content/Payment/Wxnemt/wxwap_return.php?trade_no='.$trade_no.'&identifi=w';
	$url=$result['mweb_url'].'&redirect_url='.urlencode($redirect_url);
	exit("<script>window.location.replace('{$url}');</script>");
}elseif(isset($result["err_code"])){
	sysmsg('微信支付下单失败！['.$result["err_code"].'] '.$result["err_code_des"]);
}else{
	echo $id;
	sysmsg('微信支付下单失败！['.$result["return_code"].'] '.$result["return_msg"]);
}

?>