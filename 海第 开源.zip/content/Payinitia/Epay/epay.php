<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>正在为您跳转到支付页面，请稍候...</title>
</head>
<body>
<?php
$C_Patch=$_SERVER['DOCUMENT_ROOT'];
require_once($C_Patch."/includes/common.php");
@header('Content-Type: text/html; charset=UTF-8');
$donlx=daddslashes($_GET['donlx']);
$type=daddslashes($_GET['type']);
$trade_no=daddslashes($_GET['trade_no']);
$sitename=base64_decode(daddslashes($_GET['sitename']));

$srow=$DB->query("SELECT * FROM pay_order WHERE trade_no='{$trade_no}' limit 1 for update")->fetch();

require_once(SYSTEM_ROOT."pay/epay/epay.config.php");
require_once(SYSTEM_ROOT."pay/epay/epay_submit.class.php");
$Interfaceid=MCHS_EID;//获取接口·id

$DB->exec("update `pay_order` set `type_id` ='{$Interfaceid}' where `trade_no`='$trade_no'");
$parameter = array(
	"pid" => trim($alipay_config['partner']),
	"type" => $type,
	"notify_url"	=> $payurl.'content/Payment/Enemt/epay_notify.php',
	"return_url"	=> $payurl.'content/Payment/Enemt/epay_return.php',
	"out_trade_no"	=> $trade_no,
	"name"	=> $srow['name'],
	"money"	=> $srow['money']
);
//建立请求
$alipaySubmit = new AlipaySubmit($alipay_config);
$html_text = $alipaySubmit->buildRequestForm($parameter);
echo $html_text;

?>
<p>正在为您跳转到支付页面，请稍候...</p>
</body>
</html>