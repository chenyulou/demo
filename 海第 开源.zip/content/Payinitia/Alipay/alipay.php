<?php
$C_Patch=$_SERVER['DOCUMENT_ROOT'];
require_once($C_Patch."/includes/common.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="Content-Language" content="zh-cn">
<meta name="renderer" content="webkit">
<title>支付宝支付 - <?php echo $conf['web_name'];?></title>
</head>
<body>
 <?php
 
require_once(SYSTEM_ROOT."pay/alipay/alipay.config.php");
require_once(SYSTEM_ROOT."pay/alipay/alipay_submit.class.php");

@header('Content-Type: text/html; charset=UTF-8');

$trade_no=daddslashes($_GET['trade_no']);
$sitename=base64_decode(daddslashes($_GET['sitename']));
$row=$DB->query("SELECT * FROM pay_order WHERE trade_no='{$trade_no}' limit 1")->fetch();
if(!$row)sysmsg('该订单号不存在，请返回来源地重新发起请求！');
 $id=MCHS_A_ID;
 $DB->exec("update `pay_order` set `type_id`='{$id}' where `trade_no`='{$trade_no}'");


	//构造要请求的参数数组，无需改动
	
	if(checkmobile()==true){
		//	$alipay_service = "create_direct_pay_by_user";//为了解决支付时无法换醒App时用户可在页面进行操作支付
		$alipay_service = "alipay.wap.create.direct.pay.by.user";//wap，如果你想用App支付页请将此代码开了，把上面的注释
	}else{
		$alipay_service = "create_direct_pay_by_user";//pc
	}
	$name = 'onlinepay-'.time();
	$parameter = array(
		"service" => $alipay_service,//支付页面方式
		"partner" => trim($alipay_config['partner']), //合作身份者id
		"seller_id" => trim($alipay_config['partner']), //收款支付宝用户号
		"payment_type"	=> "1", //支付方式
		"notify_url"	=> $payurl.'content/Payment/Alinemt/alipay_notify.php', //服务器异步通知页面路径
		"return_url"	=> $payurl.'content/Payment/Alinemt/alipay_return.php', //页面跳转同步通知页面路径
		"out_trade_no"	=> $trade_no, //商户订单号
		"subject"	=> $row['name'], //订单名称
		"total_fee"	=> $row['money'], //付款金额
		"_input_charset"	=> strtolower('utf-8')
	);
	
	if(checkmobile()==true){
		$parameter['app_pay'] = "Y";
	}

	//建立请求
	$alipaySubmit = new AlipaySubmit($alipay_config);
	$html_text = $alipaySubmit->buildRequestForm($parameter,"get", "正在跳转");
	echo $html_text;
	?>
	</body>
	</html>