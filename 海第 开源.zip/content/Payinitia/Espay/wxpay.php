<?php
$C_Patch=$_SERVER['DOCUMENT_ROOT'];
require_once($C_Patch."/includes/common.php");
@header('Content-Type: text/html; charset=UTF-8');

$trade_no=daddslashes($_GET['trade_no']);

$sitename=base64_decode(daddslashes($_GET['sitename']));

$row=$DB->query("SELECT * FROM pay_order WHERE trade_no='{$trade_no}' limit 1")->fetch();

if(!$row)sysmsg('该订单号不存在，请返回来源地重新发起请求！');

if(isset($_GET['type']))$DB->query("update `pay_order` set `type` ='wxpay',`addtime` ='$date' where `trade_no`='$trade_no'");


require(SYSTEM_ROOT.'pay/espay/Signer.php');

require(SYSTEM_ROOT.'pay/espay/Eshanghu.php');

$pay_config = require(SYSTEM_ROOT.'pay/espay/config.php');

$Interfaceid=MCHS_XW_ID;//获取接口·id

$DB->exec("update `pay_order` set `type_id` ='{$Interfaceid}' where `trade_no`='$trade_no'");

$name = 'onlinepay-'.time();

$pay = new Eshanghu($pay_config);

$result = $pay->create($trade_no, $name, $row['money']*100);

if($result['code'] == "200"){
	$code_url = $result['data']['code_url'];
}else{
	sysmsg('微信支付下单失败 '.$result['message']);
}

?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="Content-Language" content="zh-cn">
<meta name="renderer" content="webkit">
<title>微信安全支付 - <?php echo $sitename?></title>
<link href="/assets/css/wechat_pay.css" rel="stylesheet" media="screen">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="keywords" content="">
<meta name="description" content="">   
</head>
<title>微信支付收银台</title>
<style>
    *{margin:0;padding:0;}
    body{background: #f2f2f4;}
    .clearfix:after { content: "."; display: block; height: 0; clear: both; visibility: hidden; }
    .clearfix { display: inline-block; }
    * html .clearfix { height: 1%; }
    .clearfix { display: block; }
    .xh-title{height:75px;line-height:75px;text-align:center;font-size:30px;font-weight:300;border-bottom:2px solid #eee;background: #fff;}
    .qrbox{max-width: 900px;margin: 0 auto;padding:85px 20px 20px 50px;}
  
    .qrbox .left{width: 40%;float: left;display: block;margin: 0px auto;}
    .qrbox .left .qrcon{
        border-radius: 10px;
        background: #fff;
        overflow: visible;
        text-align: center;
        padding-top:25px;
        color: #555;
        box-shadow: 0 3px 3px 0 rgba(0, 0, 0, .05);
        vertical-align: top;
        -webkit-transition: all .2s linear;
        transition: all .2s linear;
    }
    .qrbox .left .qrcon .logo{width: 100%;}
    .qrbox .left .qrcon .title{font-size: 16px;margin: 10px auto;width: 100%;}
    .qrbox .left .qrcon .price{font-size: 22px;margin: 0px auto;width: 100%;}
    .qrbox .left .qrcon .bottom{border-radius: 0 0 10px 10px;width: 100%;background: #32343d;color: #f2f2f2;padding:15px 0px;text-align: center;font-size: 14px;}
    .qrbox .sys{width: 60%;float: right;text-align: center;padding-top:20px;font-size: 12px;color: #ccc}
    .qrbox img{max-width: 100%;}
    @media (max-width : 767px){
        .qrbox{padding:20px;}
        .qrbox .left{width: 90%;float: none;}   
        .qrbox .sys{display: none;}
    }
</style>
<body>
<div class="xh-title">微信支付收银台</div>
  <div class="qrbox clearfix">
  <div class="left" style="box-shadow: 0 0 60px #b5f1ff;">
         <div class="qrcon">
           <h5><img src="/assets/img/wechat-logo.png" alt="" style="height:40px;"></h5>
             <div class="title">商品名称：<?php echo $row['name']?></div>
             <div class="price">￥<?php echo $row['money']?></div>
           <br>
             <div align="center" style="position:relative;">
                <div class="qr-image" id="qrcode">
                   </div>
               <br>
<div class="detail" id="orderDetail">
<dl class="detail-ct" style="display: none;">
</dl>
<a href="javascript:void(0)" class="arrow"><i class="ico-arrow"></i></a>
</div>
<div class="tip">
<div class="tip-text">
</div>
</div>
<div class="tip-text">
</div>
</div>
<div class="bottom">
<div class="title">商户订单号：<?php echo $row['trade_no']?></div>
              请使用微信扫一扫<br>扫描二维码支付
                </div>
         </div>
  </div>                
<div class="sys"><img src="/assets/img/wechat-sys.png"alt=""></div>
</div>
<script src="/assets/js/qcloud_util.js"></script>
<script src="/assets/js/jquery-qrcode.min.js"></script>
<script src="/assets/layer/layer.js"></script>
<script>
    $('#qrcode').qrcode({
        text: "<?php echo $code_url?>",
        width: 230,
        height: 230,
        foreground: "#000000",
        background: "#ffffff",
        typeNumber: -1
    });
    // 订单详情
    $('#orderDetail .arrow').click(function (event) {
        if ($('#orderDetail').hasClass('detail-open')) {
            $('#orderDetail .detail-ct').slideUp(500, function () {
                $('#orderDetail').removeClass('detail-open');
            });
        } else {
            $('#orderDetail .detail-ct').slideDown(500, function () {
                $('#orderDetail').addClass('detail-open');
            });
        }
    });
    // 检查是否支付完成
    function loadmsg() {
        $.ajax({
            type: "GET",
            dataType: "json",
            url: "../../Payment/getshop.php",
            timeout: 10000, //ajax请求超时时间10s
            data: {type: "wxpay", trade_no: "<?php echo $row['trade_no']?>"}, //post数据
            success: function (data, textStatus) {
                //从服务器得到数据，显示数据并继续查询
                if (data.code == 1) {
					layer.msg('支付成功，正在跳转中...', {icon: 16,shade: 0.01,time: 15000});
					setTimeout(window.location.href=data.backurl, 1000);
                }else{
                    setTimeout("loadmsg()", 4000);
                }
            },
            //Ajax请求超时，继续查询
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                if (textStatus == "timeout") {
                    setTimeout("loadmsg()", 1000);
                } else { //异常
                    setTimeout("loadmsg()", 4000);
                }
            }
        });
    }
    window.onload = loadmsg();
</script>
</body>
</html>