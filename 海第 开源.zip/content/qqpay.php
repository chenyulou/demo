<?php

if (isset($_GET['pid'])) {

	$pid = $_GET['pid'];

}

$qqall=$DB->query("SELECT count(*) from pay_jie where api_name='qqpay' and status=1")->fetchColumn();

$qq=$DB->query("SELECT * FROM pay_jie where api_name='qqpay' and status=1  order by id desc limit {$qqall}")->fetchAll();

if(!$qq)sysmsg('很抱歉！QQ通道暂时无法使用，可能在维护过程中<br>请<a href="./content/default.php?pid='.$pid.'&trade_no='.$trade_no.'">点击此处更换其他支付方式进行支付</a>');
#获取一个随机数
$qqall=unique_rand($qqall-1);
#通过随机数选择接口
$rows=$qq[$qqall];

// echo "<pre>";

// var_dump($rows['api_type']);exit();
#判断接口
 if ($rows['api_type']=='qqpay') {

	if(checkmobile()==true){//判断是否是手机端

		echo "<script>window.location.href='./content/Payinitia/Qqpay/qqwappay.php?trade_no={$trade_no}&type=qqpay&identifi=q&sitename={$sitename}';</script>";//qqwap
	}else{

		echo "<script>window.location.href='./content/Payinitia/Qqpay/qqpay.php?trade_no={$trade_no}&type=qqpay&identifi=q&sitename={$sitename}';</script>";//QQ
	}
  }else if ($rows['api_type']=='epay') {

  	echo "<script>window.location.href='./content/Payinitia/Epay/epay.php?trade_no={$trade_no}&type=qqpay&identifi=e&sitename={$sitename}';</script>";//易支付

  }else{

  	sysmsg('暂时不能用QQ支付方式！<br>请<a href="./content/default.php?pid='.$pid.'&trade_no='.$trade_no.'">点击此处更换其他支付方式进行支付</a>');

  }
?>