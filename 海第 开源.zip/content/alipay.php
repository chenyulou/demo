<?php
//支付宝支付跳转
if (isset($_GET['pid'])) {

	$pid = $_GET['pid'];

}

$aliall=$DB->query("SELECT count(*) from pay_jie where api_name='alipay' and status=1")->fetchColumn();

$ali=$DB->query("SELECT * FROM pay_jie where api_name='alipay' and status=1  order by id desc limit {$aliall}")->fetchAll();

if(!$ali)sysmsg('很抱歉！支付宝通道暂时无法使用，可能在维护过程中<br>请<a href="./content/default.php?pid='.$pid.'&trade_no='.$trade_no.'">点击此处更换其他支付方式进行支付</a>');

$aliall=unique_rand($aliall-1);

$rows=$ali[$aliall];

if ($rows['api_type']=='dmpay') {

	echo "<script>window.location.href='./content/Payinitia/Alipay/dmpay.php?trade_no={$trade_no}&identifi=d&sitename={$sitename}';</script>";//支付宝当面付

}

if ($rows['api_type']=='alipay') {

	echo "<script>window.location.href='./content/Payinitia/Alipay/alipay.php?trade_no={$trade_no}&identifi=a&sitename={$sitename}';</script>";//支付宝

}

if ($rows['api_type']=='epay') {

  	echo "<script>window.location.href='./content/Payinitia/Epay/epay.php?trade_no={$trade_no}&type=alipay&identifi=e&sitename={$sitename}';</script>";//易支付

  }else{

  	sysmsg('暂时不能用支付宝支付方式！<br>请<a href="./content/default.php?pid='.$pid.'&trade_no='.$trade_no.'">点击此处更换其他支付方式进行支付</a>');

 }
 
?>