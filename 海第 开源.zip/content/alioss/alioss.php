<?php



USE OSS\OssClient;
USE OSS\Core\OssException;
 
require "content/alioss/autoload.php";
 
class AliYunUpload
{
 
  var $KeyId;
  var $KeySecret;
  var $Endpoint;
  var $Bucket;

  function __construct($KeyId,$KeySecret,$Endpoint,$Bucket){
    $this->KeyId = $KeyId;
    $this->KeySecret = $KeySecret;
    $this->Endpoint = $Endpoint;
    $this->Bucket = $Bucket;
  }
    /**
     * 上传图片
     * @param $dst
     * @param $getFile
     * @return mixed
     */
    function upOss($dst, $getFile)
    {

      #配置OSS基本配置
// echo $this->KeyId.$this->KeySecret.$this->Endpoint.$this->Bucket;

      $ossClient = new OssClient(
        $this->KeyId, 
        $this->KeySecret, 
        $this->Endpoint);
      #执行阿里云上传
      $result = $ossClient->uploadFile(
        $this->Bucket, 
        $dst, 
        $getFile);
      #返回
      return $result;
    }


    function upFiles($file)
    {

        $getFile = $file['file']['tmp_name'];
        #上传文件后缀
        $ext = substr($file['file']['name'], strrpos($file['file']['name'], '.')
        + 1);
        #重命名文件上传名字
        $dst = 'MSQL/sql-'.date("Y-m-d H:i:s").'.' . $ext;
        #执行阿里云上传

        $url = $this->upOss($dst, $getFile);
        #根据显示返回信息
        $json = json_encode(array(
            'code' => 200,
            'data' => $url["info"]["url"],
            'error' => ''
        ));
        return $json;
    }

    function upLocalFiles($file)
    {
        $getFile = $file;
        #上传文件后缀
        $ext = pathinfo($file)["extension"];
        #重命名文件上传名字
        $dst = 'MSQL/';
        $file= 'sql-'.date("Y-m-d H:i:s").'.' . $ext;
        #执行阿里云上传

        $url = $this->upOss($dst.$file, $getFile);
        #根据显示返回信息
        $json = array(
            'code' => 200,
            'data' => $url["info"]["url"],
            'dst' => $dst,
            'error' => $file
        );
        return $json;
    }

}

?>
