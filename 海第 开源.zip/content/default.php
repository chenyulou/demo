<?php
$is_defend=true;
@header('Content-Type: text/html; charset=UTF-8');
if (isset($_GET['trade_no'])) {
	$pid = $_GET['pid'];
	$trade_no = $_GET['trade_no'];
	require '../includes/common.php';
}

$row=$DB->query("SELECT * FROM pay_order WHERE trade_no='{$trade_no}' limit 1")->fetch();
if(!$row)sysmsg('该订单号不存在，请返回来源地重新发起请求！');
if($row['status']==1)sysmsg('该订单号已支付，请返回来源地重新发起请求！');
?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="Content-Language" content="zh-cn">
<meta name="renderer" content="webkit">
<title>支付宝扫码支付 - <?php echo $sitename?></title>
<link href="/assets/css/wechat_pay.css" rel="stylesheet" media="screen">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="keywords" content="">
<meta name="description" content="">   
</head>
<title>支付宝收银台</title>
<style>
    *{margin:0;padding:0;}
    body{background: #f2f2f4;}
    .clearfix:after { content: "."; display: block; height: 0; clear: both; visibility: hidden; }
    .clearfix { display: inline-block; }
    * html .clearfix { height: 1%; }
    .clearfix { display: block; }
    .xh-title{height:75px;line-height:75px;text-align:center;font-size:30px;font-weight:300;border-bottom:2px solid #eee;background: #fff;}
    .qrbox{max-width: 900px;margin: 0 auto;padding:85px 20px 20px 50px;}
  
    .qrbox .left{width: 40%;display: block;margin: 0px auto;}
    .qrbox .left .qrcon{
        border-radius: 10px;
        background: #fff;
        overflow: visible;
        text-align: center;
        padding-top:25px;
        color: #555;
        box-shadow: 0 3px 3px 0 rgba(0, 0, 0, .05);
        vertical-align: top;
        -webkit-transition: all .2s linear;
        transition: all .2s linear;
    }
    .qrbox .left .qrcon .logo{width: 100%;}
    .qrbox .left .qrcon .title{font-size: 16px;margin: 10px auto;width: 100%;}
    .qrbox .left .qrcon .price{font-size: 22px;margin: 0px auto;width: 100%;}
    .qrbox .left .qrcon .bottom{border-radius: 0 0 10px 10px;width: 100%;background: #32343d;color: #f2f2f2;padding:15px 0px;text-align: center;font-size: 14px;}
    .qrbox .sys{width: 60%;float: right;text-align: center;padding-top:20px;font-size: 12px;color: #ccc}
    .qrbox img{max-width: 100%;}
    @media (max-width : 767px){
        .qrbox{padding:20px;}
        .qrbox .left{width: 90%;float: none;}   
        .qrbox .sys{display: none;}
    }
</style>
<body>
<div class="xh-title">海弟易支付 - 支付转换</div>
  <div class="qrbox clearfix">
  <div class="left" style="box-shadow: 0 0 60px #b5f1ff;">
         <div class="qrcon">
             <div class="title">商品名称：<?php echo $row['name']?></div>
             <div class="price">￥<?php echo $row['money']?></div><br>
           <hr>
             <div align="center" style="position:relative;">
                
           <h5 style="padding: 25px 20px 50px 25px;">
           	<a href="/submit.php?default=1&pid=<?php echo $pid?>&type=alipay&trade_no=<?php echo $trade_no?>">
	           	<img src="/assets/img/alipay-logo.png" alt="" style="height:30px;float: left;">
            </a>
            <a href="/submit.php?default=1&pid=<?php echo $pid?>&type=wxpay&trade_no=<?php echo $trade_no?>">
	            <img src="/assets/img/wechat-logo.png" alt="" style="height:30px;float: right;">
	        </a>
	        <a href="/submit.php?default=1&pid=<?php echo $pid?>&type=qqpay&trade_no=<?php echo $trade_no?>">
	            <img src="/assets/img/qqpay.jpg" alt="" style="height:30px;float: left;margin-top: 20px;">
	        </a>
	        <a href="/submit.php?default=1&pid=<?php echo $pid?>&type=qqpay&trade_no=<?php echo $trade_no?>">
	            <img src="/assets/img/tenpay.gif" alt="" style="height:30px;float: right;margin-top: 20px;margin-right: 15px;">
	        </a>
           </h5>
               <br>
<div class="detail" id="orderDetail">
<dl class="detail-ct" style="display: none;">
</dl>
<a href="javascript:void(0)" class="arrow"><i class="ico-arrow"></i></a>
</div>
<div class="tip">
<div class="tip-text">
</div>
</div>
<div class="tip-text">
</div>
</div>
<div class="foot">
<div class="inner">
</div>
</div>
<div class="bottom">
<div class="title">商户订单号：<?php echo $row['trade_no']?></div>
              请选择一种方式继续支付
</div>
<div class="tip">
<div class="tip-text">
</div>
</div>
<div class="tip-text">
</div>
</div>
</div>
</div>
<script src="/assets/js/qcloud_util.js"></script>
<script>
    // 订单详情
    $('#orderDetail .arrow').click(function (event) {
        if ($('#orderDetail').hasClass('detail-open')) {
            $('#orderDetail .detail-ct').slideUp(500, function () {
                $('#orderDetail').removeClass('detail-open');
            });
        } else {
            $('#orderDetail .detail-ct').slideDown(500, function () {
                $('#orderDetail').addClass('detail-open');
            });
        }
    });
</script>
</body>
</html>