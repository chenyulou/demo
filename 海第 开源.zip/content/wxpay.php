<?php


if (isset($_GET['pid'])) {

	$pid = $_GET['pid'];

}

#user （haidism）
#获取接口总数
$wxall = $DB->query("SELECT count(*) from pay_jie where api_name='wxpay' and status=1")->fetchColumn();

#获取H5总数
$wxappall = $DB->query("SELECT count(*) from pay_jie where api_name='wxpay' and status=1 and donlx=1")->fetchColumn();

$rows = $DB->query("SELECT * FROM pay_jie where api_name='wxpay' and status=1 and donlx<>1 order by id desc limit {$wxall}")->fetchAll();

$rowsh5 = $DB->query("SELECT * FROM pay_jie where api_name='wxpay' and status=1 and donlx=1 order by id desc limit {$wxappall}")->fetchAll();

#######################################################################################分界线
#扫码接口获取
#获取一个随机数
$wxall = unique_rand($wxall - 1);
#通过随机数选择接口
$rows = $rows[$wxall];
#######################################################################################分界线
#H5接口获取
#获取一个随机数
$wxallh5 = unique_rand($wxappall);
#通过随机数选择接口
$rowss = $rowsh5[$wxallh5 - 1];
############################################################################################

if (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false) {

#公众号支付
    if ($rows == false) {
        sysmsg('很抱歉！微信通道暂时无法使用，可能在维护过程中<br>请<a href="./content/default.php?pid=' . $pid . '&trade_no=' . $trade_no . '">点击此处更换其他支付方式进行支付</a>');
    }

    if ($rows['api_type'] == 'wxpay') {
        header('Location: ./content/Payinitia/Wxpay/wxjspay.php?trade_no=' . $trade_no . '&identifi=w');
    } else if ($rows['api_type'] == 'epay') {
        header('Location: ./content/Payinitia/Epay/epay.php?trade_no=' . $trade_no . '&type=wxpay&identifi=e');
    } else if ($rows['api_type'] == 'eshangpay') {
        header('Location: ./content/Payinitia/Espay/wxjspay.php?trade_no=' . $trade_no . '&identifi=x');
    } else if ($rows['api_type'] == 'wftpay') {
        header('Location: ./content/Payinitia/Wftpay/wxjspay.php?trade_no=' . $trade_no . '&identifi=f');
    }

} elseif (checkmobile() == true) {

#手机端支付

    if ($rowss == true) {

        if ($wxh5pay == 1) {
//判断商户是否开通有微信H5通道，如果有则走下面

            if ($rowss['api_type'] == 'wxpay') {
                header('Location: ./content/Payinitia/Wxpay/wxwappay2.php?trade_no=' . $trade_no . '&identifi=w');
            } else if ($rowss['api_type'] == 'epay') {
                header('Location: ./content/Payinitia/Epay/epay.php?donlx=1&trade_no=' . $trade_no . '&type=wxpay&identifi=e');
            }

        } else {
//如果商户没H5权限则安排走扫码支付
            if ($rows == false) {
                sysmsg('很抱歉！微信通道暂时无法使用，可能在维护过程中<br>请<a href="./content/default.php?pid=' . $pid . '&trade_no=' . $trade_no . '">点击此处更换其他支付方式进行支付</a>');
            }

            if ($rows['api_type'] == 'wxpay') {
                header('Location: ./content/Payinitia/Wxpay/wxwappay.php?trade_no=' . $trade_no . '&identifi=w');
            } else if ($rows['api_type'] == 'epay') {
                header('Location: ./content/Payinitia/Epay/epay.php?trade_no=' . $trade_no . '&type=wxpay&identifi=e');
            } else if ($rows['api_type'] == 'eshangpay') {
                header('Location: ./content/Payinitia/Espay/wxwappay.php?trade_no=' . $trade_no . '&identifi=x');
            } else if ($rows['api_type'] == 'wftpay') {
                header('Location: ./content/Payinitia/Wftpay/wxwappay.php?trade_no=' . $trade_no . '&identifi=f');
            }
        }

    } else {
//如果后台接口没有添加或者没有开启H5接口也安排走扫码支付
        if ($rows == false) {
            sysmsg('很抱歉！微信通道暂时无法使用，可能在维护过程中<br>请<a href="./content/default.php?pid=' . $pid . '&trade_no=' . $trade_no . '">点击此处更换其他支付方式进行支付</a>');
        }

        if ($rows['api_type'] == 'wxpay') {
            header('Location: ./content/Payinitia/Wxpay/wxwappay.php?trade_no=' . $trade_no . '&identifi=w');
        } else if ($rows['api_type'] == 'epay') {
            header('Location: ./content/Payinitia/Epay/epay.php?trade_no=' . $trade_no . '&type=wxpay&identifi=e');
        } else if ($rows['api_type'] == 'eshangpay') {
            header('Location: ./content/Payinitia/Espay/wxwappay.php?trade_no=' . $trade_no . '&identifi=x');
        } else if ($rows['api_type'] == 'wftpay') {
            header('Location: ./content/Payinitia/Wftpay/wxwappay.php?trade_no=' . $trade_no . '&identifi=f');
        }
    }

} else {

#电脑端支付
    if ($rows == false) {
        sysmsg('很抱歉！微信通道暂时无法使用，可能在维护过程中<br>请<a href="./content/default.php?pid=' . $pid . '&trade_no=' . $trade_no . '">点击此处更换其他支付方式进行支付</a>');
    }

    if ($rows['api_type'] == 'wxpay') {
        header('Location: ./content/Payinitia/Wxpay/wxpay.php?trade_no=' . $trade_no . '&identifi=w');
    } else if ($rows['api_type'] == 'epay') {
        header('Location: ./content/Payinitia/Epay/epay.php?trade_no=' . $trade_no . '&type=wxpay&identifi=e');
    } else if ($rows['api_type'] == 'eshangpay') {
        header('Location: ./content/Payinitia/Espay/wxpay.php?trade_no=' . $trade_no . '&identifi=x');
    } else if ($rows['api_type'] == 'wftpay') {
        header('Location: ./content/Payinitia/Wftpay/wxpay.php?trade_no=' . $trade_no . '&identifi=f');
    } else {
        sysmsg('暂时不能用微信付方式！<br>请<a href="./content/default.php?pid=' . $pid . '&trade_no=' . $trade_no . '">点击此处更换其他支付方式进行支付</a>');
    }

}
