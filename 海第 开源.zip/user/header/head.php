<?php
@header('Content-Type: text/html; charset=UTF-8');
if($userrow['active']==0){
	sysmsg('由于你的商户违反相关法律法规与《'.$conf['web_name'].'用户协议》，已被禁用！');
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <title><?php echo $conf['web_name']?> - 商户管理中心</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <link rel="stylesheet" type="text/css" href="/assets/layui/css/layui.css" />
  <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css" />
  <link rel="stylesheet" href="assets/css/animate.min.css" type="text/css" />
  <link rel="stylesheet" href="assets/css/font-awesome.min.css" type="text/css" />
  <link rel="stylesheet" href="assets/css/simple-line-icons.min.css" type="text/css" />
  <link rel="stylesheet" href="assets/css/font.css" type="text/css" />
  <link rel="stylesheet" href="assets/css/app.css" type="text/css" />
  <link rel="stylesheet" type="text/css" href="assets/css/style.css" />
</head>
<body>
<style type="text/css">
 @media (min-width:768px){
  #header {

         display: none!important; 

    }

 }
  @media (max-width:768px){

    #gbui {

         display: none!important; 

    }
    #spans{
        display: none!important; 
    }

  }
  .btn-primary {
    color: #ffffff !important;
    background-color: #03A9F4;
    border-color: #03A9F4;
}
</style>
<div class="app app-header-fixed" style="padding-top: 0px;">


  <!-- header -->
  <header id="header" class="navbar" role="menu">
          <!-- navbar header -->
      <div class="navbar-header bg-dark" style="border-bottom: 1px solid #e6e6e6;">
       
        <!-- brand -->
        <a href="./" class="navbar-brand text-lt text-center" style="padding-left: 0px;padding-right: 0px;">
          <i class="fa fa-jsfiddle"></i>
          <span class="hidden-folded m-l-xs"><?php echo $conf['web_name']?></span>

       <button class="pull-right visible-xs dk" ui-toggle="show" target=".navbar-collapse" style="float: right;">
          <i class="glyphicon glyphicon-user"></i>
        </button>
        <button class="visible-xs" ui-toggle="off-screen" target=".app-aside" ui-scroll="app" style="float: left;">
          <i class="glyphicon glyphicon-align-left"></i>
        </button>


        </a>
        <!-- / brand -->
      </div>
      <!-- / navbar header -->

      <!-- navbar collapse -->
      <div class="collapse pos-rlt navbar-collapse box-shadow bg-white-only">
        <!-- buttons -->
        <div class="nav navbar-nav hidden-xs">
          <a href="#" class="btn no-shadow navbar-btn" ui-toggle="app-aside-folded" target=".app">
            <i class="fa fa-dedent fa-fw text"></i>
            <i class="fa fa-indent fa-fw text-active"></i>
          </a>
        </div>
        <!-- / buttons -->

        <!-- nabar right -->
        <ul class="nav navbar-nav navbar-right dropdown" style="margin-top: 20px;height: 120px;">

        <div class="col-md-12">
          <div class="row-sm text-center">
            <div class="col-xs-6">
              <div class="r bg-light dker item hbox no-border" style="box-shadow: 0px 0px 0px 0px rgba(0, 0, 0, 0) !important;">
                <div id="uidd" class="r bg-light dker item hbox no-border" style="border-radius: 0px;">
                <div id="uidd" class="dk padder-v r-r">
                  <a href="?userinfo">
                <?php echo $gricon;?>
                <div class="text-xs">我的信息</div>
              </div>
              </a>
            </div>
          </div>
        </div>
        <div class="col-xs-6">
              <div class="r bg-light dker item hbox no-border" style="box-shadow: 0px 0px 0px 0px rgba(0, 0, 0, 0) !important;">
                <div id="uidd" class="r bg-light dker item hbox no-border" style="border-radius: 0px;">
                <div id="uidd" class="dk padder-v r-r" >
                  <a href="#" onclick="logout()">
                <?php echo $tcicon;?>
                <div class="text-xs">退出登录</div>
              </a>
              </div>

            </div>
          </div>
        </div>

      </div>
    </div>


<!--               <li>
                <a ui-sref="access.signin" onclick="logout()">
                  <i class="glyphicon glyphicon-log-in"></i>
                退出登录
              </a>
              </li> -->
            </ul>
         
        <!-- / navbar right -->
      </div>
      <!-- / navbar collapse -->
  </header>
  <!-- / header -->



  <!-- aside -->
  <aside id="aside" class="app-aside hidden-xs bg-dark">
     <div id="gbui" class="navbar-header bg-dark" style="border-bottom: 1px solid #e6e6e6;">
        <a href="./" class="navbar-brand text-lt text-center" style="padding-left: 0px;padding-right: 0px;">
          <i class="fa fa-jsfiddle"></i>
          <span class="hidden-folded m-l-xs"><?php echo $conf['web_name']?></span>
        </a>
      </div>
      <div class="aside-wrap">
        <div class="navi-wrap">

          <!-- nav -->
          <nav ui-nav class="navi clearfix">
            <ul class="nav">
              <li class="hidden-folded padder m-t m-b-sm text-muted text-xs">
                <div id="spans" style="border-bottom: 50px solid transparent;"></div>
                <span>导航</span>
              </li>
              <li>
                <a href="./">
                  <i class="glyphicon glyphicon-home icon text-primary-dker"></i>
				  <b class="label bg-info pull-right">N</b>
                  <span class="font-bold">用户中心</span>
                </a>
              </li>
        <li>
                <a href="?uspay">
                  <i class="icon-wallet icon text-info-lter"></i>
                  <span>余额充值</span>
                </a>
              </li>
               <?php if($conf['smrz']==1){ ?>
              <li>
                <a href="?attes">
                  <i class="glyphicon glyphicon-credit-card" style="color: #28d82f;"></i>
                  <span>实名认证</span>
                </a>
              </li>
            <?php } ?>
              <li class="hidden-folded padder m-t m-b-sm text-muted text-xs">
                <span>操作</span>
              </li>
              <?php if($conf['settle_open']==1){ ?>
        <li>
                <a href="?apply">
                  <i class="fa fa-sitemap"></i>
                  <span>余额提现</span>
                </a>
              </li>
            <?php } ?>
             <?php if($conf['yuezz']==1){ ?>
        <li>
                <a href="?transfer">
                  <i class="fa fa-exchange"></i>
                  <span>余额转账</span>
                </a>
              </li>
            <?php } ?>
              <li>
                <a href="?userinfo">
                  <i class="glyphicon glyphicon-edit"></i>
                  <span>修改资料</span>
                </a> 
              </li>
              <li class="hidden-folded padder m-t m-b-sm text-muted text-xs">
                <span>查询</span>
              </li>
			  <li>
                <a href="?order">
                  <i class="glyphicon glyphicon-list-alt"></i>
                  <span>订单记录</span>
                </a>
              </li>
			  <li>
                <a href="?settle">
                  <i class="glyphicon glyphicon-th-list"></i>
                  <span>结算记录</span>
                </a>
              </li>
              <li>
                <a href="?money">
                  <i class="glyphicon glyphicon-stats"></i>
                  <span>余额流向</span>
                </a>
              </li>
                <li class="hidden-folded padder m-t m-b-sm text-muted text-xs">
                <span>其他</span>
              </li>
              <li>
                <a href="?serve">
                  <i class="glyphicon glyphicon-shopping-cart"></i>
                  <span>服务开通</span>
                </a>
              </li>
              
              <li>
                <a href="?plug">
                  <i class="glyphicon glyphicon-cloud-download"></i>
                  <span>插件下载</span>
                </a>
              </li>
              
              
              <li class="line dk hidden-folded"></li>

              <li class="hidden-folded padder m-t m-b-sm text-muted text-xs">          
                <span>帮助</span>
              </li>
              <li>
                <a href="?help">
                  <i class="glyphicon glyphicon-info-sign"></i>
                  <span>使用说明</span>
                </a>
              </li>
              <li>
                <a href="<?php echo $conf['qqgroup'];?>" target="blank">
                  <i class="fa fa-qq"></i>
                  <span>产品QQ群</span>
                </a>
              </li>
               <li>
                <a href="#" onclick="logout()">
                  <i class="glyphicon glyphicon-log-in"></i>
                  <span>退出登录</span>
                </a>
              </li>
            </ul>
          </nav>
          <!-- nav -->

          <!-- aside footer -->
          <div class="wrapper m-t">
<div class="text-center"><a href="./" target="_blank"><?php echo $conf['web_name']?></a></div><br>
<div class="text-center">&copy; 2016-2019 Copyright.</div>
    </div>

          <!-- / aside footer -->
        </div>
      </div>
  </aside>
