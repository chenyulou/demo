<script src="https://lib.baomitu.com/jquery/3.3.1/jquery.min.js"></script>
<script src="/assets/layer/layer.js"></script>
<script src="/assets/js/MiniDialog-es5.min.js"></script>
<script src="/assets/js/echarts.min.js"></script>
<script src="./assets/js/bootstrap.min.js"></script>
<script src="./assets/js/ui-jp.config.js"></script>
<script src="./assets/js/ui-jp.js"></script>
<script src="./assets/js/ui-nav.js"></script>
<script src="https://template.down.swap.wang/ui/angulr_2.0.1/html/js/ui-toggle.js"></script>
<?php if(isset($_GET['userinfo'])){ ?>
<script src="//static.geetest.com/static/tools/gt.js"></script>
<script src="assets/js/userinfo.js"></script>
<?php }?>
<script type="text/javascript">
$(".weiqq").click(function(){

  var type = $(this).attr('data-type');

  if(type=='wx'){
   var title = '微信绑定';
   var content= '说明：<br>1.微信绑定可能会获取到你的基本信息(手机号等)<br>2.为了安全起见，请点击确定获取二维码进行绑定';
   var qrcode = '<iframe src="./cache/wxlogin.php?bind" style="width: 100%;height: 200px;padding: 0;margin: 0;border: 0;"></iframe>';
  }else if (type=='qq'){
   var title = 'QQ绑定';
   var content= '说明：<br>1.QQ绑定可能会获取到你的基本信息<br>2.为了安全起见，请点击确定获取二维码进行绑定';
   var qrcode = '<iframe src="./cache/qqlog.php?bind" style="width: 100%;height: 200px;padding: 0;margin: 0;border: 0;"></iframe>';
  }else if (type=='jdwx') {
   var title = '微信解绑';
   var content= '说明：<br>解绑号可进行更换其他微信号码绑定，若继续操作请点击确定。';
   var qrcode = '<iframe src="./cache/wxlogin.php?jieb" style="width: 100%;height: 200px;padding: 0;margin: 0;border: 0;"></iframe>';
  }else if (type=='jdqq') {
   var title = 'QQ解绑';
   var content= '说明：<br>解绑号可进行更换其他QQ号码绑定,若继续操作请点击确定。';
   var qrcode = '<iframe src="./cache/qqlog.php?bind" style="width: 100%;height: 200px;padding: 0;margin: 0;border: 0;"></iframe>';
  }else{
   var title = '系统提示';
   var content= '系统出错，请求发生错误！';
   var qrcode = 0;
  }

  if(qrcode==0){
Dialog({
    title: title,
    content: content,
  })
  }else{

  Dialog({
    title: title,
    content: content,
    ok: {
       waiting: true,
       waitingText: "正在获取二维码",
        callback: function () {
           window.setTimeout(function () {
                Dialog.close();
                Dialog({ 
                   title: title,
                   content: qrcode,    
                   showButton: false
                 });
            }, 3000)

        }
    },
  });
 }
})

function tap_msg(){

var phone = $("input[name='phone']").val();

var email = $("input[name='email']").val();

var zfmm = $("input[name='zfmm']").val();

if(phone==''){layer.alert('手机号不能为空！');return false;}

if(phone.length!=11){layer.alert('手机号码不正确！');return false;}

if(email==''){layer.alert('邮箱号不能为空！');return false;}

var reg = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/;
    
if(!reg.test(email)){layer.alert('邮箱格式不正确！');return false;}

if(zfmm==''){layer.alert('支付密码不能为空！');return false;}

if(zfmm.length!=6){layer.alert('支付密码必须为6位数！');return false;}

if(isNaN(zfmm)){layer.alert('支付密码必须为数字！');return false;}

 $.ajax({

      type:"POST",

        url:"./jsajax/ajax2.php?act=msg",

        data:{phone:phone,email:email,zfmm:zfmm},

        dataType:"json",

        success:function(data){

      if(data.code == 0){
    
      layer.msg(data.msg);

      $('.tap-msg').hide();

       }else{

          layer.msg(data.msg);

        }
      
          
            
        }
    });
}


function agree_cake(){

	  if($('input[name=agree]').is(':checked')){
	    $('.closetap').attr('disabled',false);
	  }else{
	    $('.closetap').attr('disabled',true);
	  }
}
$("select[name='type']").change(function(){
  if($(this).val() == 2){
   $("#keys").css("display","inherit");
     }else{
    $("#keys").css("display","none");
  }
 });
$(".yhkrz").click(function(){

    var card = $("input[name='yhkh']").val();

    $.ajax({

    	type:"POST",

        url:"./jsajax/ajax2.php?act=yinhang",

        data:{card:card},

        dataType:"json",

        success:function(data){
      
            $("#ka").val(data.msg);
        }
         
    });
    
})


$(".shggck").click(function(){

var type = $(this).attr('types');

var name = $(this).attr('manes');

Dialog({    title: type,    content: name, showButton: false});

})

function logout(){
Dialog({
title: "系统提示",
content: "<center><h2>你确定要退出登录吗？</h2></center>",
ok: {
  waiting: true,
  waitingText: "正在退出...",
  callback: function () {
    window.setTimeout(function () {
      $.ajax({
        type : "POST",
        url : "jsajax/ajax.php?act=login&logout",
        dataType : 'json',
        success : function(data) {
        if(data.code == 0){
            window.parent.location.href="/user/";
           }
          }
        });
        Dialog.close();
    }, 3000)
  }
}
});

}


$(".tixs").click(function(){
      
  var ii = layer.load(2, {shade:[0.1,'#fff']});

  $.ajax({

      type : "POST",

      url : "jsajax/ajax2.php?act=tix",

      data : $('#tixu').serialize(),

      dataType : 'json',

      success : function(data) {
          
          layer.close(ii);

          if(data.code == 0){

          layer.msg(data.msg,function(index){

          parent.layer.closeAll();
          
          window.location.reload();
         
          });

          }else{

          layer.msg(data.msg);

          }

      }

  });
 })

$(".mmxg").click(function(){
      
  var ii = layer.load(2, {shade:[0.1,'#fff']});

  $.ajax({

      type : "POST",

      url : "jsajax/ajax2.php?act=mmxg",

      data : $('#mm').serialize(),

      dataType : 'json',

      success : function(data) {
          
          layer.close(ii);

          if(data.code == 0){

          layer.msg(data.msg,function(index){

          parent.layer.closeAll();
          
          window.location.reload();
         
          });

          }else{

          layer.msg(data.msg);

          }

      }

  });
 })

$(".zfmmxg").click(function(){var ii = layer.load(2, {shade:[0.1,'#fff']}); $.ajax({type : "POST", url : "jsajax/ajax2.php?act=zfmmxg", data : $('#zf').serialize(), dataType : 'json', success : function(data) {layer.close(ii); if(data.code == 0){layer.msg(data.msg,function(index){parent.layer.closeAll(); window.location.reload(); }); }else{layer.msg(data.msg); } } }); })

$(".keycz").click(function(){

  var type = $('#key-type').val()

if(type==2){
  var key = $('#key-name').val()

  if(key.length = 32){

   layer.msg("key必须是32位，你输入的是"+key.length+"位！");
   
   return;

  }
}else{
  var key = 0;
}
  var ii = layer.load(2, {shade:[0.1,'#fff']});

  $.ajax({

      type : "POST",

      url : "jsajax/ajax2.php?act=keycz",

      data : {key:key,type:type},

      dataType : 'json',

      success : function(data) {
          
          layer.close(ii);

          if(data.code == 0){

          layer.msg(data.msg,function(index){

          parent.layer.closeAll();
          
          window.location.reload();
         
          });

          }else{

          layer.msg(data.msg);

          }

      }

  });
 })

$(".serve").click(function(){

  var type = $(this).attr('data-type');

  var money = $(this).attr('money');

  if(money==='xsmf') {

    var text = '确认开通此权限吗？';


  }else{

    var text = '确认花费'+money+'元购买此权限吗？';

  }

  layer.confirm(text, {icon: 3, title:'开通提示'}, function(index){
   //do something
  layer.close(index);
  var ii = layer.load(2, {shade:[0.1,'#fff']});
     $.ajax({

    type : "POST",

    url : "jsajax/ajax2.php?act=fwseve",

    data : {type:type,money:money},

    dataType : 'json',

    success : function(data) {
             
    layer.close(ii);

      if(data.code == 0){

        layer.msg(data.msg,function(index){

                parent.layer.closeAll();
                
                window.location.reload();
               
                });

      }else{

        layer.msg(data.msg);

      }

         }

        });
         
  });

})



      $(".shzz").click(function(){
            
        var ii = layer.load(2, {shade:[0.1,'#fff']});

        $.ajax({

            type : "POST",

            url : "jsajax/ajax2.php?act=transfer",

            data : $('#shzz').serialize(),

            dataType : 'json',

            success : function(data) {
                
                layer.close(ii);

                if(data.code == 0){

                layer.msg(data.msg,function(index){

                parent.layer.closeAll();
                
                window.location.reload();
               
                });

                }else{

                layer.msg(data.msg);

                }

            }

        });
       })


    function sfyz(){
            
        var ii = layer.load(2, {shade:[0.1,'#fff']});

        $.ajax({

            type : "POST",

            url : "jsajax/ajax2.php?act=sfyz",

            data : $('#form_sfyz').serialize(),

            dataType : 'json',

            success : function(data) {
                
                layer.close(ii);

                if(data.code == 0){

                layer.msg(data.msg,function(index){

                parent.layer.closeAll();
                
                window.location.reload();
               
               });

                }else{

                    layer.msg(data.msg);

                }

            }

        });
    }

    function sjrz(){
            
        var ii = layer.load(2, {shade:[0.1,'#fff']});

        $.ajax({

            type : "POST",

            url : "jsajax/ajax2.php?act=sjrz",

            data : $('#form_sjrz').serialize(),

            dataType : 'json',

            success : function(data) {
                
                layer.close(ii);

                if(data.code == 0){

                layer.msg(data.msg,function(index){

                parent.layer.closeAll();
                
                window.location.reload();
               
               });

                }else{

                    layer.msg(data.msg);

                }

            }

        });
    }
    function yhkyz(){
            
        var ii = layer.load(2, {shade:[0.1,'#fff']});

        $.ajax({

            type : "POST",

            url : "jsajax/ajax2.php?act=yhrz",

            data : $('#form_yhkrz').serialize(),

            dataType : 'json',

            success : function(data) {
                
                layer.close(ii);

                if(data.code == 0){

                layer.msg(data.msg,function(index){

                parent.layer.closeAll();
                
                window.location.reload();
               
               });

                }else{

                    layer.msg(data.msg);

                }

            }

        });
    }

    var zhexianchart = echarts.init(document.getElementById('center-zhexian'));
    var zhexianoption = {
    tooltip: {
        trigger: 'axis'
    },
    legend: {
        data:['订单总数','成功订单','失败订单']
    },
    grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true
    },
    toolbox: {
        feature: {
            saveAsImage: {}
        }
    },
    xAxis: {
        type: 'category',
        boundaryGap: false,
         data:<?php echo json_encode($zhexiandatakey)?>
    },
    yAxis: {
        type: 'value'
    },
    series: [
        {
            name:'订单总数',
            type:'line',
            stack: '总量',
            data:<?php echo json_encode($zhexiandatavalue);?>,
            itemStyle: {
                normal: {
                    color: '#4ac4ea'
                }
            }
        },
        {
            name:'成功订单',
            type:'line',
            stack: '总量',
            data:<?php echo json_encode($zhexiandatacgorder);?>,
            itemStyle: {
                normal: {
                    color: '#48cb67'
                }
            }
        },
        {
            name:'失败订单',
            type:'line',
            stack: '总量',
            data:<?php echo json_encode($zhexiandatasborder);?>,
            itemStyle: {
                normal: {
                    color: '#f05050'
                }
            }
        },
    ]

        };

        // 使用刚指定的配置项和数据显示图表。
        zhexianchart.setOption(zhexianoption);


  var simple =echarts.init(document.getElementById('center-simple'));

  var option = {
    title : {
        text: '今日通道收入统计',
        x:'center'
    },
    tooltip : {
        trigger: 'item',
        formatter: "{a} <br/>{b} : {c} ({d}%)"
    },
    legend: {
        orient: 'vertical',
        left: 'left',
        data: ['QQ','微信','支付宝']
    },
    series : [
        {
            name: '数据统计',
            type: 'pie',
            radius : '55%',
            center: ['50%', '60%'],
            roseType: 'angle',
            data:[
                {value:<?php echo round($jt_qqpay,2);?>, name:'QQ',itemStyle: {
        color: '#fad733'
    }},
                {value:<?php echo round($jt_wxpay,2);?>, name:'微信',itemStyle: {
        color: '#27c24c'
    }},
                {value:<?php echo round($jt_alipay,2);?>, name:'支付宝',itemStyle: {
        color: '#23b7e5'
    }}
            ],

        }
    ]
};

simple.setOption(option);


</script>

</body>
</html>