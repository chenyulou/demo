<?php
include("../../includes/common.php");
$act=isset($_GET['act'])?daddslashes($_GET['act']):null;

@header('Content-Type: application/json; charset=UTF-8');

switch($act){

case 'captcha':
	require_once SYSTEM_ROOT.'lib/class.geetestlib.php';

	$GtSdk = new GeetestLib($conf['CAPTCHA_ID'], $conf['PRIVATE_KEY']);

	$data = array(

		'user_id' => isset($pid)?$pid:'public', # 网站用户id

		'client_type' => "web", # web:电脑上的浏览器；h5:手机上的浏览器，包括移动应用内完全内置的web_view；native：通过原生SDK植入APP应用的方式

		'ip_address' => $clientip # 请在此处传输用户请求验证时所携带的IP

	);

	$status = $GtSdk->pre_process($data, 1);

	$_SESSION['gtserver'] = $status;

	$_SESSION['user_id'] = isset($pid)?$pid:'public';

	echo $GtSdk->get_response_str();

break;

case 'sendcode':

	$sendto=trim(daddslashes($_POST['sendto']));

	if($conf['is_reg']==0)exit('{"code":-1,"msg":"未开放商户申请"}');

	if(isset($_SESSION['send_mail']) && $_SESSION['send_mail']>time()-10){

		exit('{"code":-1,"msg":"请勿频繁发送验证码"}');

	}

	require_once SYSTEM_ROOT.'lib/class.geetestlib.php';

	$GtSdk = new GeetestLib($conf['CAPTCHA_ID'], $conf['PRIVATE_KEY']);

	$data = array(

		'user_id' => 'public', 

		'client_type' => "web", 

		'ip_address' => $clientip 

	);

	if ($_SESSION['gtserver'] == 1) {   //服务器正常

		$result = $GtSdk->success_validate($_POST['geetest_challenge'], $_POST['geetest_validate'], $_POST['geetest_seccode'], $data);

		if ($result) {
			//echo '{"status":"success"}';
		} else{

			exit('{"code":-1,"msg":"验证失败，请重新验证"}');

		}
	}else{  //服务器宕机,走failback模式

		if ($GtSdk->fail_validate($_POST['geetest_challenge'],$_POST['geetest_validate'],$_POST['geetest_seccode'])) {
			//echo '{"status":"success"}';
		}else{

			exit('{"code":-1,"msg":"验证失败，请重新验证"}');

		}

	}


	if($conf['verifytype']==1){

		$phone = $sendto;

		$row=$DB->query("select * from pay_user where phone='$phone' limit 1")->fetch();

		if($row){

			exit('{"code":-1,"msg":"该手机号已被使用,请更换其他手机号码注册！"}');

		}

		$row=$DB->query("select * from pay_regcode where email='$phone' order by id desc limit 1")->fetch();

		if($row['time']>time()-60){

			exit('{"code":-1,"msg":"两次发送短信之间需要相隔60秒！"}');

		}

		$count=$DB->query("select count(*) from pay_regcode where email='$phone' and time>'".(time()-3600*24)."'")->fetchColumn();

		if($count>2){

			exit('{"code":-1,"msg":"该手机号码发送次数过多，请更换号码！"}');

		}

		$count=$DB->query("select count(*) from pay_regcode where ip='$clientip' and time>'".(time()-3600*24)."'")->fetchColumn();

		if($count>5){

			exit('{"code":-1,"msg":"你今天发送次数过多，已被禁止注册"}');

		}

		$code = rand(111111,999999);

		$tnum=$conf['dx_mb_reg'];
        
		$result = send_sms($phone, $code,$tnum);

		if($result===true){

			if($DB->exec("insert into `pay_regcode` (`type`,`code`,`email`,`time`,`ip`,`status`) values ('1','".$code."','".$phone."','".time()."','".$clientip."','0')")){
				$_SESSION['send_mail']=time();

				exit('{"code":0,"msg":"succ"}');

			}else{

				exit('{"code":-1,"msg":"写入数据库失败。'.$DB->errorCode().'"}');

			}

		}else{

			exit('{"code":-1,"msg":"短信发送失败 '.$result.'"}');

		}

	}else{

		$email = $sendto;

		$row=$DB->query("select * from pay_user where email='{$email}' limit 1")->fetch();

		if($row){

			exit('{"code":-1,"msg":"该邮箱号已被使用,请更换其他邮箱号码注册！"}');

		}

		$row=$DB->query("select * from pay_regcode where email='{$email}' order by id desc limit 1")->fetch();

		if($row['time']>time()-60){

			exit('{"code":-1,"msg":"两次发送邮件之间需要相隔60秒！"}');

		}

		$count=$DB->query("select count(*) from pay_regcode where email='{$email}' and time>'".(time()-3600*24)."'")->fetchColumn();

		if($count>6){

			exit('{"code":-1,"msg":"该邮箱发送次数过多，请更换邮箱！"}');

		}

		$count=$DB->query("select count(*) from pay_regcode where ip='{$clientip}' and time>'".(time()-3600*24)."'")->fetchColumn();

		if($count>10){

			exit('{"code":-1,"msg":"你今天发送次数过多，已被禁止注册"}');

		}

		$code = rand(1111111,9999999);

		$text="你的注册验证码是：".$code;

        $msg=youfas($text);

        $result = send_mail($email, $conf['web_name']."-注册提醒！", $msg);

		if($result===true){

			if($DB->exec("insert into `pay_regcode` (`type`,`code`,`email`,`time`,`ip`,`status`) values ('0','".$code."','".$email."','".time()."','".$clientip."','0')")){
				$_SESSION['send_mail']=time();

				exit('{"code":0,"msg":"succ"}');

			}else{

				exit('{"code":-1,"msg":"写入数据库失败。'.$DB->errorCode().'"}');

			}
		}else{

			file_put_contents('mail.log',$result);

			exit('{"code":-1,"msg":"邮件发送失败"}');

		}
	}
break;




case 'sendlogin':

	$sendto=trim(daddslashes($_POST['sendto']));


	if(isset($_SESSION['send_mail']) && $_SESSION['send_mail']>time()-10){

		exit('{"code":-1,"msg":"请勿频繁发送验证码"}');

	}

	require_once SYSTEM_ROOT.'lib/class.geetestlib.php';

	$GtSdk = new GeetestLib($conf['CAPTCHA_ID'], $conf['PRIVATE_KEY']);

	$data = array(

		'user_id' => 'public', 

		'client_type' => "web", 

		'ip_address' => $clientip 

	);

	if ($_SESSION['gtserver'] == 1) {   //服务器正常

		$result = $GtSdk->success_validate($_POST['geetest_challenge'], $_POST['geetest_validate'], $_POST['geetest_seccode'], $data);

		if ($result) {
			//echo '{"status":"success"}';
		} else{

			exit('{"code":-1,"msg":"验证失败，请重新验证"}');

		}
	}else{  //服务器宕机,走failback模式

		if ($GtSdk->fail_validate($_POST['geetest_challenge'],$_POST['geetest_validate'],$_POST['geetest_seccode'])) {
			//echo '{"status":"success"}';
		}else{

			exit('{"code":-1,"msg":"验证失败，请重新验证"}');

		}

	}

		$phone = $sendto;

		$row=$DB->query("select * from pay_user where phone='$phone' limit 1")->fetch();

		if(!$row){

			exit('{"code":-1,"msg":"该手机号未绑定商户账号！"}');

		}

		$row=$DB->query("select * from pay_regcode where email='$phone' order by id desc limit 1")->fetch();

		if($row['time']>time()-60){

			exit('{"code":-1,"msg":"两次发送短信之间需要相隔60秒！"}');

		}

		$count=$DB->query("select count(*) from pay_regcode where email='$phone' and time>'".(time()-3600*24)."'")->fetchColumn();

		if($count>2){

			exit('{"code":-1,"msg":"该手机号码发送次数过多，请更换号码！"}');

		}

		$count=$DB->query("select count(*) from pay_regcode where ip='$clientip' and time>'".(time()-3600*24)."'")->fetchColumn();

		if($count>5){

			exit('{"code":-1,"msg":"你今天发送次数过多，已被禁止使用验证码登录！"}');

		}

		$code = rand(111111,999999);

		$tnum=$conf['dx_mb_log'];
        
		$result = send_sms($phone, $code,$tnum);

		if($result===true){

			if($DB->exec("insert into `pay_regcode` (`type`,`code`,`email`,`time`,`ip`,`status`) values ('3','".$code."','".$phone."','".time()."','".$clientip."','0')")){
				$_SESSION['send_mail']=time();

				exit('{"code":0,"msg":"succ"}');

			}else{

				exit('{"code":-1,"msg":"写入数据库失败。'.$DB->errorCode().'"}');

			}

		}else{

			exit('{"code":-1,"msg":"短信发送失败 '.$result.'"}');

		}

break;


case 'codelog':

$phone=trim(strip_tags(daddslashes($_POST['phone'])));

$code=trim(strip_tags(daddslashes($_POST['code'])));

if(strlen($phone)!=11){

	exit('{"code":-1,"msg":"请填写正确的手机号！"}');

}

$row=$DB->query("select * from pay_regcode where type=3 and code='$code' and email='$phone' order by id desc limit 1")->fetch();


if(!$row){

	exit('{"code":-1,"msg":"验证码不正确！"}');

}

if($row['time']<time()-3600 || $row['status']>0){

	exit('{"code":-1,"msg":"验证码已失效，请重新获取"}');

}

$scriptpath=str_replace('\\','/',$_SERVER['SCRIPT_NAME']);

$sitepath = substr($scriptpath, 0, strrpos($scriptpath, '/'));

$siteurl = ($_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://').$_SERVER['HTTP_HOST'].$sitepath.'/';

$userrow=$DB->query("SELECT * FROM pay_user WHERE phone='{$phone}' limit 1")->fetch();

if($userrow){

$DB->query("insert into `pay_log` (`uid`,`type`,`date`,`city`,`data`) values ('".$userrow['user']."','登录用户中心','".$date."','".$city."','".$clientip."')");

$DB->exec("update `pay_regcode` set `status` ='1' where `id`='{$row['id']}'");

$session=md5($userrow['id'].$userrow['pwd'].$password_hash);

$expiretime=time()+604800;

$token=authcode("{$userrow['id']}\t{$session}\t{$expiretime}", 'ENCODE', SYS_KEY);

setcookie("user_token", $token, time() + 604800,"/user");

@header('Content-Type: text/html; charset=UTF-8');

exit('{"code":0,"msg":"登陆成功！"}');

}else{

exit('{"code":-1,"msg":"登陆失败！"}');


}

break;




case 'reg':

	$type=intval($_POST['type']);

	$user=trim(strip_tags(daddslashes($_POST['user'])));

	$pwd=trim(strip_tags(daddslashes($_POST['pwd'])));

	$email=trim(strip_tags(daddslashes($_POST['email'])));

	$phone=trim(strip_tags(daddslashes($_POST['phone'])));

	$code=trim(strip_tags(daddslashes($_POST['code'])));

	if($conf['is_reg']==0)exit('{"code":-1,"msg":"未开放商户申请"}');

	if(isset($_SESSION['reg_submit']) && $_SESSION['reg_submit']>time()-600){

		exit('{"code":-1,"msg":"请勿频繁注册"}');

	}
	if($conf['verifytype']==1){

		$row=$DB->query("select * from pay_user where phone='$phone' limit 1")->fetch();

		if($row){

			exit('{"code":-1,"msg":"该手机号已被使用,请更换其他手机号码注册！"}');

		}

	}else{
	$row=$DB->query("select * from pay_user where email='$email' limit 1")->fetch();

	if($row){

		exit('{"code":-1,"msg":"该邮箱号已被使用,请更换其他邮箱号码注册！"}');

	}
}

	if (preg_match("/([\x81-\xfe][\x40-\xfe])/", $user)) {
	     exit('{"code":-1,"msg":"账号不能够有中文！"}'); 
	}

	  if(preg_match('/^[0-9A-Z]+$/',$user) || strlen($user)<=5){
  
       exit('{"code":-1,"msg":"账号必须大于或等于5位且不位纯数字！"}');
  
      }

	$row=$DB->query("select * from pay_user where user='$user' limit 1")->fetch();

	if($row){

		exit('{"code":-1,"msg":"该账号已经存在！"}');

	}

	if($type==1 && strlen($account)!=11){

		exit('{"code":-1,"msg":"请填写正确的手机号！"}');

	}
	

	if (preg_match("/([\x81-\xfe][\x40-\xfe])/", $pwd)) {
	     exit('{"code":-1,"msg":"密码不能够有中文！"}'); 
	}
    if(mb_strlen($pwd,"utf-8")<8){
  
      exit('{"code":-1,"msg":"密码不能少于8位！"}');
  
    }

	if($conf['verifytype']==0 && !preg_match('/^[A-z0-9._-]+@[A-z0-9._-]+\.[A-z0-9._-]+$/', $email)){

		exit('{"code":-1,"msg":"邮箱格式不正确"}');

	}

	if($conf['verifytype']==1){

		$row=$DB->query("select * from pay_regcode where type=1 and code='$code' and email='$phone' order by id desc limit 1")->fetch();

	}else{

		$row=$DB->query("select * from pay_regcode where type=0 and code='$code' and email='$email' order by id desc limit 1")->fetch();

	}
	if(!$row){

		exit('{"code":-1,"msg":"验证码不正确！"}');

	}

	if($row['time']<time()-3600 || $row['status']>0){

		exit('{"code":-1,"msg":"验证码已失效，请重新获取"}');

	}

	$scriptpath=str_replace('\\','/',$_SERVER['SCRIPT_NAME']);

	$sitepath = substr($scriptpath, 0, strrpos($scriptpath, '/'));

	$siteurl = ($_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://').$_SERVER['HTTP_HOST'].$sitepath.'/';


		$key = random(32);

		$sds=$DB->exec("INSERT INTO `pay_user` (`key`, `user`, `pwd`, `money`, `email`, `phone`, `addtime`, `type`, `active`) VALUES ('{$key}', '{$user}', '{$pwd}', '0', '{$email}', '{$phone}', '{$date}', '0', '1')");

		$pid=$DB->lastInsertId();

		if($sds){

		$text="注册成功，尊敬的".$user.",感谢你注入我们平台！";

        $msg=youfas($text);

        $result = send_mail($email, $conf['web_name']."-注册提醒！", $msg);

			$DB->exec("update `pay_regcode` set `status` ='1' where `id`='{$row['id']}'");

			$_SESSION['reg_submit']=time();

			exit('{"code":1,"msg":"申请商户成功！","user":"'.$user.'","pwd":"'.$pwd.'"}');

		}else{

			exit('{"code":-1,"msg":"申请商户失败！'.$DB->errorCode().'"}');
		}
	
break;

case 'find':

	$email=trim(daddslashes($_POST['email']));

	if(isset($_SESSION['find_mail']) && $_SESSION['find_mail']>time()-600){

		exit('{"code":-1,"msg":"请勿频繁发送邮件，如果未收到请尝试在垃圾邮件箱寻找"}');

	}

	$row=$DB->query("select * from pay_user where email='$email' limit 1")->fetch();

	if(!$row){

		exit('{"code":-1,"msg":"该邮箱未绑定商户，如需找回请联系客服"}');

	}

	$text="信息找回：账号".$row['user'].",密码".$row['pwd'];

    $msg=youfas($text);

    $result = send_mail($email, $conf['web_name']."-密码找回！", $msg);

	if($result===true){

		$_SESSION['find_mail']=time();

		exit('{"code":0,"msg":"succ"}');

	}else{

		file_put_contents('mail.log',$result);

		exit('{"code":-1,"msg":"邮件发送失败"}');

	}
	
break;

case 'login':

$city=get_ip_city($clientip);

if(isset($_GET['logout'])){

	setcookie("user_token", "", time() - 604800,"/user");

	@header('Content-Type: text/html; charset=UTF-8');

	exit('{"code":0,"msg":"你已成功退出登陆！"}');

}
	$user=daddslashes($_POST['user']);

	$pass=$_POST['pass'];

	$userrow=$DB->query("SELECT * FROM pay_user WHERE qq='{$user}' or user='{$user}' or email='{$user}' or phone='{$user}' limit 1")->fetch();

	if($user==''){
		exit('{"code":-1,"msg":"账号不能为空！"}');
	}
	if($pass==''){
		exit('{"code":-1,"msg":"密码不能为空！"}');
	}
	if(!$userrow){
		exit('{"code":-1,"msg":"账号不存在！"}');
	}

	if($pass==$userrow['pwd']) {

		$DB->query("insert into `pay_log` (`uid`,`type`,`date`,`city`,`data`) values ('".$userrow['id']."','登录用户中心','".$date."','".$city."','".$clientip."')");

		$session=md5($userrow['id'].$userrow['pwd'].$password_hash);

		$expiretime=time()+604800;

		$token=authcode("{$userrow['id']}\t{$session}\t{$expiretime}", 'ENCODE', SYS_KEY);
        
		setcookie("user_token", $token, time() + 604800,"/user");

		@header('Content-Type: text/html; charset=UTF-8');

		$DB->query("insert into `pay_log` (`uid`,`type`,`date`,`city`,`data`) values ('".$userrow['id']."','登录用户中心','".$date."','".$city."','".$clientip."')");

		exit('{"code":0,"msg":"登陆成功！"}');

	}else {

		exit('{"code":-1,"msg":"你的密码不正确！"}');

	}

	break;

	case 'qqlogin':

		$city=get_ip_city($clientip);

		$qq=daddslashes($_POST['qq']);

		$user=$DB->query("SELECT * FROM pay_user WHERE qq_uid='{$qq}' limit 1")->fetch();

		if($user['qq_uid']==$qq){

		$session=md5($user['id'].$user['pwd'].$password_hash);

		$expiretime=time()+604800;

		$token=authcode("{$user['id']}\t{$session}\t{$expiretime}", 'ENCODE', SYS_KEY);
        
		setcookie("user_token", $token, time() + 604800,"/user");

		$DB->query("insert into `pay_log` (`uid`,`type`,`date`,`city`,`data`) values ('".$userrow['id']."','登录用户中心','".$date."','".$city."','".$clientip."')");

        exit('{"code":0,"msg":"登陆成功！正在为你跳转中"}');

		}else{

		exit('{"code":-1,"msg":"登陆失败，该QQ未与平台账号绑定！"}');

		}

		break;

	case 'wxlogin':

		$city=get_ip_city($clientip);

		$webid='1002';
		$encrypt=$_POST['encrypt'];
		$decrypturl='https://open.sanhaoapi.cn/wechat/decrypt.php?encrypt='.$encrypt.'&webid='.$webid;
		$data=file_get_contents($decrypturl);
		$data = json_decode($data, true);
		$openid =daddslashes($data['openid']);

		$user=$DB->query("SELECT * FROM pay_user WHERE wxid='{$openid}' limit 1")->fetch();

		if($user){

		$session=md5($user['id'].$user['pwd'].$password_hash);

		$expiretime=time()+604800;

		$token=authcode("{$user['id']}\t{$session}\t{$expiretime}", 'ENCODE', SYS_KEY);
        
		setcookie("user_token", $token, time() + 604800,"/user");

		$DB->query("insert into `pay_log` (`uid`,`type`,`date`,`city`,`data`) values ('".$userrow['id']."','登录用户中心','".$date."','".$city."','".$clientip."')");

        exit('{"code":0,"msg":"登陆成功！正在重新加载中"}');

		}else{

		exit('{"code":-1,"msg":"登陆失败，该微信未与平台账号绑定！"}');

		}

		break;


default:
	exit('{"code":-4,"msg":"No Act"}');
break;
}