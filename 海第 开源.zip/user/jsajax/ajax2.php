<?php

include "../../includes/common.php";

if ($islogin2 == 1) {} else {
    exit('{"code":-3,"msg":"No Login"}');
}

$act = isset($_GET['act']) ? daddslashes($_GET['act']) : null;

@header('Content-Type: application/json; charset=UTF-8');

switch ($act) {

    case 'sendcode':
        $type       = trim(daddslashes($_POST['type']));
        $situations = trim(daddslashes($_POST['situations']));
        $target     = trim(strip_tags(daddslashes($_POST['target'])));
        if (isset($_SESSION['send_mail']) && $_SESSION['send_mail'] > time() - 10) {
            exit('{"code":-1,"msg":"请勿频繁发送验证码"}');
        }
        require_once SYSTEM_ROOT . 'lib/class.geetestlib.php';
        $GtSdk = new GeetestLib($conf['CAPTCHA_ID'], $conf['PRIVATE_KEY']);
        $data  = array(
            'user_id'     => $pid, # 网站用户id
            'client_type' => "web", # web:电脑上的浏览器；h5:手机上的浏览器，包括移动应用内完全内置的web_view；native：通过原生SDK植入APP应用的方式
            'ip_address'  => $clientip, # 请在此处传输用户请求验证时所携带的IP
        );
        if ($_SESSION['gtserver'] == 1) {
            //服务器正常
            $result = $GtSdk->success_validate($_POST['geetest_challenge'], $_POST['geetest_validate'], $_POST['geetest_seccode'], $data);
            if (!$result) {exit('{"code":-1,"msg":"验证失败，请重新验证"}');}
        } else {
            //服务器宕机,走failback模式
            if ($GtSdk->fail_validate($_POST['geetest_challenge'], $_POST['geetest_validate'], $_POST['geetest_seccode'])) {
            } else {
                exit('{"code":-1,"msg":"验证失败，请重新验证"}');
            }}

        if ($type == 'phone') {
//短信验证码 判断
            if ($situations == 'bind') {
                //绑定判断
                $phone = $target;
                if (empty($phone) || strlen($phone) != 11) {exit('{"code":-1,"msg":"请填写正确的手机号码！"}');}
                if ($phone == $userrow['phone']) {exit('{"code":-1,"msg":"你填写的手机号码和之前一样"}');}
                $row = $DB->query("select * from pay_user where phone='$target' limit 1")->fetch();
                if ($row) {exit('{"code":-1,"msg":"该手机号码已经绑定过其它商户"}');}
            } else {
                //修改验证判断
                if (empty($userrow['phone']) || strlen($userrow['phone']) != 11) {exit('{"code":-1,"msg":"请先绑定手机号码！"}');}
                $phone = $userrow['phone'];}
            $row = $DB->query("select * from pay_regcode where email='$phone' order by id desc limit 1")->fetch();
            if ($row['time'] > time() - 60) {exit('{"code":-1,"msg":"两次发送短信之间需要相隔60秒！"}');}
            $count = $DB->query("select count(*) from pay_regcode where email='$phone' and time>'" . (time() - 3600 * 24) . "'")->fetchColumn();
            if ($count > 2) {exit('{"code":-1,"msg":"该手机号码发送次数过多，暂无法发送！"}');}
            $count = $DB->query("select count(*) from pay_regcode where ip='$clientip' and time>'" . (time() - 3600 * 24) . "'")->fetchColumn();
            if ($count > 5) {exit('{"code":-1,"msg":"你今天发送次数过多，已被禁止发送"}');}
//短信验证码 发送
            $code   = rand(111111, 999999);
            $tnum   = $conf['dx_mb_code'];
            $result = send_sms($phone, $code, $tnum, '4');
            if ($result === true) {
                if ($DB->exec("insert into `pay_regcode` (`type`,`code`,`email`,`time`,`ip`,`status`) values ('3','" . $code . "','" . $phone . "','" . time() . "','" . $clientip . "','0')")) {
                    $_SESSION['send_mail'] = time();
                    exit('{"code":0,"msg":"succ"}');
                } else {
                    exit('{"code":-1,"msg":"写入数据库失败。' . $DB->errorCode() . '"}');
                }
            } else {
                exit('{"code":-1,"msg":"短信发送失败 ' . $result . '"}');

            }
        } else {
//邮箱验证码  判断
            if ($situations == 'bind') {
                $email = $target;
                if (!preg_match('/^[A-z0-9._-]+@[A-z0-9._-]+\.[A-z0-9._-]+$/', $email)) {exit('{"code":-1,"msg":"邮箱格式不正确"}');}
                if ($email == $userrow['email']) {exit('{"code":-1,"msg":"你填写的邮箱和之前一样"}');}
                $row = $DB->query("select * from pay_user where email='$email' limit 1")->fetch();
                if ($row) {exit('{"code":-1,"msg":"该邮箱已经绑定过其它商户"}');}
            } else {
                if (empty($userrow['email']) || strpos($userrow['email'], '@') === false) {exit('{"code":-1,"msg":"请先绑定邮箱！"}');}
                $email = $userrow['email'];
            }
            $row = $DB->query("select * from pay_regcode where email='$email' order by id desc limit 1")->fetch();
            if ($row['time'] > time() - 60) {exit('{"code":-1,"msg":"两次发送邮件之间需要相隔60秒！"}');}
            $count = $DB->query("select count(*) from pay_regcode where email='$email' and time>'" . (time() - 3600 * 24) . "'")->fetchColumn();
            if ($count > 6) {exit('{"code":-1,"msg":"该邮箱发送次数过多，请更换邮箱！"}');}
            $count = $DB->query("select count(*) from pay_regcode where ip='$clientip' and time>'" . (time() - 3600 * 24) . "'")->fetchColumn();
            if ($count > 10) {exit('{"code":-1,"msg":"你今天发送次数过多，已被禁止发送"}');}
//邮箱验证码 发送
            $sub  = $conf['web_name'] . ' - 验证码获取';
            $code = rand(1111111, 9999999);
            if ($situation == 'settle') {
                $msg = youfas('您正在修改结算账号信息，验证码是：' . $code);
            } elseif ($situation == 'mibao') {
                $msg = youfas('您正在修改密保邮箱，验证码是：' . $code);
            } elseif ($situations == 'bind') {
                $msg = youfas('您正在绑定新邮箱，验证码是：' . $code);
            } else {
                $msg = youfas('您的验证码是：' . $code);
            }

            $result = send_mail($email, $sub, $msg);
            if ($result === true) {
                if ($DB->exec("insert into `pay_regcode` (`type`,`code`,`email`,`time`,`ip`,`status`) values ('2','" . $code . "','" . $email . "','" . time() . "','" . $clientip . "','0')")) {
                    $_SESSION['send_mail'] = time();
                    exit('{"code":0,"msg":"succ"}');
                } else {
                    exit('{"code":-1,"msg":"写入数据库失败。' . $DB->errorCode() . '"}');
                }
            } else {
                file_put_contents('mail.log', $result);
                exit('{"code":-1,"msg":"邮件发送失败"}');
            }
        }
        break;

    case 'verifycode':
        $type = trim(strip_tags(daddslashes($_POST['type'])));
        $code = trim(strip_tags(daddslashes($_POST['code'])));
        if ($type == 'phone') {
            $row = $DB->query("select * from pay_regcode where type=3 and code='$code' and email='{$userrow['phone']}' order by id desc limit 1")->fetch();
        } else if ($type == 'email') {
            $row = $DB->query("select * from pay_regcode where type=2 and code='$code' and email='{$userrow['email']}' order by id desc limit 1")->fetch();
        } else {
            exit('{"code":-1,"msg":"请求错误！"}');
        }
        if (!$row) {
            exit('{"code":-1,"msg":"验证码不正确！"}');
        }
        if ($row['time'] < time() - 3600 || $row['status'] > 0) {
            exit('{"code":-1,"msg":"验证码已失效，请重新获取"}');
        }
        $_SESSION['verify_ok'] = $pid;
        $DB->exec("update `pay_regcode` set `status` ='1' where `id`='{$row['id']}'");
        exit('{"code":1,"msg":"succ"}');
        break;

    case 'edit_settle':
        $type     = intval($_POST['stype']);
        $account  = trim(strip_tags(daddslashes($_POST['account'])));
        $username = trim(strip_tags(daddslashes($_POST['username'])));
        if ($account == null || $username == null) {
            exit('{"code":-1,"msg":"请确保每项都不为空"}');
        }
        if ($type == 1 && strlen($account) != 11 && strpos($account, '@') == false) {
            exit('{"code":-1,"msg":"请填写正确的支付宝账号！"}');
        }
        if ($type == 2 && strlen($account) < 3) {
            exit('{"code":-1,"msg":"请填写正确的微信"}');
        }
        $sqs = $DB->exec("update `pay_user` set `settle_id` ='{$type}',`account` ='{$account}',`username` ='{$username}' where `id`='$pid'");
        if ($sqs || $DB->errorCode() == '0000') {
            exit('{"code":1,"msg":"succ"}');
        } else {
            exit('{"code":-1,"msg":"保存失败！' . $DB->errorCode() . '"}');
        }

        break;

    case 'edit_info':
        $accounts = daddslashes(strip_tags($_POST['accounts']));
        $url      = daddslashes(strip_tags($_POST['url']));
        $sqs      = $DB->exec("update `pay_user` set `accounts` ='{$accounts}',`url` ='{$url}' where `id`='$pid'");
        if ($sqs || $DB->errorCode() == '0000') {
            exit('{"code":1,"msg":"succ"}');
        } else {
            exit('{"code":-1,"msg":"保存失败！' . $DB->errorCode() . '"}');
        }

        break;

    case 'edit_bind':

        $type  = daddslashes(strip_tags($_POST['type']));
        $email = daddslashes(strip_tags($_POST['email']));
        $phone = daddslashes(strip_tags($_POST['phone']));
        $code  = daddslashes(strip_tags($_POST['code']));
        if ($code == null || $email == null && $phone == null) {
            exit('{"code":-1,"msg":"请确保每项都不为空"}');
        }
        if ($type == 'phone') {
            $row = $DB->query("select * from pay_regcode where type=3 and code='$code' and email='$phone' order by id desc limit 1")->fetch();
        } else if ($type == 'email') {
            $row = $DB->query("select * from pay_regcode where type=2 and code='$code' and email='$email' order by id desc limit 1")->fetch();
        } else {
            exit('{"code":-1,"msg":"请求错误！"}');
        }
        if (!$row) {
            exit('{"code":-1,"msg":"验证码不正确！"}');
        }
        if ($row['time'] < time() - 3600 || $row['status'] > 0) {
            exit('{"code":-1,"msg":"验证码已失效，请重新获取"}');
        }
        if ($type == 'phone') {
            $sqs = $DB->exec("update `pay_user` set `phone` ='{$phone}' where `id`='$pid'");
        } else if ($type == 'email') {
            $sqs = $DB->exec("update `pay_user` set `email` ='{$email}' where `id`='$pid'");
        } else {
            exit('{"code":-1,"msg":"请求错误！"}');
        }
        if ($sqs || $DB->errorCode() == '0000') {
            exit('{"code":1,"msg":"succ"}');
        } else {
            exit('{"code":-1,"msg":"保存失败！' . $DB->errorCode() . '"}');
        }
        break;

    case 'yinhang':

        $yhk = daddslashes(strip_tags($_POST['card']));
        $fh  = bankInfo($yhk);
        exit('{"code":1,"msg":"' . $fh . '"}');

        break;

    case 'transfer':

        $date = date("Y-m-d H:i:s");
        $ids  = daddslashes(strip_tags($_POST['pid']));

        $row = $DB->query("SELECT * FROM `pay_user` WHERE user='{$ids}'  limit 1")->fetch();

        if ($ids == '') {
            exit('{"code":1,"msg":"收款账号不能为空！"}');
        } else if (!$row) {
            exit('{"code":1,"msg":"用户不存在哦！"}');
        }
        $money = daddslashes(strip_tags($_POST['money']));
        if ($money == '') {
            exit('{"code":1,"msg":"转账余额不能为空！"}');
        }
        $note = daddslashes(strip_tags($_POST['note']));
        if ($money == '') {
            exit('{"code":1,"msg":"转账余额不能为空！"}');
        }

        if (preg_match("/([\x81-\xfe][\x40-\xfe])/", $money)) {
            exit('{"code":-1,"msg":"余额不能有特殊字符！"}');
        }
        $zfmm = daddslashes(strip_tags($_POST['zfmm']));
        if ($zfmm == '') {
            exit('{"code":1,"msg":"支付密码不能为空！"}');
        }
        if ($zfmm != $userrow['zfmm']) {
            exit('{"code":1,"msg":"支付密码错误！"}');
        } else if ($money > $userrow['money'] || $money <= 0) {
            exit('{"code":1,"msg":"你的余额不足！"}');
        } else if ($ids == $userrow['user']) {
            exit('{"code":1,"msg":"不可以转给自己哦！"}');
        }
        $res = $DB->exec("INSERT INTO `pay_accoun` (`uid`, `pid`, `money`, `note`, `status`, `time`) VALUES ('{$pid}', '{$ids}', '{$money}', '{$note}', '1', '{$date}')");
        if ($res) {
            $DB->exec("update `pay_user` set `money` =money-$money where `id`='$pid'");

            $row = $DB->query("SELECT * FROM pay_user WHERE id='{$pid}' limit 1")->fetch();

            $DB->exec("INSERT INTO `pay_money` (`uid`, `name`, `money`, `addmoney`, `time`) VALUES ('{$pid}', '转账', '-{$money}', '{$row['money']}', '{$date}')");

            $DB->exec("update `pay_user` set `money` =money+$money where `user`='$ids'");

            $rows = $DB->query("SELECT * FROM pay_user WHERE user='{$ids}' limit 1")->fetch();

            $DB->exec("INSERT INTO `pay_money` (`uid`, `name`, `money`, `addmoney`, `time`) VALUES ('{$rows['id']}', '收款', '+{$money}', '{$rows['money']}', '{$date}')");

            exit('{"code":0,"msg":"转账成功！"}');

        } else {

            exit('{"code":1,"msg":"转账失败！"}');

        }

        break;

    case 'mmxg':
        $jpwd = daddslashes(strip_tags($_POST['jpwd']));
        $xpwd = daddslashes(strip_tags($_POST['xpwd']));
        $zpwd = daddslashes(strip_tags($_POST['zpwd']));
        if ($jpwd == '' || $xpwd == '' || $zpwd == '') {
            exit('{"code":1,"msg":"请确保每项不能为空！"}');
        } else if ($jpwd != $userrow['pwd']) {
            exit('{"code":1,"msg":"旧密码有误！"}');
        } else if ($xpwd != $zpwd) {
            exit('{"code":1,"msg":"你输入的新密码不一致！"}');
        } else if ($xpwd == $userrow['pwd']) {
            exit('{"code":1,"msg":"你输入的密码不能与之前的一致！"}');
        }
        $rs = $DB->exec("update `pay_user` set `pwd` ='{$zpwd}' where `id`='$pid'");
        if ($rs) {
            $userrow    = $DB->query("SELECT * FROM pay_user WHERE id='{$userrow['id']}' limit 1")->fetch();
            $session    = md5($userrow['id'] . $userrow['pwd'] . $password_hash);
            $expiretime = time() + 604800;
            $token      = authcode("{$userrow['id']}\t{$session}\t{$expiretime}", 'ENCODE', SYS_KEY);
            setcookie("user_token", $token, time() + 604800, "/user");
            exit('{"code":0,"msg":"修改成功！"}');
        } else {
            exit('{"code":1,"msg":"修改失败！"}');
        }
        break;

    case 'zfmmxg':
        $jpzf = daddslashes(strip_tags($_POST['jpzf']));
        $xpzf = daddslashes(strip_tags($_POST['xpzf']));
        $zpzf = daddslashes(strip_tags($_POST['zpzf']));
        if ($jpzf == '' || $xpzf == '' || $zpzf == '') {
            exit('{"code":1,"msg":"请确保每项不能为空！"}');
        } else if ($jpzf != $userrow['zfmm']) {
            exit('{"code":1,"msg":"旧支付密码有误！"}');
        } else if (!is_numeric($jpzf)) {
            exit('{"code":1,"msg":"支付密码必须为数字！"}');
        } else if (strlen($jpzf) != 6) {
            exit('{"code":1,"msg":"支付密码必须为6位数！"}');
        } else if (!is_numeric($xpzf)) {
            exit('{"code":1,"msg":"支付密码必须为数字！"}');
        } else if (strlen($xpzf) != 6) {
            exit('{"code":1,"msg":"支付密码必须为6位数！"}');
        } else if (!is_numeric($zpzf)) {
            exit('{"code":1,"msg":"支付密码必须为数字！"}');
        } else if (strlen($zpzf) != 6) {
            exit('{"code":1,"msg":"支付密码必须为6位数！"}');
        } else if ($xpzf != $zpzf) {
            exit('{"code":1,"msg":"你输入的新支付密码不一致！"}');
        } else if ($xpzf == $userrow['zfmm']) {
            exit('{"code":1,"msg":"你输入的支付密码不能与之前的一致！"}');
        }
        $rs = $DB->exec("update `pay_user` set `zfmm` ='{$zpzf}' where `id`='$pid'");
        if ($rs) {
            exit('{"code":0,"msg":"修改成功！"}');
        } else {
            exit('{"code":1,"msg":"修改失败！"}');
        }
        break;

    case 'tix':
        #allmoney 手续费
        #fee 因结余额
        #money 申请余额
        $batch    = date("Ymd") . rand(111, 999);
        $zfmm     = daddslashes(strip_tags($_POST['zfmm']));
        $money    = daddslashes(strip_tags($_POST['money']));
        $allmoney = round($money * $conf['settle_rate'], 2);
        if ($allmoney < $conf['settle_fee_min']) {
            $allmoney = $conf['settle_fee_min'];
        }
        if ($allmoney > $conf['settle_fee_max']) {
            $allmoney = $conf['settle_fee_max'];
        }
        $fee = $money - $allmoney;
        if ($money < $conf['settle_money']) {
            exit('{"code":1,"msg":"抱歉！你输入提现的金额不在申请范围内"}');
        } else if ($money > $conf['settle_money_max']) {
            exit('{"code":1,"msg":"抱歉！你输入提现的金额不在申请范围内"}');
        }if ($zfmm == '' || $money == '') {
            exit('{"code":1,"msg":"请确保每项不能为空！"}');
        } else if (!is_numeric($money)) {
            exit('{"code":1,"msg":"请不要输入不为数字的字符！"}');
        } else if ($zfmm != $userrow['zfmm']) {
            exit('{"code":1,"msg":"支付密码有误！"}');
        } else if ($userrow['apply'] > $conf['settle_every']) {
            exit('{"code":1,"msg":"你有一笔资金尚未处理，暂时不可申请！"}');
        } else if ($userrow['type'] == 2) {
            exit('{"code":1,"msg":"您的商户出现异常，无法提现！"}');
        } else if ($money > $userrow['money'] || $money <= 0) {
            exit('{"code":1,"msg":"你的余额不足！  "}');
        }

        $DB->exec("update `pay_user` set `apply` =apply+1,`money` =money-$money where `id`='$pid'"); //扣余额
        $userrow = $DB->query("SELECT * FROM pay_user WHERE id='{$userrow['id']}' limit 1")->fetch(); //重新查询
        $DB->exec("INSERT INTO `pay_money` (`uid`, `name`, `money`, `addmoney`, `time`) VALUES ('{$pid}', '提现', '-{$money}', '{$userrow['money']}', '{$date}')");
        $DB->exec("INSERT INTO `pay_settle` (`pid` ,`batch` ,`type` ,`username` ,`account` ,`money` ,`allmoney` ,`fee` ,`time` ,`status`)	VALUES ('{$pid}','{$batch}','{$userrow['settle_id']}', '{$userrow['username']}','{$userrow['account']}','{$fee}','{$money}','{$allmoney}','{$date}','3')");

        exit('{"code":0,"msg":"提现提交成功，请内心等待！"}');

        break;

    case 'fwseve':

        $type = daddslashes(strip_tags($_POST['type']));

        if ($type == 'qqpay') {

            $money = $conf['is_qqpay'];

        } else if ($type == 'wxpay') {

            $money = $conf['is_wxpay'];

        } else if ($type == 'alipay') {

            $money = $conf['is_alipay'];

        } else if ($type == 'wxh5pay') {

            $money = $conf['is_wxh5'];

        } else {

            exit('{"code":1,"msg":"参数错误！"}');

        }

        if ($conf['is_pay'] == 1) {

            if ($userrow['money'] < $money) {

                exit('{"code":1,"msg":"余额不足哦！请先充值吧！"}');

            }

            $res = $DB->exec("update `pay_user` set `{$type}` ='1',`money`=money-$money where `id`='{$pid}'");

            $DB->exec("INSERT INTO `pay_money` (`uid`, `name`, `money`, `addmoney`, `time`) VALUES ('{$pid}', '通道开通', '-{$money}', '{$userrow['money']}', '{$date}')");

        } else {
            $res = $DB->exec("update `pay_user` set `{$type}` ='1' where `id`='{$pid}'");
        }

        if ($res) {

            exit('{"code":0,"msg":"购买成功！感谢使用。"}');

        } else {

            exit('{"code":1,"msg":"购买失败！请稍后重试。' . $type . '"}');

        }

        break;

    case 'keycz':
        $key = daddslashes(strip_tags($_POST['key']));

        $type = daddslashes(strip_tags($_POST['type']));

        $keys = mb_strlen($key, 'UTF8');

        if (!preg_match('/^(?![0-9]+$)(?![a-zA-Z]+$)[0-9a-zA-Z]+$/', "123qw")) {
            exit('{"code":1,"msg":"key必须包含字母及数字！"}');
        }

        if ($type == 2) {
            if ($keys != 32) {

                exit('{"code":1,"msg":"key必须是32位，你输入的是' . $keys . '位！"}');

            }
        } else if ($type == 1) {
            $key = random(32);
        } else {
            exit('{"code":1,"msg":"参数错误！"}');
        }

        $res = $DB->exec("update `pay_user` set `key` ='{$key}' where `id`='$pid'");

        if ($res) {

            exit('{"code":0,"msg":"重置成功！"}');

        } else {

            exit('{"code":1,"msg":"重置失败！"}');

        }

        break;

    case 'sfyz':

        $name = daddslashes(strip_tags($_POST['name']));

        $sfzhm = daddslashes(strip_tags($_POST['sfzhm']));

        if ($name == '') {
            exit('{"code":1,"msg":"姓名不能为空！"}');
        } else if ($sfzhm == '') {
            exit('{"code":1,"msg":"身份证号码不能为空！"}');
        }
        $arr = is_idcard($sfzhm);
        if ($arr == false) {
            exit('{"code":1,"msg":"身份证号码格式错误！"}');
        }

        $rss = rzfrequency($userrow['sf_rz']);

        if ($rss == 0) {

            exit('{"code":1,"msg":"抱歉！你的认证次数用尽！"}');

        }

        $data = Sfyz($sfzhm, $name, $conf);

        $isok = $data['result']['isok'];

        $name = $data['result']['realname']; //姓名

        $sfzhm = $data['result']['idcard']; //身份证号码

        if ($isok == true) {

            $DB->exec("update `pay_user` set `username` ='{$name}',`sfzhm` ='{$sfzhm}',`sf_rz` ='1' where `id`='$pid'");

            exit('{"code":0,"msg":"认证通过！"}');

        } else {
            if ($userrow['sf_rz'] == '') {
                $DB->exec("update `pay_user` set `sf_rz` ='2' where `id`='$pid'");
            } else {
                $DB->exec("update `pay_user` set `sf_rz` =sf_rz+1 where `id`='$pid'");
            }
            exit('{"code":1,"msg":"认证失败！"}');
        }

        break;

    case 'sjrz':

        $name = daddslashes(strip_tags($_POST['name']));

        $sfzhm = daddslashes(strip_tags($_POST['sfzhm']));

        if ($name == '') {
            exit('{"code":1,"msg":"姓名不能为空！"}');
        } else if ($sfzhm == '') {
            exit('{"code":1,"msg":"身份证号码不能为空！"}');
        }
        $arr = is_idcard($sfzhm);
        if ($arr == false) {
            exit('{"code":1,"msg":"身份证号码格式错误！"}');
        }

        $rss = rzfrequency($userrow['sj_rz']);

        if ($rss == 0) {

            exit('{"code":1,"msg":"抱歉！你的认证次数用尽！"}');

        }

        $data = shourz($userrow['phone'], $sfzhm, $name, $conf);

        $isok = $data['VerificationResult'];

        if ($isok == 1) {

            $DB->exec("update `pay_user` set `sj_rz` ='1' where `id`='$pid'");

            exit('{"code":0,"msg":"认证通过！"}');

        } else {
            if ($userrow['sj_rz'] == '') {
                $DB->exec("update `pay_user` set `sj_rz` ='2' where `id`='$pid'");
            } else {
                $DB->exec("update `pay_user` set `sj_rz` =sj_rz+1 where `id`='$pid'");
            }
            exit('{"code":1,"msg":"认证失败,信息不符合！"}');
        }

        break;

    case 'yhrz':

        $name = $userrow['username'];

        $sfzhm = $userrow['sfzhm'];

        $yhkh = daddslashes(strip_tags($_POST['yhkh']));

        $type = daddslashes(strip_tags($_POST['type']));

        if ($yhkh == '') {
            exit('{"code":1,"msg":"银行卡号不能为空！"}');
        } else if (strlen($yhkh) < 16) {
            exit('{"code":1,"msg":"请填写正确的银行卡号码！"}');
        } else if ($type == '') {
            exit('{"code":1,"msg":"银行卡类型不能为空！"}');
        }

        $rss = rzfrequency($userrow['yh_rz']);

        if ($rss == 0) {

            exit('{"code":1,"msg":"抱歉！你的认证次数用尽！"}');

        }

        $data = yhkrz($yhkh, $sfzhm, $name, $conf);

        if ($data == 'T') {

            $DB->exec("update `pay_user` set `yh_rz` ='1' where `id`='$pid'");

            exit('{"code":0,"msg":"认证通过！"}');

        } else {
            if ($userrow['yh_rz'] == '') {
                $DB->exec("update `pay_user` set `yh_rz` ='2' where `id`='$pid'");
            } else {
                $DB->exec("update `pay_user` set `yh_rz` =yh_rz+1 where `id`='$pid'");
            }
            exit('{"code":1,"msg":"认证失败,信息不符合！"}');
        }

        break;

    case 'msg':

        $email = daddslashes(strip_tags($_POST['email']));

        $phone = daddslashes(strip_tags($_POST['phone']));

        $zfmm = daddslashes(strip_tags($_POST['zfmm']));

        if ($userrow['phone'] == '') {

            $row = $DB->query("select * from pay_user where phone='$phone' limit 1")->fetch();

        }

        if ($userrow['email'] == '') {

            $rows = $DB->query("select * from pay_user where email='$email' limit 1")->fetch();

        }

        if ($phone == '') {

            exit('{"code":1,"msg":"手机号码不能为空！"}');

        } else if (strlen($phone) != 11) {

            exit('{"code":1,"msg":"请填写正确的手机号码！"}');

        } else if ($row) {

            exit('{"code":-1,"msg":"该手机号已被使用,请更换其他手机号码！"}');

        } else if ($email == '') {

            exit('{"code":1,"msg":"邮箱号不能为空！"}');

        } else if (!preg_match('/^[A-z0-9._-]+@[A-z0-9._-]+\.[A-z0-9._-]+$/', $email)) {

            exit('{"code":-1,"msg":"邮箱格式不正确！"}');

        } else if ($rows) {

            exit('{"code":-1,"msg":"该邮箱已被使用,请更换其他邮箱号码！"}');

        } else if ($zfmm == '') {

            exit('{"code":1,"msg":"支付密码不能为空！"}');

        } else if (!is_numeric($zfmm)) {

            exit('{"code":1,"msg":"支付密码必须为数字！"}');

        } else if (strlen($zfmm) != 6) {

            exit('{"code":1,"msg":"支付密码必须为6位数！"}');

        }
        $arr = $DB->exec("update `pay_user` set `email`='{$email}',`phone`='{$phone}',`zfmm`='{$zfmm}',`xieyi` ='1' where `id`='$pid'");
        if ($arr) {

            exit('{"code":0,"msg":"保存成功！"}');

        } else {

            exit('{"code":1,"msg":"保存失败！"}');

        }

        break;

    case 'qqbind':

        $qq = daddslashes($_POST['qq']);

        $name = daddslashes($_POST['nick']);

        $user = $DB->query("SELECT * FROM pay_user WHERE qq_uid='{$qq}' limit 1")->fetch();

        if ($user['qq_uid'] == $qq) {

            exit('{"code":1,"msg":"绑定失败！该QQ已被绑定。"}');

        } else {

            $arr = $DB->exec("update `pay_user` set `qq_uid`='{$qq}',`qq_name`='{$name}' where `id`='$pid'");

            if (!$arr) {

                exit('{"code":1,"msg":"绑定失败，系统出错！"}');

            }

            exit('{"code":0,"msg":"绑定成功！正在为你重新加载中"}');

        }

        break;

    case 'qqjieb':

        $qq = daddslashes($_POST['qq']);

        $name = daddslashes($_POST['nick']);

        $user = $DB->query("SELECT * FROM pay_user WHERE qq_uid='{$qq}' limit 1")->fetch();

        if ($user['qq_uid'] != $qq) {

            exit('{"code":1,"msg":"解绑失败，请使用原绑定号码扫码"}');

        } else {

            $arr = $DB->exec("update `pay_user` set `qq_uid`='',`qq_name`='' where `id`='$pid'");

            if (!$arr) {

                exit('{"code":1,"msg":"解绑失败，系统出错！"}');

            }

            exit('{"code":0,"msg":"解绑成功！正在为你重新加载中"}');

        }

        break;

    case 'wxbind':

        $webid      = '1002';
        $encrypt    = $_POST['encrypt'];
        $name       = daddslashes($_POST['name']);
        $type       = daddslashes($_POST['type']);
        $decrypturl = 'https://open.sanhaoapi.cn/wechat/decrypt.php?encrypt=' . $encrypt . '&webid=' . $webid;
        $data       = file_get_contents($decrypturl);
        $data       = json_decode($data, true);
        $name       = daddslashes($data['nickname']);
        $openid     = daddslashes($data['openid']);

        if ($openid == '') {
            exit('{"code":1,"msg":"绑定失败！该无法获取openid"}');
        }

        $user = $DB->query("SELECT * FROM pay_user WHERE wxid='{$openid}' limit 1")->fetch();

        if ($user['wxid'] == $openid) {

            exit('{"code":1,"msg":"绑定失败！该微信已被绑定。"}');

        } else {

            $arr = $DB->exec("update `pay_user` set `wxid`='{$openid}',`wx_name`='{$name}' where `id`='$pid'");

            if (!$arr) {

                exit('{"code":1,"msg":"绑定失败，系统出错！"}');

            }

            exit('{"code":0,"msg":"绑定成功！正在为你重新加载中"}');

        }

        break;

    case 'wxjieb':

        $webid      = '1002';
        $encrypt    = $_POST['encrypt'];
        $name       = daddslashes($_POST['name']);
        $decrypturl = 'https://open.sanhaoapi.cn/wechat/decrypt.php?encrypt=' . $encrypt . '&webid=' . $webid;
        $data       = file_get_contents($decrypturl);
        $data       = json_decode($data, true);
        $name       = daddslashes($data['nickname']);
        $openid     = daddslashes($data['openid']);
        if ($openid == '') {
            exit('{"code":1,"msg":"解绑失败！该无法获取openid"}');
        }
        $user = $DB->query("SELECT * FROM pay_user WHERE wxid='{$openid}' limit 1")->fetch();

        if ($openid != $user['wxid']) {

            exit('{"code":1,"msg":"解绑失败！请使用原微信扫码。"}');

        } else {

            $arr = $DB->exec("update `pay_user` set `wxid`='',`wx_name`='' where `id`='$pid'");

            if (!$arr) {

                exit('{"code":1,"msg":"解绑失败，系统出错！"}');

            }

            exit('{"code":0,"msg":"解绑成功！正在为你重新加载中"}');

        }

        break;

    case 'order':

        function do_callback($data)
    {
            global $DB, $userrow;
            if ($data['status'] >= 1) {
                $trade_status = 'TRADE_SUCCESS';
            } else {
                $trade_status = 'TRADE_FAIL';
            }

            $array  = array('pid' => $data['pid'], 'trade_no' => $data['trade_no'], 'out_trade_no' => $data['out_trade_no'], 'type' => $data['type'], 'name' => $data['name'], 'money' => $data['money'], 'trade_status' => $trade_status);
            $arg    = argSort(paraFilter($array));
            $prestr = createLinkstring($arg);
            $urlstr = createLinkstringUrlencode($arg);
            $sign   = md5Sign($prestr, $userrow['key']);
            if (strpos($data['notify_url'], '?')) {
                $url = $data['notify_url'] . '&' . $urlstr . '&sign=' . $sign . '&sign_type=MD5';
            } else {
                $url = $data['notify_url'] . '?' . $urlstr . '&sign=' . $sign . '&sign_type=MD5';
            }

            return $url;
        }

        if (!empty($_GET['select_orderId'])) {
            $kw = daddslashes($_GET['select_orderId']);
            if (strlen($_GET['select_orderId']) == 19) {
                $sql = " and trade_no='$kw'";
            } elseif (strlen($_GET['select_orderId']) == 17) {
                $sql = " and out_trade_no='$kw'";
            } else {
                $sql = "";
            }

        } else {
            $sql = "";

        }
        $numrows  = $DB->query("SELECT count(*) from pay_order WHERE pid={$pid}{$sql}")->fetchColumn();
        $pagesize = $_GET['limit'];
        $pages    = intval($numrows / $pagesize);
        if ($numrows % $pagesize) {
            $pages++;
        }
        if (isset($_GET['page'])) {
            $page = intval($_GET['page']);
        } else {
            $page = 1;
        }
        $offset = $pagesize * ($page - 1);

        $list = $DB->query("SELECT * FROM pay_order WHERE pid={$pid}{$sql} order by trade_no desc limit $offset,$pagesize")->fetchAll();

        // 获得回调通知
        foreach ($list as $key => $value) {
            $list[$key]['url'] = do_callback($value);
        }

        $jsonArray = ['code' => 0, 'msg' => '', 'count' => $numrows, 'data' => $list];

        print(json_encode($jsonArray));

        break;

    case 'settle':

        $numrows  = $DB->query("SELECT * from pay_settle WHERE pid={$pid}")->rowCount();
        $pagesize = $_GET['limit'];
        $pages    = intval($numrows / $pagesize);
        if ($numrows % $pagesize) {
            $pages++;
        }
        if (isset($_GET['page'])) {
            $page = intval($_GET['page']);
        } else {
            $page = 1;
        }
        $offset = $pagesize * ($page - 1);

        $list = $DB->query("SELECT * FROM pay_settle WHERE pid={$pid} order by id desc limit $offset,$pagesize")->fetchAll();
        $i    = 1;
        foreach ($list as $key => $value) {
            $list[$key]['i'] = $i++;
        }
        $jsonArray = ['code' => 0, 'msg' => '', 'count' => $numrows, 'data' => $list];

        print(json_encode($jsonArray));

        break;

    case 'money':

        $numrows  = $DB->query("SELECT count(*) from pay_money WHERE uid={$pid}")->fetchColumn();
        $pagesize = $_GET['limit'];
        $pages    = intval($numrows / $pagesize);
        if ($numrows % $pagesize) {
            $pages++;
        }
        if (isset($_GET['page'])) {
            $page = intval($_GET['page']);
        } else {
            $page = 1;
        }
        $offset = $pagesize * ($page - 1);

        $list = $DB->query("SELECT * FROM pay_money WHERE uid={$pid} order by id desc limit $offset,$pagesize")->fetchAll();

        $i = 1;
        foreach ($list as $key => $value) {
            $list[$key]['i'] = $i++;
        }
        $jsonArray = ['code' => 0, 'msg' => '', 'count' => $numrows, 'data' => $list];

        print(json_encode($jsonArray));

        break;

    default:

        exit('{"code":-4,"msg":"请求错误！"}');

        break;

}
