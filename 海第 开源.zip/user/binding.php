<?php
include("../includes/common.php");

if ($conf['lyhbd']!=1) {
    exit();
  }

if(isset($_POST['user']) && isset($_POST['pwd'])){

$user=trim(strip_tags(daddslashes($_POST['user'])));

$pwd=trim(strip_tags(daddslashes($_POST['pwd'])));

$id=trim(strip_tags(daddslashes($_POST['id'])));

$key=trim(strip_tags(daddslashes($_POST['key'])));

	if (preg_match("/([\x81-\xfe][\x40-\xfe])/", $user)) {
	
	exit("<script language='javascript'>alert('账号不能够有中文！');history.go(-1);</script>");
	    
	}

	  if(preg_match('/^[0-9A-Z]+$/',$user) || strlen($user)<=5){
  exit("<script language='javascript'>alert('账号必须大于或等于5位且不位纯数字！');history.go(-1);</script>");
      
  
      }

	$row=$DB->query("select * from pay_user where user='$user' limit 1")->fetch();

	if($row){
exit("<script language='javascript'>alert('该账号已经存在！');history.go(-1);</script>");
	

	}


	if (preg_match("/([\x81-\xfe][\x40-\xfe])/", $pwd)) {
	
	exit("<script language='javascript'>alert('密码不能够有中文！');history.go(-1);</script>");
	    
	}
    if(mb_strlen($pwd,"utf-8")<8){
    
  exit("<script language='javascript'>alert('密码不能少于8位！');history.go(-1);</script>");
    
  
    }

$userrow=$DB->query("select * from pay_user where id='{$id}' limit 1")->fetch();

if($userrow){

if($userrow['key']==$key){

  $rs = $DB->exec("update `pay_user` set `user` ='{$user}',`pwd` ='{$pwd}',`wxh5pay` ='2' where `id`='$id'");

   if($rs){
   
   exit("<script language='javascript'>alert('绑定成功！');window.location.href='./?login';</script>");
   
   }else{
   
    exit("<script language='javascript'>alert('绑定失败！');history.go(-1);</script>");
   
   }
}else{

 exit("<script language='javascript'>alert('KEY错误或不存在！');history.go(-1);</script>");
 
}
}else{

exit("<script language='javascript'>alert('该ID不存在，请检查后进行操作！');history.go(-1);</script>");


}
}

?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<title>商户绑定 | <?php echo $conf['web_name']?></title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css" />
<link rel="stylesheet" href="assets/css/app.min.css" type="text/css" />
</head>
<body>
<div class="app app-header-fixed  ">
<div class="container w-xxl w-auto-xs" ng-controller="SigninFormController" ng-init="app.settings.container = false;">
<span class="navbar-brand block" style="height: 60px;"><?php echo $conf['web_name']?></span>
<span class="h6" style="height: 50px;">老用户绑定</span><br>
<form name="form" class="form-validation" method="post" action="binding.php">
<div class="text-danger wrapper text-center" ng-show="authError">
</div>
<div class="list-group-item">
            <div class="input-group">
              <input type="text" name="user" placeholder="请输入账号" class="form-control no-border" required>
            </div>
            </div>
<div class="list-group-item">
            <div class="input-group">
              <input type="password" name="pwd" placeholder="请输入密码" class="form-control no-border" required>
            </div>
            </div>
<div class="list-group-item">
            <div class="input-group">
              <input type="password" name="id" placeholder="请输入旧平台ID" class="form-control no-border" required>
            </div>
            </div>
<div class="list-group-item">
            <div class="input-group">
              <input type="password" name="key" placeholder="请输入旧平台KEY" class="form-control no-border" required>
            </div>
            </div>
<button type="submit" class="btn btn-lg btn-primary btn-block login" style="margin-bottom: 10px;">立即绑定</button>
</form>
 <div style="height: 40px;">
  <a href="./?login" style="float: left;">已有账号，去登录</a><a href="./?reg" style="float: right;">未有账号，去注册</a>
</div>
</div>
</div>
</body>
</html>