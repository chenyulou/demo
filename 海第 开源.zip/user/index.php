<?php
include("../includes/common.php");

$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://": "http://";//判断通讯协议

$userurl = $protocol . $_SERVER['HTTP_HOST'].'/user/'.'?userurl='.$_SERVER['QUERY_STRING'];//拼接完整url

$arr = parse_url($userurl);

$arr_query = convertUrlQuery($arr['query']);
 
if($islogin2!=1){ 
	if($_SERVER['QUERY_STRING']){
	   include 'cache/'.$arr_query['userurl'].'.php'; 
	}
	header('Location: ?login'); 
  }else{
  	if($_SERVER['QUERY_STRING']=='login'){ 
	   header('Location: ./'); 
	}
	include 'header/head.php'; 
	if($_SERVER['QUERY_STRING']){
		include 'views/'.$arr_query['userurl'].'.php'; 
	}else{
		include 'views/index.php'; 
	}
		 include 'header/foot.php'; 
}