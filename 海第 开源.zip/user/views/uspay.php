<?php
$title='余额充值';
if(isset($_GET['htcx'])){
$trade_no=$_GET['trade_no'];
$srow=$DB->query("SELECT * FROM pay_order WHERE trade_no='$trade_no' limit 1 for update")->fetch();
  if($srow['status']==1){
	$czrss=1;
  }
}
if($_POST){



$alipay_config['partner']		= $conf['web_id'];

$rs=$DB->query("SELECT * FROM pay_user WHERE id='{$conf['web_id']}' limit 1")->fetch();

if (!$rs) {
	sysmsg('抱歉！暂时无法进行充值。');
}

$alipay_config['key']			= $rs['key'];
//签名方式 不需修改
$alipay_config['sign_type']    = strtoupper('MD5');

//字符编码格式 目前支持 gbk 或 utf-8
$alipay_config['input_charset']= strtolower('utf-8');

//访问模式,根据自己的服务器是否支持ssl访问，若支持请选择https；若不支持请选择http
$alipay_config['transport']    = $conf['protocol'];

//支付API地址
$alipay_config['apiurl']    = $payurl;

require_once(SYSTEM_ROOT."pay/epay/epay_submit.class.php");

//商户订单号
$out_trade_no = date("YmdHis").mt_rand(100,999);

$parameter = array(
"pid" => trim($alipay_config['partner']),
"type" => $_POST['type'],
"uid" => $pid,
"notify_url"	=> $alipay_config['apiurl'].'user/?uspay&htcx',
"return_url"	=> $alipay_config['apiurl'].'user/?uspay&htcx',
"out_trade_no"	=> $out_trade_no,
"name"	=> '余额充值',
"money"	=> $_POST['money'],
"sitename"	=> $conf['web_name']
);

//建立请求
$alipaySubmit = new AlipaySubmit($alipay_config);
$html_text = $alipaySubmit->buildRequestForm($parameter);
echo $html_text;

}


$list=$DB->query("SELECT * FROM pay_money WHERE uid={$pid} and name='充值' order by id desc limit 5")->fetchAll();

?>
 <div id="content" class="app-content" role="main">
    <div class="app-content-body ">
<div class="col-md-12" style="margin-top: 20px;">
     <ul class="breadcrumb bg-white b-a">
          <li><a href="./"><i class="fa fa-home"></i> 商户中心</a></li>
          <li class="active"><?php echo $title;?></li>
      </ul>
</div>



<?php if($czrss==1){?>

<div class="col-md-12" style="margin-bottom: 20px">
<div class="bg-white">
  <div class="developer-train-block">
    <div class="titleBar">
      <h3 class="caption"><?php echo $paycgico;?></h3>
      <p class="descript">恭喜你！充值成功 <strong style="color: #f05050;"><?php echo $_GET['money'];?></strong> 元</p>
      <a href="?uspay"><button class="btn btn-rounded btn-sm btn-info"><i class="fa fa-fw fa-angle-double-left "></i>返回</button></a>
    </div>
  </div>
</div>
</div>
<?php }else{ ?>
<div class="col-md-12" style="margin-bottom: 20px">
<div class="bg-white">
  <div class="developer-train-block">
    <div class="titleBar">
      <h3 class="caption">商户余额充值区</h3>
      <p class="descript"><?php echo $conf['web_name'];?>提供商户自助充值 余额不满结算要求？ 来充一下就好来</p>
    </div>
  </div>
</div>
</div>
    <div class="col-sm-6">
    	<div class="panel panel-default" style="height: 404PX;">
				<div class="col-lg-3"></div>
				<div class="col-lg-12" style="margin-top:30px;">
					<div class="alert alert-success" style="background-color: #edf1f2; border-color: #eee;">
						<strong>温馨提示：</strong> 最小充值金额1元
					</div>
					<div class="table-responsive">
						<table width="100%" class="table">
							<tbody>
								<tr>
									<td>用户账号</td>
									<td><?php echo $userrow['user'];?></td>
								</tr>
								<tr>
									<td>账户余额</td>
									<td><?php echo $userrow['money'];?>元</td>
								</tr>
							</tbody>
						</table>
					</div>
					<ul class="nav nav-tabs">
						<li class="active"><a href="#alipay" data-toggle="tab" aria-expanded="true"><img height="20px" src="https://template.down.swap.wang/swap/yun/T1HHFgXXVeXXXXXXXX.png" alt="支付宝支付" border="0"></a></li>
						<li class=""><a href="#palpay" data-toggle="tab" aria-expanded="false"><img height="20px" src="../assets/img/qqpay.jpg" alt="QQ支付" border="0"></a></li>
						<li class=""><a href="#weixin" data-toggle="tab" aria-expanded="false"><img height="20px" src="https://template.down.swap.wang/swap/yun/weixinpay.png" alt="微信支付" border="0"></a></li>
					</ul>
					<div class="tab-content">
						<div id="alipay" class="tab-pane panel-body active">
							<label>充值金额</label>
							<form  method="post">
								<input name="uspay" type="hidden" value="1">
								<input name="cz" type="hidden" value="1">
								<input name="type" type="hidden" value="alipay">
								<input value="1" name="money" type="text" class="form-control">
								<p style="text-align:center;margin:2em auto"><input type="submit" class="btn btn-yss" style="background-color: #23b7e5;color: #fff" value="去支付>>"></p>
							</form>
						</div>
						<div id="palpay" class="tab-pane panel-body">
							<!-- <div class="alert alert-info"><strong>充值提示：</strong> 接口已被关闭</div> -->
							<label>充值金额</label>
							<form  method="post">
								<input name="uspay" type="hidden" value="1">
								<input name="cz" type="hidden" value="1">
								<input name="type" type="hidden" value="qqpay">
								<input value="1" name="money" type="text" class="form-control">
								<p style="text-align:center;margin:2em auto"><input type="submit" class="btn btn-yss" style="background-color: #23b7e5;color: #fff" value="去支付>>"></p>
							</form>
						</div>
						<div id="weixin" class="tab-pane panel-body">
							<!-- <div class="alert alert-info"><strong>充值提示：</strong> 接口已被关闭</div> -->
							<label>充值金额</label>
							<form  method="post">
								<input name="uspay" type="hidden" value="1">
								<input name="cz" type="hidden" value="1">
								<input name="type" type="hidden" value="wxpay">
								<input value="1" name="money" type="text" class="form-control">
								<p style="text-align:center;margin:2em auto"><input type="submit" class="btn btn-yss" style="background-color: #23b7e5;color: #fff" value="去支付>>"></p>
							</form>
						</div>
					</div>
				</div>
				<div class="col-lg-3"></div>
			</div>
		</div>

	<div class="col-md-6">
      <div class="panel b-a">
        <div class="panel-heading b-b b-light">  
          <span class="badge bg-warning pull-right"><?php echo $notices;?></span>
          <a class="font-bold">充值记录</a>
        </div>
        <ul class="list-group list-group-lg no-bg auto">
       <?php foreach($list as $res){ ?>
         <li class="list-group-item clearfix">
            <span class="pull-left thumb-sm avatar m-r">
            <?php echo $czicon;?>
            </span>
            <span class="clear">
              <span>充值金额：<?php echo $res['money'];?> </span>
              <small class="text-muted clear text-ellipsis">充值时间：<?php echo $res['time'];?></small>
            </span>
          </li>
         <?php } ?>
        </ul>
    </div>
  </div>
<?php } ?>
</div>
</div>
