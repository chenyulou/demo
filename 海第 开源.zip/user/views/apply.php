<?php
$title='申请提现';
if($conf['settle_open']!=1)exit('抱歉！暂不支持商户手动结算。');
$list=$DB->query("SELECT * FROM pay_money WHERE uid={$pid} and name='提现' order by id desc limit 5")->fetchAll();
?>

<div id="content" class="app-content" role="main">
    <div class="app-content-body ">
<div class="col-md-12" style="margin-top: 20px;">
     <ul class="breadcrumb bg-white b-a">
          <li><a href="./"><i class="fa fa-home"></i> 商户中心</a></li>
          <li class="active"><?php echo $title;?></li>
      </ul>
</div>
<div class="col-md-12" style="margin-bottom: 20px">
<div class="bg-white">
  <div class="developer-train-block">
    <div class="titleBar">
      <h3 class="caption">商户余额自助提现区</h3>
      <p class="descript"><?php echo $conf['web_name'];?>商户余额自助提现满足你一天多次结算</p>
    </div>
  </div>
</div>
</div>
	 <div class="col-sm-12">
		<div class="alert ng-isolate-scope alert-warning alert-dismissable">
	    <div ng-transclude=""><span class="ng-binding ng-scope"><span class="glyphicon glyphicon-info-sign"></span>注意事项：请核实以上信息是否正确，提交申请后余额将在1-7个工作日转入你指定的账户。若有问题请及时联系客服，我们7X24小时在线。</span></div>
	   </div>
	</div>
    <div class="col-sm-6">
    	<div class="panel panel-default" style="height: 404PX;">
				<div class="col-lg-3"></div>
				<div class="col-lg-12" style="margin-top:25px;">
					<div class="font-bold" style="padding: 10px 15px;">提现信息：</div>
					<div class="table-responsive">
						<table width="100%" class="table">
							<tbody>
								<tr>
									<td>提现账号</td>
									<td><?php echo $userrow['user'];?></td>
								</tr>
								<tr>
									<td>商户姓名</td>
									<td><?php echo $userrow['username']?></td>
								</tr>
								<tr>
									<td>我的余额</td>
									<td><?php echo $userrow['money'];?></td>
								</tr>
								<tr>
									<td>提现手续费</td>
									<td><?php echo round($conf['settle_rate']*100,2);?>%</td>
								</tr>
								<tr>
									<td>金额范围</td>
									<td><?php echo $conf['settle_money'];?>~<?php echo $conf['settle_money_max'];?> 元</td>
								</tr>
							</tbody>
						</table>
					</div>
					<p style="text-align:center;margin:2em auto;">

					<form action="" id="tixu" method="POST">

					<input type="text" name="money" value="" class="default form-control" placeholder="提现金额" style="width: 85px;float: left; margin-right: 10px;">

					<input type="password" name="zfmm" value="" class="default form-control" placeholder="支付密码" style="width: 130px;float: left;">

					<input type="button" class="btn btn-yss tixs" value="提交申请" style="float: right;background-color: #23b7e5;color: #fff">

					</form>

					</p>

				</div>

			</div>
		</div>
	<div class="col-md-6">
      <div class="panel b-a">
        <div class="panel-heading b-b b-light">  
          <span class="badge bg-warning pull-right"><?php echo $notices;?></span>
          <a class="font-bold">提现记录</a>
        </div>
        <ul class="list-group list-group-lg no-bg auto">
       <?php foreach($list as $res){ ?>
         <li class="list-group-item clearfix">
            <span class="pull-left thumb-sm avatar m-r">
            <?php echo $txicon;?>
            </span>
            <span class="clear">
              <span>提现金额：<?php echo $res['money'];?> </span>
              <small class="text-muted clear text-ellipsis">提现时间：<?php echo $res['time'];?></small>
            </span>
          </li>
         <?php } ?>
        </ul>
    </div>
  </div>
	 </div>
   </div>
<?php include 'foot.php';?>






