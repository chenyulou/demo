
<?php 
$title='更多公告';

$numrows=$DB->query("SELECT * from pay_notice where 1 order by time desc")->rowCount();
if(isset($_GET['pagesize'])){
$pagesize=$_GET['pagesize'];
}else{
$pagesize=10;
}
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);

$notices=$DB->query("SELECT count(*) from pay_notice ")->fetchColumn();

$list=$DB->query("SELECT * FROM pay_notice where 1 order by time desc limit $offset,$pagesize")->fetchAll();

 ?>

  <div id="content" class="app-content" role="main">
  <div class="col-md-12" style="margin-top: 20px;">
     <ul class="breadcrumb bg-white b-a">
          <li><a href="./"><i class="fa fa-home"></i> 商户中心</a></li>
          <li class="active"><?php echo $title;?></li>
      </ul>
</div>
<div class="col-md-12">
      <div class="panel b-a">
        <div class="panel-heading b-b b-light">  
          <span class="badge bg-warning pull-right"><?php echo $notices;?></span>
          <a href="" class="font-bold">平台公告</a>
        </div>
        <ul class="list-group list-group-lg no-bg auto">
       <?php foreach($list as $res){ ?>
         <li class="list-group-item clearfix shggck" types="<?php echo $res['title'];?>" manes="<?php echo $res['name'];?>">
            <span class="pull-left thumb-sm avatar m-r">
            <img src="<?php echo qqimg($conf['web_qq']);?>" alt="站长">
              <i class="on b-white bottom"></i>
            </span>
            <a href="#m<?php $res['id'];?>" data-toggle="modal">
            <span class="clear">
              <span><?php echo $res['title'];?></span>
              <small class="text-muted clear text-ellipsis"><?php echo $res['name'];?></small>
            </span>
            </a>
          </li>
         <?php } ?>
        </ul>
<footer class="panel-footer">
    <div id="demo7"></div>
</footer>
<script src="/assets/layui/layui.js"></script>
<script>
layui.use(['laypage', 'layer'], function(){
var laypage = layui.laypage,
layer = layui.layer; 
laypage.render(
  {
    elem: 'demo7',
    count: <?php echo $numrows?> ,
    curr: <?php echo $page?> ,
    limit:<?php echo $pagesize?>,
    layout: ['count', 'prev', 'page', 'next', 'limit', 'refresh', 'skip'],
    jump: function(obj,first){
      if(first!=true){
            var currentPage = obj.curr;
            window.location.href ="?order&page="+currentPage+"&pagesize="+obj.limit+"<?php echo $link;?>";
       }
   }
});
});
</script>
  </div>       
</div>