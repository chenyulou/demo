<?php
$title='用户中心';
?>
<?php
$orders=$DB->query("SELECT count(*) from pay_order WHERE pid={$pid}")->fetchColumn();

$lastday=date("Y-m-d",strtotime("-1 day")).' 00:00:00';
$lastdays=date("Y-m-d",strtotime("-7 day"));
$today=date("Y-m-d").' 00:00:00';
$order_today=$DB->query("SELECT sum(money) from pay_order where pid={$pid} and status=1 and endtime>='$today'")->fetchColumn();

$order_lastday=$DB->query("SELECT sum(money) from pay_order where pid={$pid} and status=1 and endtime>='$lastday' and endtime<'$today'")->fetchColumn();

#统计表数据获取
$zhexiandata = [];
$zhexiandatakey = [];
$zhexiandatavalue = [];
$zhexiandatamoney = [];
$zhexiandatacgorder = [];
$zhexiandatasborder = [];
for($i=0;$i<count($begin_timedata);$i++)
{
  $rss = $DB->query("SELECT count(money) as money from pay_order where addtime >= '".$begin_timedata[$i]."' and addtime <= '".$end_timedata[$i]."' and  pid={$pid} ")->fetch();
  $rsss = $DB->query("SELECT sum(money) as money from pay_order where addtime >= '".$begin_timedata[$i]."' and addtime <= '".$end_timedata[$i]."' and  pid={$pid} and status=1")->fetch();
  $rsscg = $DB->query("SELECT count(money) as money from pay_order where endtime >= '".$begin_timedata[$i]."' and endtime <= '".$end_timedata[$i]."' and  pid={$pid} and status=1")->fetch();
  $rsssb = $DB->query("SELECT count(money) as money from pay_order where addtime >= '".$begin_timedata[$i]."' and addtime <= '".$end_timedata[$i]."' and  pid={$pid} and status<>1")->fetch();
  $zhexiandata[] = $rss["money"];

  $zhexiandatakey[] = $end_timedata2[$i];

  $zhexiandatavalue[] = $rss["money"];
  $zhexiandatamoney[] = round($rsss["money"],2);
  $zhexiandatacgorder[] = $rsscg["money"];
  $zhexiandatasborder[] = $rsssb["money"];
}


$rs=$DB->query("SELECT * from pay_settle where pid={$pid} and status=1");
$settle_money=0;
while($row = $rs->fetch())
{
  $settle_money+=$row['money'];
}

$log = $DB->query("SELECT * FROM  `pay_log` where uid={$userrow['id']} ORDER BY `date` DESC LIMIT 1,2")->fetch();

$list=$DB->query("SELECT * FROM pay_notice order by time desc limit 4")->fetchAll();

$notices=$DB->query("SELECT count(*) from pay_notice ")->fetchColumn();

$zg_wxpay=$DB->query("SELECT sum(money) from pay_order where pid={$pid} and type = 'wxpay' and status=1")->fetchColumn();
$zg_alipay=$DB->query("SELECT sum(money) from pay_order where pid={$pid} and type = 'alipay' and status=1")->fetchColumn();
$zg_qqpay=$DB->query("SELECT sum(money) from pay_order where pid={$pid} and type = 'qqpay' and status=1")->fetchColumn();

$jt_wxpay=$DB->query("SELECT sum(money) from pay_order where pid={$pid} and type = 'wxpay' and status=1 and endtime>='$today'")->fetchColumn();
$jt_alipay=$DB->query("SELECT sum(money) from pay_order where pid={$pid} and type = 'alipay' and status=1 and endtime>='$today'")->fetchColumn();
$jt_qqpay=$DB->query("SELECT sum(money) from pay_order where pid={$pid} and type = 'qqpay' and status=1 and endtime>='$today'")->fetchColumn();

$zt_wxpay=$DB->query("SELECT sum(money) from pay_order where pid={$pid} and type = 'wxpay' and status=1 and endtime>='$lastday' and endtime<'$today'")->fetchColumn();
$zt_alipay=$DB->query("SELECT sum(money) from pay_order where pid={$pid} and type = 'alipay' and status=1 and endtime>='$lastday' and endtime<'$today'")->fetchColumn();
$zt_qqpay=$DB->query("SELECT sum(money) from pay_order where pid={$pid} and type = 'qqpay' and status=1 and endtime>='$lastday' and endtime<'$today'")->fetchColumn();


?>
 <div id="content" class="app-content" role="main">
    <div class="app-content-body ">
<div class="wrapper-md control">
     <ul class="breadcrumb bg-white b-a">
          <li><a href="./"><i class="fa fa-home"></i> 商户中心</a></li>
          <li class="active">首页</li>
      </ul>
<!-- stats -->
      <div class="row">
        <div class="col-sm-6">
          <div class="panel panel-default" style="border-radius: 12px;">
            <div class="panel-heading" style="background-color: #23b7e5;color:#fff;">
              <div class="clearfix">
                <a class="pull-left avatar b-3x m-r">
                 <img src="<?php echo qqimg($userrow['qq_uid']);?>" style="width: 90px;">
                </a>
                <div class="clear">
                  <div class="h3 m-t-xs m-b-xs">
                    <p><?php echo $userrow['username'];?></p>
                  </div>
                  <small class="text-muted" style="color:#fff;"><p>上次登陆：<?php echo $log['date'];?></p></small>
                  <small class="text-muted" style="color:#fff;"><p>登陆地址：<?php echo $log['city'];?></p></small>
                </div>
              </div>
            </div>
            <div class="list-group no-radius alt">
              <p class="list-group-item">
                <span class="badge bg-light"><?php echo $pid;?></span>
                <i class="fa fa-user-md fa-fw text-muted"></i> 
                商户PID
              </p>
              <p class="list-group-item">
                <span class="badge bg-light"><?php echo $userrow['email'];?></span>
                <i class="fa fa-envelope fa-fw text-muted"></i> 
                商户邮箱
              </p>
              <p class="list-group-item">
                <span class="badge bg-light"><?php echo $userrow['qq_uid'];?></span>
                <i class="fa fa-qq fa-fw text-muted"></i> 
                商户QQ
              </p>
              <p class="list-group-item" style="border-radius: 0px 0px 12px 12px;">
                <span class="badge bg-light">
                  <a href="#keycz" data-toggle='modal' title="商户KEY重置">
                  <i class="icon-reload"></i>
                  </a>
                </span>
                <span class="badge bg-light"><?php echo $userrow['key'];?></span>
                <i class="fa fa-sliders fa-fw text-muted"></i>  
                商户KEY
              </p>
            </div>
          </div>
        </div>

        <div class="col-md-6">
          <div class="row row-sm text-center">

            <div class="col-xs-6 m-b-md">
              <div class="r bg-light dker item hbox no-border">
                <div id="uidd" class="r bg-light dker item hbox no-border">
                <div class="col w-xs v-middle" style="width: 50px;">
                  <?php echo $ddicon;?>
                </div>
              <div id="uidd" class="col dk padder-v r-r">
                <div class="h1 text-info font-thin h3"><?php echo $orders?></div>
                <span class="text-info text-xs">订单总数(笔)</span>
              </div>
            </div>
          </div>
        </div>

            <div class="col-xs-6 m-b-md">
              <div class="r bg-light dker item hbox no-border">
                <div id="uijs" class="r bg-light dker item hbox no-border">
                <div class="col w-xs v-middle" style="width: 50px;">
                  <?php echo $jsicon;?>
                </div>
              <div id="uijs" class="col dk padder-v r-r">
                <span class="text-white font-thin h3 block"><?php echo round($settle_money,2);?></span>
                <span class="text-white text-xs">已结算余额(元)</span>
              </div>
            </div>
          </div>
        </div>

            <div class="col-xs-6 m-b-md">
              <div class="r bg-light dker item hbox no-border">
                <div id="uisr" class="r bg-light dker item hbox no-border">
                <div class="col w-xs v-middle" style="width: 60px;">
                  <?php echo $jricon;?>
                </div>
              <div id="uisr" class="col dk padder-v r-r">
                <span class="text-white font-thin h3 block"><?php echo round($order_today,2);?></span>
                <span class="text-white text-xs">今日收入(元)</span>
              </div>
            </div>
          </div>
        </div>

            <div class="col-xs-6 m-b-md">
              <div class="r bg-light dker item hbox no-border">
                <div id="uidd" class="r bg-light dker item hbox no-border">
                <div class="col w-xs v-middle " style="width: 60px;">
                  <?php echo $zricon;?>
                </div>
              <div id="uidd" class="col dk padder-v r-r">
                <div class="font-thin h3"><?php echo round($order_lastday,2);?></div>
                <span class="text-muted text-xs">昨日收入(元)</span>
              </div>
            </div>
          </div>
        </div>

            <div class="col-xs-12 m-b-md">
              <div class="r bg-light dker item hbox no-border">
                <div class="col w-xs v-middle">
                  <?php echo $xsicon;?>
                </div>
                <div class="col dk padder-v r-r" style="background-color: #fff;">
                  <div class="text-primary-dk font-thin h1"><span><?php echo round($userrow['money'],2);?></span></div>
                  <span class="text-muted text-xs">我的可用余额(元)</span>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>

<div class="row">
<div class="col-md-6">
  <div class="panel wrapper">
      <div id="center-zhexian" style="width:100%;height:300px"></div>
  </div>
</div>

<style type="text/css">
  
 .qqr {
    border-radius: 12px 12px 0px 0px !important;
 }
 .qqx {
  border-radius: 12px 12px 0px 0px !important;
  background-color: #fff !important;
  padding: 10px !important;
  box-shadow: 0px 8px 20px 0px rgba(0, 0, 0, 0.14) !important;
 }
 .wxr {
    border-radius: 0px !important;
    background-color: #fff !important;
    padding: 11px !important;
    border-style: solid;
    border-top-width: 1px;
    border-bottom-width: 1px;
    box-shadow: 0px 8px 20px 0px rgba(0, 0, 0, 0.14) !important;
 }

 .alir {
  border-radius: 0px 0px 12px 12px !important;
  background-color: #fff !important;
  padding: 10px !important;
  box-shadow: 0px 8px 20px 0px rgba(0, 0, 0, 0.14) !important;
 }

</style>

<div class="col-md-6">
    <div class="row row-sm text-center" style="margin-bottom: 20px;">
      <div class="col-xs-12">
        <div class="r bg-light dker item hbox no-border qqr">
          <div class="r bg-light dker item hbox no-border qqx">
          <div class="col w-xs v-middle" style="width: 60px;">
            <?php echo $QQ;?>
          </div>
        <div class="col dk padder-v r-r" style="background-color: #fff;">
          <span class="text-white font-thin h1 block" style="color: #fad733;"><?php echo round($zg_qqpay,2);?></span>
          <span class="text-white text-xs" style="color: #fad733;">QQ通道收入(元)</span>
        </div>
      </div>
    </div>
  </div>
      <div class="col-xs-12">
        <div class="r bg-light dker item hbox no-border wxr">
          <div class="col w-xs v-middle " style="width: 60px; background-color: #fff;">
            <?php echo $WX;?>
          </div>
        <div class="col dk padder-v r-r" style="background-color: #fff;">
          <div class="font-thin h1" style="color: #27c24c;"><?php echo round($zg_wxpay,2);?></div>
          <span class="text-muted text-xs" style="color: #27c24c;">微信通道收入(元)</span>
        </div>
    </div>
  </div>

      <div class="col-xs-12">
        <div class="r bg-light dker item hbox no-border alir">
          <div class="col w-xs v-middle" style="width: 60px;">
            <?php echo $ZFB;?>
          </div>
          <div class="col dk padder-v r-r" style="background-color: #fff;">
            <div class="text-primary-dk font-thin h1" style="color: #23b7e5;"><span><?php echo round($zg_alipay,2);?></span></div>
            <span class="text-muted text-xs" style="color: #23b7e5;">支付宝通道收入(元)</span>
          </div>
        </div>
      </div>
    </div>
</div>
</div>

<div class="row">
<div class="col-md-6">
  <div class="panel wrapper">
    <div id="center-simple" style="width:100%;height:288px"></div>
  </div>
</div>


<div class="col-md-6">
  <div class="panel b-a">
    <div class="panel-heading b-b b-light">
      <a href="?shgg" class="badge bg-light pull-right">查看更多</a>  
      <span class="font-bold">平台公告</span>
      <span class="badge bg-warning "><?php echo $notices;?></span>
    </div>
    <ul class="list-group list-group-lg no-bg auto">
   <?php foreach($list as $res){ ?>
     <li class="list-group-item clearfix shggck" types="<?php echo $res['title'];?>" manes="<?php echo $res['name'];?>">
        <span class="pull-left thumb-sm avatar m-r">
        <img src="<?php echo qqimg($conf['web_qq']);?>" alt="站长">
          <i class="on b-white bottom"></i>
        </span>
        <a href="#m<?php $res['id'];?>" title="点击查看完整内容" data-toggle="modal">
        <span class="clear">
          <span><?php echo $res['title'];?></span>
          <small class="text-muted clear text-ellipsis"><?php echo $res['name'];?></small>
        </span>
        </a>
      </li>
     <?php } ?>
    </ul>
  </div>       
</div>


</div>
</div>
<div class="modal fade" align="left" id="keycz" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span></button>
      <h4 class="modal-title" id="myModalLabel">KEY重置</h4>
      </div>
      <div class="modal-body">
      <form action="" method="POST">
      <div class="form-group">
      <label>请选择重置方式:</label>
      <select class="form-control" id="key-type" name="type">
          <option value="1">自动生成</option>
          <option value="2">手动生成</option>
      </select>
      </div>
      <div id="keys" class="form-group" style="display:none;">
      <label>请输入32位key:</label><br>
      <input type="text" class="form-control" id="key-name" name="key" value="" required>
      </div>
      <div class="form-group">
      <input type="button" class="btn btn-info btn-block keycz" value="保存">
      </div>
      </form>
      </div>
    </div>
    </div>
  </div>


