<?php
$title='订单记录';
?>
 <div id="content" class="app-content" role="main">
 	<div class="col-md-12" style="margin-top: 20px;">
     <ul class="breadcrumb bg-white b-a">
          <li><a href="./"><i class="fa fa-home"></i> 商户中心</a></li>
          <li class="active"><?php echo $title;?></li>
      </ul>
</div>
<style type="text/css">
  tr {
    background-color: #ffffff!important;
  }
</style>
<div class="app-content-body ">
<div class="wrapper-md control">
<?php if(isset($msg)){?>
<div class="alert alert-info">
	<?php echo $msg?>
</div>
<?php }?>
	<div class="panel panel-default">
	<div class="panel-heading font-bold">
		订单记录	
	</div>
  <form style="padding: 10px 0 0 0;">
    <div style="float: left; position: relative;">
        <label class="layui-form-label" style="padding: 9px 11px;">订单搜索</label>
      <input style="width: auto;" type="text" id="select_orderId" name="select_orderId" lay-verify="required" placeholder="请输入交易号或商户订单号" autocomplete="off" class="layui-input">
    </div>
    <button type="button" class="layui-btn" id="searchBtn" data-type="getInfo" style="float: left;">搜索</button>
  </form>
<table class="layui-hide" id="test" style="width: 100%;display:inline-block !important;"></table>
</div>
</div>
</div>
</div>
<script src="http://www.jq22.com/jquery/jquery-1.10.2.js"></script>
<script type="text/javascript" src="/assets/layui/layui.js"></script>
<script>
var tableIns;
layui.use('table', function(){
  var table = layui.table;
  
  tableIns = table.render({
    elem: '#test'
    ,url:'./jsajax/ajax2.php?act=order'
    ,page: { //支持传入 laypage 组件的所有参数（某些参数除外，如：jump/elem） - 详见文档
      layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'] //自定义分页布局
      //,curr: 5 //设定初始在第 5 页
      ,groups: 1 //只显示 1 个连续页码
      ,first: false //不显示首页
      ,last: false //不显示尾页
      
    }
    ,cols: [[
      {field:'0', title: '交易号', sort: true, minWidth: 180,templet: function(d){
        return d.trade_no;
      }}
      ,{field:'1', title: '商户订单号', sort: true, minWidth: 180,templet: function(d){
        return d.out_trade_no;
      }}
      ,{field:'10', width:130, title: '商品名称',templet: function(d){
        return d.name;
      }}
      ,{field:'11', width:130, title: '商品金额', sort: true,templet: function(d){
        return d.money;
      }}
      ,{field:'4', width:130, title: '支付方式',templet: function(d){
        return d.type;
      }}
      ,{field:'8', title: '创建时间', sort: true, minWidth: 180,templet: function(d){
        return d.addtime;
      }}
      ,{field:'9', title: '完成时间', sort: true, minWidth: 180,templet: function(d){
        return d.endtime;
      }}
      ,{field:'13', title: '支付IP', minWidth: 150,templet: function(d){
        return d.ip;
      }}
      ,{field:'14', width:80, title: '状态', templet: function(d){
        if(d.status==1){
          return '<font color=green>已支付</font>';
        }else{
          return '<font color=red>未支付</font>';
        }
      }}

      ,{field:'url', width:135, title: '操作', templet: function(d){
        var url = d.url;
        // console.log(d[3])

          return '<a href="'+url+'" target="_blank" rel="noreferrer">重新通知</a>';
      }}
    ]]
    
  });
});
//表单序列化成json对象
function serializeObject(dom){  
    var obj=new Object();  
    $.each($(dom).serializeArray(),function(index,param){  
        if(!(param.name in obj)){  
            obj[param.name]=param.value;  
        }  
    });  
    return obj;  
}; 
//搜索
$('#searchBtn').click(function(){
  var data = serializeObject('form');
  //重载表格
  tableIns.reload({
    where: data
    ,page: {
      curr: 1 //重新从第 1 页开始
    }
  });
})

</script>
</div>