<?php
$title='结算记录';
?>
 <div id="content" class="app-content" role="main">
 	<div class="col-md-12" style="margin-top: 20px;">
     <ul class="breadcrumb bg-white b-a">
          <li><a href="./"><i class="fa fa-home"></i> 商户中心</a></li>
          <li class="active"><?php echo $title;?></li>
      </ul>
</div>
<style type="text/css">
   tr {
    background-color: #ffffff!important;
  }
.layui-table, .layui-table-view {
    margin: -21px 0;
}

</style>
    <div class="app-content-body ">
<div class="wrapper-md control">
<?php if(isset($msg)){?>
<div class="alert alert-info">
	<?php echo $msg?>
</div>
<?php }?>
	<div class="panel panel-default">
		<div class="panel-heading font-bold">
			结算记录
		</div>
<table class="layui-hide" id="test" style="width: 100%;display:inline-block !important;"></table>

</div>
</div>
</div>
</div>
<script src="http://www.jq22.com/jquery/jquery-1.10.2.js"></script>
<script type="text/javascript" src="/assets/layui/layui.js"></script>


<script>
var tableIns;
layui.use('table', function(){
  var table = layui.table;
  
  tableIns = table.render({
    elem: '#test'
    ,url:'./jsajax/ajax2.php?act=settle'
    ,page: { //支持传入 laypage 组件的所有参数（某些参数除外，如：jump/elem） - 详见文档
      layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'] //自定义分页布局
      //,curr: 5 //设定初始在第 5 页
      ,groups: 1 //只显示 1 个连续页码
      ,first: false //不显示首页
      ,last: false //不显示尾页
      
    }

    ,cols: [[
      {field:'i', title: '排序', sort: true, minWidth: 80}
      ,{field:'3', title: '结算方式', minWidth: 130, templet: function(d){
        if(d.type==1){
          return '支付宝';
        }else if(d.type==2){
          return '微信';
        }else if(d.type==3){
          return 'QQ钱包';
        }else if(d.type==4){
          return '银行卡';
        }else{
          return '未知'
        }
      }}
      ,{field:'5', title: '结算账户', minWidth: 130,templet: function(d){
        return d.account;
      }}
      ,{field:'4', title: '用户姓名', minWidth: 130,templet: function(d){
        return d.username;
      }}
      ,{field:'7', title: '结算金额', sort: true, minWidth: 180,templet: function(d){
        return d.allmoney;
      }}
      ,{field:'6', title: '到账金额', sort: true, minWidth: 180,templet: function(d){
        return d.money;
      }}
      ,{field:'8', title: '结算手续', sort: true, minWidth: 180,templet: function(d){
        return d.fee;
      }}
      ,{field:'9', title: '结算时间', sort: true, minWidth: 180,templet: function(d){
        return d.time;
      }}
      ,{field:'10', title: '结算状态', minWidth: 130, templet: function(d){
        if(d.status==1){
          return '<font color=green>已结算</font>';
        }else if(d.status==2){
          return '<font color=red>未结算</font>';
        }else if(d.status==3){
          return '<font color=khaki>处理中</font>';
        }else if(d.status==4){
          return '<font color=firebrick>已驳回(</font><a href="#" onclick="ckbohuis(\''+d.transfer_result+'\')">查看</a>)';
        }else{
          return '未知'
        }
      }}
    ]]
    
  });
});
function ckbohuis(ckbohui){
layer.alert(ckbohui);
}
</script>

</div>
