<?php
$title='修改资料';

if(strlen($userrow['phone'])==11){
	$userrow['phone']=substr($userrow['phone'],0,3).'****'.substr($userrow['phone'],7,10);
}

?>
<style type="text/css">
.plugin-card {
    clear: both;
    margin-left: 0;
    margin-bottom: 20px;
    border-radius: 12px;
    box-shadow: 0px 8px 20px 0px rgba(0, 0, 0, 0.14) !important;
}
.btn-ys {
	color: #ffffff !important;
	background-color: #e40a0a;
    border-color: #e40a0a;
}
.btn-yss {
	color: #ffffff !important;
	background-color: #03A9F4;
    border-color: #03A9F4;
}
</style>
<div id="situation" value="">
	<div id="situations" value="">
   <div id="situationc" value="">
 <div id="content" class="app-content" role="main">

<div class="col-md-12" style="margin-top: 20px;">
     <ul class="breadcrumb bg-white b-a">
          <li><a href="./"><i class="fa fa-home"></i> 商户中心</a></li>
          <li class="active"><?php echo $title;?></li>
      </ul>
</div>

<div class="col-md-4">
<div class="plugin-card">
	<div class="plugin-card-top" style="min-height: 110px;">
		<span class="thickbox plugin-icon">
		<?php echo $sjicon;?>
		</span>
	<div class="name column-name" style="padding: 10px;margin-left: 100px;">
		<h4>手机绑定<?php if($userrow['phone']){echo '<i class="icon-check" style="color: #27c24c;margin-left:8px;"></i>';}?></h4>
	</div>
		<div class="desc column-description" style="margin-left: 100px;">
			<p>身份验证、快捷登录</p>
		</div>
	</div>
	<div class="plugin-card-bottom">
		<div class="vers column-rating">
			<?php 
			if($userrow['phone']){
				echo '<strong>'.$userrow['phone'].'</strong>';
			  }else{
				echo '<strong>未验证</strong>';
			 }
			?>
		</div>
		<div class="column-compatibility">
			<?php 
			if($userrow['phone']){
				echo '<a class="btn btn-success btn-xs">验证完成</a> <a href="#"  data-type="phone" class="btn btn-yss btn-xs checkbind">更换</a>';
			  }else{
				echo '<a href="#" class="btn btn-success btn-xs checkbind"  data-types="phone">立即绑定</a>';
			 }
			?>
		</div>
	</div>
</div>

<div class="plugin-card">
	<div class="plugin-card-top" style="min-height: 110px;">
		<span class="thickbox plugin-icon">
		<?php echo $yxicon;?>
		</span>
	<div class="name column-name" style="padding: 10px;margin-left: 100px;">
		<h4>邮箱绑定<?php if($userrow['email']){echo '<i class="icon-check" style="color: #27c24c;margin-left:8px;"></i>';}?></h4>
	</div>
		<div class="desc column-description" style="margin-left: 100px;">
			<p>身份验证、快捷登录</p>
		</div>
	</div>
	<div class="plugin-card-bottom">
		<div class="vers column-rating">
			<?php 
			if($userrow['email']){
				echo '<strong>'.$userrow['email'].'</strong>';
			  }else{
				echo '<strong>未验证</strong>';
			 }
			?>
		</div>
		<div class="column-compatibility">
			<?php 
			if($userrow['email']){
				echo '<a class="btn btn-success btn-xs">验证完成</a> <a href="#"  data-type="email" class="btn btn-yss btn-xs checkbind">更换</a>';
			  }else{
				echo '<a href="#" class="btn btn-success btn-xs checkbind" data-types="email">立即绑定</a>';
			 }
			?>
		</div>
	</div>
</div>

<div class="plugin-card">
	<div class="plugin-card-top" style="min-height: 110px;">
		<span class="thickbox plugin-icon">
		<?php echo $wxicon;?>
		</span>
	<div class="name column-name" style="padding: 10px;margin-left: 100px;">
		<h4>微信绑定<?php if($userrow['wxid']){echo '<i class="icon-check" style="color: #27c24c;margin-left:8px;"></i>';}?></h4>
	</div>
		<div class="desc column-description" style="margin-left: 100px;">
			<p>身份验证、快捷登录</p>
		</div>
	</div>
	<div class="plugin-card-bottom">
		<div class="vers column-rating">
			<?php 
			if($userrow['wxid']){
				echo '<strong>'.$userrow['wx_name'].'</strong>';
			  }else{
				echo '<strong>未验证</strong>';
			 }
			?>
		</div>
		<div class="column-compatibility">
			<?php 
			if($userrow['wxid']){
				echo '<a class="btn btn-success btn-xs">验证完成</a> <a href="#" class="btn btn-ys btn-xs weiqq" data-type="jdwx">解除</a>';
				}else{
				echo '<a href="#" class="btn btn-success btn-xs weiqq" data-type="wx">立即绑定</a>';
			 }
			?>
		</div>
	</div>
</div>

<div class="plugin-card">
	<div class="plugin-card-top" style="min-height: 110px;">
		<span class="thickbox plugin-icon">
		<?php echo $qqicon;?>
		</span>
	<div class="name column-name" style="padding: 10px;margin-left: 100px;">
		<h4>QQ绑定<?php if($userrow['qq_uid']){echo '<i class="icon-check" style="color: #27c24c;margin-left:8px;"></i>';}?></h4>
	</div>
		<div class="desc column-description" style="margin-left: 100px;">
			<p>身份验证、快捷登录</p>
		</div>
	</div>
	<div class="plugin-card-bottom">
		<div class="vers column-rating">
			<?php 
			if($userrow['qq_uid']){
				echo '<strong>'.urldecode($userrow['qq_name']).'</strong>';
			  }else{
				echo '<strong>未验证</strong>';
			 }
			?>
		</div>
		<div class="column-compatibility">
			<?php 
			if($userrow['qq_uid']){
				echo '<a class="btn btn-success btn-xs">绑定完成</a> <a href="#" class="btn btn-ys btn-xs weiqq" data-type="jdqq">解除</a>';
			  }else{
				echo '<a href="#" class="btn btn-success btn-xs weiqq" data-type="qq">立即绑定</a>';
			 }
			?>
		</div>
	</div>
</div>
</div>


  <div class="modal inmodal fade" id="myModalphone" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">关闭</span>
				</button>
				<h4 class="modal-title">验证密保信息</h4>
			</div>
			<div class="modal-body">
			<div class="list-group-item" style="margin-bottom: 20px;">密保手机：<?php echo $userrow['phone']?></div>
			<div class="input-group" style="margin-bottom: 20px;">
			<input type="text" name="code" placeholder="输入短信验证码" class="form-control" required>
			<a class="input-group-addon sendcode" data-type="phone" >获取验证码</a>
			</div>
			<button type="button" data-type="phone" date-situation="bind" class="btn btn-info btn-block verifycode">立即验证</button>
			<div id="embed-captcha"></div>
			</div>
		</div>
	</div>
</div>

  <div class="modal inmodal fade" id="myModalemail" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">关闭</span>
				</button>
				<h4 class="modal-title">验证密保信息</h4>
			</div>
			<div class="modal-body">
			<div class="list-group-item" style="margin-bottom: 20px;">密保邮箱：<?php echo $userrow['email']?></div>
			<div class="input-group" style="margin-bottom: 20px;">
			<input type="text" name="code2" placeholder="输入验证码" class="form-control" required>
			<a class="input-group-addon sendcode" data-type="email">获取验证码</a>
			</div>
			<button type="button" data-type="email" date-situation="bind" class="btn btn-info btn-block verifycode">立即验证</button>
			<div id="embed-captcha"></div>
			</div>
		</div>
	</div>
</div>


<div class="modal inmodal fade" id="myModal2" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">关闭</span>
				</button>
				<h4 class="modal-title">修改密保信息</h4>
			</div>
			<div class="modal-body">
				
				<div id="phonegk">
				<div class="list-group" style="margin-bottom: 20px;">
				<input type="text" name="phone_n" placeholder="输入新的手机号码" class="form-control" required>
				</div>

				<div class="input-group" style="margin-bottom: 20px;">
				<input type="text" name="code_n" placeholder="输入短信验证码" class="form-control" required>
				<a class="input-group-addon sendcode2">获取验证码</a>
				</div>
				</div>

				<div id="emailgk">
				<div class="list-group">
				<input type="email" name="email_n" placeholder="输入新的邮箱" class="form-control" required>
				</div>

				<div class="input-group" style="margin-bottom: 20px;">
				<input type="text" name="code_u" placeholder="输入验证码" class="form-control" required>
				<a class="input-group-addon sendcode2">获取验证码</a>
				</div>
				</div>

			
				<button type="button" id="editBind" class="btn btn-info btn-block">确定</button>
				<div id="embed-captcha"></div>
			</div>
		</div>
	</div>
</div>

<div class="modal inmodal fade" id="mmxg" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">关闭</span>
				</button>
				<h4 class="modal-title">修改密码信息</h4>
			</div>
			<div class="modal-body">
			  <form action="" id="mm" method="POST">
		      <div class="form-group">
		      <label>请输入旧密码:</label><br>
		      <input type="text" class="form-control" name="jpwd" value="" required>
		      </div>
		      <div class="form-group">
		      <label>请输入新密码:</label><br>
		      <input type="text" class="form-control" name="xpwd" value="" required>
		      </div>
		      <div class="form-group">
		      <label>请输再输入新密码:</label><br>
		      <input type="text" class="form-control" name="zpwd" value="" required>
		      </div>
		      <div class="form-group">
		      <input type="button" class="btn btn-info btn-block mmxg" value="保存">
		      </div>
		      </form>
				<div id="embed-captcha"></div>
				<i class="icon-question"></i> 若遗忘登录密码请联系客服找回！建议绑定QQ/微信
			</div>
		</div>
	</div>
</div>

<div class="modal inmodal fade" id="zfmm" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">关闭</span>
				</button>
				<h4 class="modal-title">修改支付密码信息</h4>
			</div>
			<div class="modal-body">
			  <form action="" id="zf" method="POST">
		      <div class="form-group">
		      <label>请输入旧支付密码:</label><br>
		      <input type="text" class="form-control" name="jpzf" value="" required>
		      </div>
		      <div class="form-group">
		      <label>请输入新支付密码:</label><br>
		      <input type="text" class="form-control" name="xpzf" value="" required>
		      </div>
		      <div class="form-group">
		      <label>请输再输入新支付密码:</label><br>
		      <input type="text" class="form-control" name="zpzf" value="" required>
		      </div>
		      <div class="form-group">
		      <input type="button" class="btn btn-info btn-block zfmmxg" value="保存">
		      </div>
		      </form>
				<div id="embed-captcha"></div>
				<i class="icon-question"></i> 支付密码默认是：123456 若遗忘请联系客服找回！
			</div>
		</div>
	</div>
</div>

<div class="col-md-8">
	<div class="panel panel-default">
		<div class="panel-heading font-bold">
			收款信息设置
		</div>
		<div class="panel-body">
			<form class="form-horizontal devform">

				<div class="form-group">
					<label class="col-sm-2 control-label">结算方式</label>
					<div class="col-sm-9">
						<select class="form-control" name="stype" default="<?php echo $userrow['settle_id']?>">
						<?php if($conf['stype_1']){?><option value="1">支付宝结算</option>
						<?php }if($conf['stype_2']){?><option value="2">微信结算</option>
						<?php }if($conf['stype_3']){?><option value="3">QQ钱包结算</option>
						<?php }if($conf['stype_4']){?><option value="4">银行卡结算</option>
						<?php }?></select>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-2 control-label" id="typename">收款账号</label>
					<div class="col-sm-9">
						<input class="form-control" type="text" name="account" value="<?php echo $userrow['account']?>">
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-2 control-label">真实姓名</label>
					<div class="col-sm-9">
						<input class="form-control" type="text" name="username" value="<?php echo $userrow['username']?>">
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-2 control-label">结算率费</label>
					<div class="col-sm-9">
						<input class="form-control" type="text" name="" value="<?php echo round($conf['settle_rate']*100,2).'%';?>" disabled>
					</div>
				</div>
				<div class="form-group">
				  <div class="col-sm-offset-2 col-sm-9"><input type="button" id="editSettle" value="保存信息" class="btn btn-info form-control"/><br/>
				 </div>
				</div>
			</form>
		</div>
	</div>
</div>



<div class="col-md-8">
	<div class="panel panel-default">
		<div class="panel-heading font-bold">
			基本信息设置
		</div>
		<div class="panel-body">
			<form class="form-horizontal devform">
				<div class="form-group">
					<label class="col-sm-2 control-label">行业类型</label>
					<div class="col-sm-9">
					<select class="form-control" name="accounts">
		              <option value="餐饮" <?=$userrow['accounts']=='餐饮'?"selected":""?>>餐饮</option>
		              <option value="线下零售" <?=$userrow['accounts']=='线下零售'?"selected":""?>>线下零售</option>
		              <option value="居民生活/商业服务" <?=$userrow['accounts']=='居民生活/商业服务'?"selected":""?>>居民生活/商业服务</option>
		              <option value="休闲娱乐" <?=$userrow['accounts']=='休闲娱乐'?"selected":""?>>休闲娱乐</option>
		              <option value="线上交易" <?=$userrow['accounts']=='线上交易'?"selected":""?>>线上交易</option>
		            </select>
		            </div>
		        </div>
				<div class="form-group">
					<label class="col-sm-2 control-label">网站域名</label>
					<div class="col-sm-9">
						<input class="form-control" type="text" name="url" value="<?php echo $userrow['url']?>">
					</div>
				</div>
				<div class="form-group">
             <label class="col-sm-2 control-label">登录密码</label>
             <div class="col-sm-9">
	              <div class="input-group">
	              <input type="text" class="form-control" value="* * * * * *" disabled>
	              <span class="input-group-addon" id="mmxgs" style="cursor:pointer;">修改</span>
	            </div>
	        </div>
			</div>
				<div class="form-group">
             <label class="col-sm-2 control-label">支付密码</label>
             <div class="col-sm-9">
	              <div class="input-group">
	              <input type="text" class="form-control" value="* * * * * *" disabled>
	              <span class="input-group-addon" id="zfmmgs" style="cursor:pointer;">重置</span>
	            </div>
	        </div>
			</div>
				<div class="form-group">
					<label class="col-sm-2 control-label">注册时间</label>
					<div class="col-sm-9">
						<input class="form-control" type="text" name="addtime" value="<?php echo $userrow['addtime']?>" disabled>
					</div>
				</div>
				
				<div class="form-group">
				  <div class="col-sm-offset-2 col-sm-9"><input type="button" id="editInfo" value="保存信息" class="btn btn-info form-control"/><br/>
				 </div>
				</div>
			</form>
		    </div>
		  </div>
	    </div>
	  </div>
	</div>
