<?php
$title='余额流向';
?>
 <div id="content" class="app-content" role="main">
 	<div class="col-md-12" style="margin-top: 20px;">
     <ul class="breadcrumb bg-white b-a">
          <li><a href="./"><i class="fa fa-home"></i> 商户中心</a></li>
          <li class="active"><?php echo $title;?></li>
      </ul>
</div>
<style type0="text/css">
   tr {
    background-color: #ffffff!important;
  }
.layui-table, .layui-table-view {
    margin: -21px 0;
}

</style>
    <div class="app-content-body ">
<div class="wrapper-md control">
<?php if(isset($msg)){?>
<div class="alert alert-info">
	<?php echo $msg?>
</div>
<?php }?>
	<div class="panel panel-default">
		<div class="panel-heading font-bold">
			流向记录&nbsp;(仅保留一个月内的记录)
		</div>
<table class="layui-hide" id="test" style="width: 100%;display:inline-block !important;"></table>

</div>
</div>
</div>
</div>



<script src="http://www.jq22.com/jquery/jquery-1.10.2.js"></script>
<script type="text/javascript" src="/assets/layui/layui.js"></script>


<script>
var tableIns;
layui.use('table', function(){
  var table = layui.table;
  
  tableIns = table.render({
    elem: '#test'
    ,url:'./jsajax/ajax2.php?act=money'
    ,page: { //支持传入 laypage 组件的所有参数（某些参数除外，如：jump/elem） - 详见文档
      layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'] //自定义分页布局
      //,curr: 5 //设定初始在第 5 页
      ,groups: 1 //只显示 1 个连续页码
      ,first: false //不显示首页
      ,last: false //不显示尾页
      
    }

    ,cols: [[
      {field:'i', title: '排序', sort: true, minWidth: 80}
      ,{field:'2', title: '流向类型', minWidth: 180,templet: function(d){
        return d.name;
      }}
      ,{field:'3', title: '流向金额', minWidth: 130,templet: function(d){
        return d.money;
      }}
      ,{field:'4', title: '流向后金额', sort: true, minWidth: 180,templet: function(d){
        return d.addmoney;
      }}
      ,{field:'5', title: '流向时间', sort: true, minWidth: 180,templet: function(d){
        return d.time;
      }}
    ]]
    
  });
});
</script>

</div>

