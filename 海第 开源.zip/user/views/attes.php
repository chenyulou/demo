<?php
$title='实名认证';
$sfzhm=substr($userrow['sfzhm'],0,3).'****'.substr($userrow['sfzhm'],15,18);
if ($conf['smrz']!=1) {
  exit();
}
?>
 <div id="content" class="app-content" role="main">
    <div class="app-content-body ">

<div class="col-md-12" style="margin-top: 20px;">
     <ul class="breadcrumb bg-white b-a">
          <li><a href="./"><i class="fa fa-home"></i> 商户中心</a></li>
          <li class="active"><?php echo $title;?></li>
      </ul>
</div>
<div class="col-md-12">
<div class="bg-white" style="margin-top: 20px;">
  <div class="developer-train-block">
    <div class="titleBar">
      <h3 class="caption">商户产品免签认证</h3>
      <p class="descript"><?php echo $conf['web_name'];?>提供专业的身份认证方式，助您账号提升安全定级，成就职场新机遇！</p>
    </div>
  </div>
</div>
    <div class="row developer-train">
      <?php if($conf['sfrz']==1){?>
      <div class="col-md-4 ">
        <div class="tile part4-layer">
          <div class="layer-figure">
            <h3 class="title">身份实名认证</h3>
          </div>
          <div class="layer-text">
            <p class="dev-text"><?php echo $conf['web_name'];?>精心打造专业的认证体系，为您扩展职场发展的机遇，成为您技术能力的证明。</p>
          </div>
            <?php if($userrow['sf_rz']==1){?>
              <div style="position: absolute; bottom: 30px; right: 35.842%; text-align: center;width: 100px; height: 32px;">
            <a href="#" data-toggle='modal'>
              <p style="color: #27c24c;"><i class="icon-check"></i> 已认证</p>
            </a>
          </div>
          <?php }else{?>
          <div class="buttond">
            <a href="#sfrz" data-toggle='modal'>
              <p>立即认证</p>
            </a>
          </div>
          <?php }?>
        </div>
      </div>
    <?php } ?>
      <?php if($conf['sjrz']==1){?>
      <div class="col-md-4 ">
        <div class="tile part4-layer">
          <div class="layer-figure">
            <h3 class="title">手机号实名认证</h3>
          </div>
          <div class="layer-text">
            <p class="dev-text"><?php echo $conf['web_name'];?>精心打造专业的认证体系，为账号安全十分保障，一键即可确认身份。</p>
          </div>
           <?php if($userrow['sj_rz']==1){?>
              <div style="position: absolute; bottom: 30px; right: 35.842%; text-align: center;width: 100px; height: 32px;">
            <a href="#" data-toggle='modal'>
              <p style="color: #27c24c;"><i class="icon-check"></i> 已认证</p>
            </a>
          </div>
          <?php }else{?>
          <div class="buttond">
            <a href="#sjrz" data-toggle='modal'>
              <p>立即认证</p>
            </a>
          </div>
          <?php }?>
        </div>
      </div>
    <?php }?>
      <?php if($conf['yhrz']==1){?>
      <div class="col-md-4 " style="margin-bottom: 20px;">
        <div class="tile part4-layer">
          <div class="layer-figure">
            <h3 class="title">银行卡实名认证</h3>
          </div>
          <div class="layer-text">
            <p class="dev-text">由浅入深的<?php echo $conf['web_name'];?>系统认证体系，银行认证必不可少，大额收钱分分钟。</p>
          </div>
             <?php if($userrow['yh_rz']==1){?>
              <div style="position: absolute; bottom: 30px; right: 35.842%; text-align: center;width: 100px; height: 32px;">
            <a href="#" data-toggle='modal'>
              <p style="color: #27c24c;"><i class="icon-check"></i> 已认证</p>
            </a>
          </div>
          <?php }else{?>
          <div class="buttond">
            <a href="#yhkrz" data-toggle='modal'>
              <p>立即认证</p>
            </a>
          </div>
          <?php }?>
        </div>
      </div>
    <?php }?>
    </div>
  </div>



<!--  -->

<div class="modal fade" align="left" id="sjrz" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span></button>
      <h4 class="modal-title" id="myModalLabel">手机认证</h4>
      </div>
      <div class="modal-body">
      <form action="" id="form_sjrz" method="POST">
      <div class="form-group">
      <label>手机号码:</label><br>
      <input type="text" class="form-control" name="phone" value="<?php echo $userrow['phone'];?>" disabled>
      </div>
      <div class="form-group">
      <label>请输入该持卡人姓名:</label><br>
      <input type="text" class="form-control" name="name" value="" required>
      </div>
      <div class="form-group">
      <label>请输入该持卡人身份证号码:</label><br>
      <input type="text" class="form-control" name="sfzhm" value="" required>
      </div>
      <div class="form-group">
      <?php if($userrow['phone']==''){?>
      <input type="button" class="btn btn-info btn-block" value="请先绑定手机号码" disadled>
      <?php }else{?>
      <input type="button" onclick="sjrz()" class="btn btn-info btn-block" value="点击认证">
      <?php }?>
      </div>
      </form>
          注意：认证失败超过3次则无法再进行认证，请认真填写。
    </div>
    </div>
  </div>
</div>


<div class="modal fade" align="left" id="sfrz" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span></button>
      <h4 class="modal-title" id="myModalLabel">身份认证</h4>
      </div>
      <div class="modal-body">
      <form action="" id="form_sfyz" method="POST">
      <div class="form-group">
      <label>请输入真实姓名:</label><br>
      <input type="text" class="form-control" name="name" value="" required>
      </div>
      <div class="form-group">
      <label>请输入你的身份证号码:</label><br>
      <input type="text" class="form-control" name="sfzhm" value="" required>
      </div>
      <div class="form-group">
      <input type="button" onclick="sfyz()" class="btn btn-info btn-block" value="点击认证">
      </div>
      </form>
          注意：认证失败超过3次则无法再进行认证，请认真填写。
    </div>
    </div>
  </div>
</div>

<div class="modal fade" align="left" id="yhkrz" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span></button>
      <h4 class="modal-title" id="myModalLabel">银行卡认证</h4>
      </div>
      <div class="modal-body">
      <form action="" id="form_yhkrz" method="POST">
      <div class="form-group">
      <label>姓名:</label><br>
      <input id="card" type="text" class="form-control" name="name" value="<?php echo $userrow['username'];?>" disabled>
      </div>
      <div class="form-group">
      <label>身份证:</label><br>
      <input id="card" type="text" class="form-control" name="sfzhm" value="<?php echo $sfzhm;?>" disabled>
      </div>
      <div class="form-group">
      <label>请输入该持卡人银行卡号:</label><br>
      <input type="text" class="form-control" name="yhkh" value="" required>
      </div>
      <div class="form-group">
      <label>请输入该银行卡类型:</label><a href="#" class="yhkrz">点击获取</a><br>
      <input id="ka" type="text" size="35" name="type" class="form-control"  value="" required>
      </div>
      <div class="form-group">
      <?php if($userrow['sf_rz']!=1){?>
        <input type="button" class="btn btn-info btn-block" value="请先完成身份认证" disadled>
      <?php }else{?>
      <input type="button" onclick="yhkyz()" class="btn btn-info btn-block" value="立即认证">
      <?php }?>
      </div>
      </form>
          注意：认证失败超过3次则无法再进行认证，请认真填写。
    </div>
    </div>
  </div>
</div>