<?php
$title='余额转账';
?>
 <div id="content" class="app-content" role="main">
    <div class="app-content-body ">
<div class="col-md-12" style="margin-top: 20px;">
     <ul class="breadcrumb bg-white b-a">
          <li><a href="./"><i class="fa fa-home"></i> 商户中心</a></li>
          <li class="active"><?php echo $title;?></li>
      </ul>
</div>
<div class="col-md-12" style="margin-bottom: 20px">
<div class="bg-white">
  <div class="developer-train-block">
    <div class="titleBar">
      <h3 class="caption">商户余额转账区</h3>
      <p class="descript"><?php echo $conf['web_name'];?>提供商户对商户转账功能给用户更好体验</p>
    </div>
  </div>
</div>
</div>
<div class="col-sm-12">
<div class="panel panel-default">
    <div class="panel-heading font-bold">                  
      余额转账
    </div>
    <div class="panel-body">
      <form class="form-inline ng-pristine ng-valid" id="shzz" role="form">
        <div class="form-group">
          <input type="text" class="form-control" name="pid" placeholder="请输入转账账号">
        </div>
        <div class="form-group">
          <input type="text" class="form-control" name="money" placeholder="请输入转账金额">
        </div>
        <div class="form-group">
          <input type="text" class="form-control" name="note" placeholder="备注">
        </div>
        <div class="form-group">
          <input type="password" class="form-control" name="zfmm" placeholder="请输入支付密码">
        </div>

       
          <button type="button" class="btn btn-success shzz">确认转账</button>
       
      </form>
    </div>
  </div>


<div class="panel panel-default">
    <div class="panel-heading font-bold">                  
      转账记录
    </div>
    	<div class="table-responsive" style="border-radius: 12px;">
        <table class="table table-striped">
          <thead><tr><th>排序</th><th>转账账号</th><th>转账金额</th><th>备注</th><th>转账时间</th><th>状态</th></tr></thead>
          <tbody>
<?php
$i=0;
$list=$DB->query("SELECT * FROM pay_accoun WHERE uid={$pid} order by id desc limit 10");
while($res = $list->fetch()){
$i++;
	echo '<tr><td>'.$i.'</td><td>'.$res['pid'].'</td><td>￥ <b>'.$res['money'].'</b></td><td><b>'.$res['note'].'</b></td><td>'.$res['time'].'</td><td>'.($res['status']==1?'<font color=green>已完成</font>':'<font color=red>未完成</font>').'</td></tr>';
}
?>
		  </tbody>
        </table>
      </div>
</div>  
</div>
<?php include 'foot.php';?>
