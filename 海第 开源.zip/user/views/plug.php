<?php
$title='插件列表';
$list=$DB->query("SELECT * FROM `pay_plug` ORDER BY `id` ASC")->fetchAll();

?>
 <div id="content" class="app-content" role="main">
    <div class="app-content-body ">
<div class="col-md-12" style="margin-top: 20px;">
     <ul class="breadcrumb bg-white b-a">
          <li><a href="./"><i class="fa fa-home"></i> 商户中心</a></li>
          <li class="active"><?php echo $title;?></li>
      </ul>
</div>
<div class="col-md-12" style="margin-bottom: 20px">
<div class="bg-white">
  <div class="developer-train-block">
    <div class="titleBar">
      <h3 class="caption">商户插件下载区</h3>
      <p class="descript"><?php echo $conf['web_name'];?>提供各大平台对接插件省去集成烦恼</p>
    </div>
  </div>
</div>
</div>
<?php if($list==NULL){ ?>
      <div class="filter-count"> 
       <div class="tab-content col-sm-4"> 
        <div class="plugin-card" onclick="alert"> 
         <div class="plugin-card-top  text-center"> 
          <div class="new-tag" style="margin-top: 10px;">
          </div> 
          <span class="thickbox"><?php echo $wuicon;?></span> 
         </div> 
         <div class="plugin-card-bottom"> 
          <div class="vers"> 
          <center>暂无插件，正在积极开发中</center> 
          </div> 
         </div> 
        </div> 
        <div class="clear"></div> 
       </div> 
      </div> 
<?php }?>

<?php foreach($list as $res){ ?>
      <div class="filter-count"> 
       <div class="tab-content col-sm-4"> 
        <div class="plugin-card" onclick="alert"> 
         <div class="plugin-card-top"> 
          <div class="new-tag">
           <div>
            HOT
           </div>
          </div> 
          <span class="thickbox plugin-icon"><img src="<?php echo $res['logimg'];?>" /></span> 
          <div class="name column-name"> 
           <h4><?php echo $res['name'];?></h4> 
          </div> 
          <div class="desc column-description"> 
           <p><?php echo $res['title'];?></p> 
           <p class="authors"> 开发者 <b class="label bg-primary"><?php echo $res['author'];?></b> </p> 
           <p class="authors"> 发布时间：<?php echo $res['time'];?> </p>
          </div> 
         </div> 
         <div class="plugin-card-bottom"> 
          <div class="vers column-rating"> 
          <strong>语言：</strong> <?php echo $res['type'];?>
          </div> 
          <div class="column-compatibility"> 
          <a  href="<?php echo $res['download'];?>" class="btn btn-success btn-xs">免费下载</a> 
          </div> 
         </div> 
        </div> 
        <div class="clear"></div> 
       </div> 
      </div> 
<?php }?>

  <!-- / content -->
 <?php include 'foot.php';?>