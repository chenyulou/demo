<?php
$C_Patch=$_SERVER['DOCUMENT_ROOT'];
require_once($C_Patch."/includes/common.php");
$appid='1002';
$appkey='dd25h6s6af96sSFqKI12ZIdvu56i0616';
$codeurl='https://open.sanhaoapi.cn/wechat/?appid='.$appid.'&appkey='.$appkey;
$data=file_get_contents($codeurl);
$data = json_decode($data, true);
$loginkey=$data['loginkey'];
$loginurl=$data['loginurl'];
?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>微信登录</title>
	<link href="//cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
	<script src="http://code.jquery.com/jquery-2.1.1.min.js"></script>
	<script src="/assets/layer/layer.js"></script>
	<script src="/assets/js/qrcode.min.js"></script>
</head>
<body>
<div class="col-xs-12 col-sm-10 col-md-8 col-lg-6 center-block" style="float: none;">
<div class="panel-body" style="text-align: center;">
<div class="row">
   <a><div class="qr-image text-center" id="qrcode" title="扫码登录" alt="扫码登录" style="height: 150px;"></div></a>
   <div  id="login">
        <span id="loginmsg">使用微信手机版扫描二维码</span><span id="loginload" style="padding-left: 10px;color: #790909;">.</span>
      </div>
		</div>
</div>
</div>
</div>
</body>
<script>
function jumurl(){
	window.parent.location.reload();
}
function GetUrlPara()
　　{
　　　　var url = document.location.toString();
　　　　var arrUrl = url.split("?");

　　　　var para = arrUrl[1];
　　　　return para;
　　}
$(document).ready(function(){
	var qrcode = new QRCode("qrcode", {
        text: "<?php echo $loginurl; ?>",
        width: 134,
        height: 134,
        colorDark: "#000000",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.H
    });
});
var int=self.setInterval("clock()",2000);//js定时器2秒请求1次
function clock(){
$.ajax({
type: "GET",
dataType: "json",
url: "https://open.sanhaoapi.cn/wechat/ajax.php?loginkey=<?php echo $loginkey;?>",
timeout: 2000, //ajax请求超时时间2s
//  data: {id: "1000"}, //post数据
success: function (data, textStatus) {
	var msg = '使用微信手机版扫描二维码';
    //从服务器得到数据，显示数据并继续查询
    if(data.code==0){
			msg='使用微信手机版扫描二维码';
		}
	   if(data.code==1){
	   	    test(data.encrypt);
			clearInterval(int);//清除定时器
	   }
	    if(data.code==2){
			msg='你已取消登录';
			clearInterval(int);//清除定时器
		}
	  if(data.code==3){
			msg='你已扫码成功，请确认登录';
    }
    $('#loginmsg').html(msg);

  }
 })
}
function test(encrypt){
	var url = GetUrlPara();
	if(url=='jieb'){
      var address = "/user/jsajax/ajax2.php?act=wxjieb";
	}else if(url=='bind'){
	  var address = "/user/jsajax/ajax2.php?act=wxbind";
	 }else{
	  var address = "/user/jsajax/ajax.php?act=wxlogin";
	 }
	$.ajax({
    type : "POST",
    url : address,
    data : {encrypt:encrypt},
    dataType : 'json',
    success : function(data) {
        if(data.code == 0){
            msg=data.msg;
            clearInterval(interval1);
            setTimeout(jumurl,3000)
        }else{
        	msg=data.msg;
        	clearInterval(interval1);
        }
        $('#loginmsg').html(msg);
    }
   });
}
function loginload(){
	if ($('#login').attr("data-lock") === "true") return;
	var load=document.getElementById('loginload').innerHTML;
	var len=load.length;
	if(len>2){
		load='.';
	}else{
		load+='.';
	}
	document.getElementById('loginload').innerHTML=load;
}
$(document).ready(function(){
	interval1=setInterval(loginload,1000);
});
</script>
</html>


