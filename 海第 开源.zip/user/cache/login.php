<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<title>登录 | <?php echo $conf['web_name']?></title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css" />
<link rel="stylesheet" href="assets/css/app.min.css" type="text/css" />
</head>
<body>

<div class="app app-header-fixed  ">
<div class="container w-xxl w-auto-xs" ng-controller="SigninFormController" ng-init="app.settings.container = false;">
<span class="navbar-brand block m-t"><?php echo $conf['web_name']?>
<span id="mmzhs" style="height: 50px;display: none;"> - 密码找回</span>
</span>
<div class="m-b-lg">

<form name="form" class="form-validation" method="post" action="login.php">


<div id="mmzh" style="display: none;">


<div class="list-group-item">
     <div class="input-group">
      <input type="text" name="email" placeholder="请输入绑定账号的邮箱" class="form-control no-border" required>
      <i class="fa fa-envelope-square" style="position: absolute; left: -12px; top: 11px;"></i>
     </div>
    </div>
   <button type="button" id="zhmm" class="btn btn-lg btn-primary btn-block login">确认</button>
  <div class="switch" id="switch">
    <a  href="#" hidefocus="true" tabindex="6" style="float: right;">返回登录</a>
  </div>
  <br>
  <hr>
  <i class="fa fa-info-circle"></i> 我们将会发送一个包含你账号和密码的邮件到你的邮箱
</div>

<div id="gblogin">

<div id="header" class="header text-center">
  <div class="switch" id="switch" style="font-size: 16px;">
   <a class="switch_btn_focus" hidefocus="true" id="switcher_qlogin" href="javascript:void(0);" tabindex="1">帐号登录</a>
   <a class="switch_btn" hidefocus="true" id="switcher_plogin" href="javascript:void(0);" tabindex="2" >验证码登录</a>
   <div class="switch_bottom" id="switch_bottom"></div>
  </div>
</div>

<div id="Cancel" class="text-danger wrapper text-center" ng-show="authError"></div>

<div id="zhanghao">
 <div class="list-group-item">
    <div class="input-group">
      <input type="text" name="user" placeholder="请输入账号/QQ号/手机号/邮箱号" class="form-control no-border" required>
      <i class="fa fa-user" style="position: absolute; left: -10px; top: 11px;"></i>
    </div>
 </div>
<div class="list-group-item">
   <div class="input-group">
     <input type="password" name="pwd" placeholder="请输入登陆密码" class="form-control no-border" required>
     <i class="fa fa-lock" style="position: absolute; left: -10px; top: 11px;"></i>
   </div>
</div>
  <button type="button" class="btn btn-lg btn-primary btn-block accounts-login">立即登录</button>
</div>


<div id="Verification" style="display: none;">
    <div class="list-group-item">
     <div class="input-group">
      <input type="text" name="phone" placeholder="请输入手机号" class="form-control no-border" required>
      <i class="fa fa-lg fa-mobile" style="font-size: 1.53333333em;position: absolute; left: -10px; top: 11px;"></i>
     </div>
    </div>
    <div class="list-group-item">
     <div class="input-group">
      <input type="text" name="code" placeholder="验证码" class="form-control no-border" required>
        <a class="input-group-addon" id="sendcode">获取验证码</a>
        <i class="fa fa-lock" style="position: absolute; left: -10px; top: 11px;"></i>
      </div>
    </div>
   <button type="button" id="submit" class="btn btn-lg btn-primary btn-block login">立即登录</button>
</div>
<div class="switch" id="switch">
<a href="?reg" style="float: left;">新用户注册</a><a  href="#" hidefocus="true" tabindex="5" style="float: right;">找回密码</a>
</div>
<br>

<div id="qqwxlogin" style="display: none;">
      <iframe data-qq-src="./cache/qqlog.php" data-wx-src="./cache/wxlogin.php" data-qx-src="" title="扫码登录" style="width: 100%;height: 200px;padding: 0;margin: 0;border: 0;"></iframe>
</div>
<?php if($conf['qq_login']==1 || $conf['wx_login']==1){ ?>
<div class="text-center">
  <div class="lefts"></div>
    其他方式登陆
  <div class="rights"></div>
<br><br>

<div class="switch" id="switch" style="font-size: 16px;">
<?php if($conf['qq_login']==1){ ?>
  <a href="#" hidefocus="true" tabindex="3">
    <svg t="1569253250336" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2078" width="40" height="40"><path d="M512 0C229.003636 0 0 229.003636 0 512s229.003636 512 512 512 512-229.003636 512-512S794.996364 0 512 0z m210.385455 641.396364c-7.447273 9.309091-26.996364-1.861818-41.89091-32.581819-3.723636 13.963636-13.032727 36.305455-34.443636 64.232728 35.374545 8.378182 44.683636 42.821818 33.512727 61.44-8.378182 13.032727-26.996364 24.203636-59.578181 24.203636-58.647273 0-83.781818-15.825455-95.883637-26.996364-1.861818-2.792727-5.585455-3.723636-10.24-3.723636-4.654545 0-7.447273 0.930909-10.24 3.723636-11.170909 11.170909-37.236364 26.996364-95.883636 26.996364-32.581818 0-52.130909-11.170909-59.578182-24.203636-12.101818-18.618182-1.861818-53.061818 33.512727-61.44-20.48-27.927273-29.789091-50.269091-34.443636-64.232728-13.963636 30.72-34.443636 42.821818-41.890909 32.581819-5.585455-8.378182-8.378182-26.065455-7.447273-38.167273 3.723636-46.545455 34.443636-85.643636 53.061818-106.123636-2.792727-5.585455-8.378182-40.029091 14.894546-63.301819v-1.861818c0-92.16 65.163636-158.254545 148.014545-158.254545 81.92 0 148.014545 66.094545 148.014546 158.254545v1.861818c23.272727 23.272727 17.687273 57.716364 14.894545 63.301819 17.687273 20.48 49.338182 59.578182 53.061818 106.123636 0.930909 12.101818-0.930909 29.789091-7.447272 38.167273z" fill="#30A5DD" p-id="2079"></path></svg>
  </a>
<?php } ?>
<?php if($conf['wx_login']==1){ ?>
  <font style="margin-left:15px; margin-right:15px;"></font>
  <a href="#" hidefocus="true" tabindex="4">
    <svg t="1569253358863" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="5605" width="40" height="40"><path d="M347.729118 353.0242c-16.487119 0-29.776737 13.389539-29.776737 29.776737S331.241998 412.677596 347.729118 412.677596s29.776737-13.389539 29.776737-29.776737-13.289617-29.876659-29.776737-29.876659zM577.749415 511.800156c-13.689305 0-24.880562 11.091335-24.880563 24.880562 0 13.689305 11.091335 24.880562 24.880563 24.880562 13.689305 0 24.880562-11.191257 24.880562-24.880562s-11.191257-24.880562-24.880562-24.880562zM500.909446 412.677596c16.487119 0 29.776737-13.389539 29.776737-29.776737s-13.389539-29.776737-29.776737-29.776737c-16.487119 0-29.776737 13.389539-29.776737 29.776737s13.289617 29.776737 29.776737 29.776737zM698.455113 511.600312c-13.689305 0-24.880562 11.091335-24.880562 24.880562 0 13.689305 11.091335 24.880562 24.880562 24.880562 13.689305 0 24.880562-11.091335 24.880562-24.880562-0.099922-13.689305-11.191257-24.880562-24.880562-24.880562z" fill="#00C800" p-id="5606"></path><path d="M511.601093 0.799375C229.12178 0.799375 0.000781 229.820453 0.000781 512.399688s229.021077 511.600312 511.600312 511.600312 511.600312-229.021077 511.600312-511.600312S794.180328 0.799375 511.601093 0.799375z m-90.229508 634.504294c-27.37861 0-49.361436-5.595628-76.839969-10.991413l-76.640125 38.469945 21.882904-65.948477c-54.957065-38.370023-87.73146-87.831382-87.73146-148.084309 0-104.318501 98.722873-186.554254 219.32865-186.554255 107.815769 0 202.34192 65.648712 221.327088 153.979703-6.994536-0.799375-13.989071-1.298985-21.083529-1.298985-104.118657 0-186.454333 77.739266-186.454332 173.564403 0 15.98751 2.498048 31.275566 6.794692 45.964091-6.794692 0.599532-13.689305 0.899297-20.583919 0.899297z m323.547228 76.839969l16.48712 54.757221-60.153006-32.874317c-21.882904 5.495706-43.965652 10.991413-65.848555 10.991413-104.318501 0-186.554254-71.344262-186.554255-159.175644 0-87.631538 82.135831-159.175644 186.554255-159.175644 98.523029 0 186.254489 71.444184 186.254488 159.175644 0.099922 49.461358-32.774395 93.227166-76.740047 126.301327z" fill="#00C800" p-id="5607"></path></svg>
  </a>
<?php } ?>
</div>

</div>

</div>
<?php }?>
</form>
</div>
</div>
</div>
<script src="https://lib.baomitu.com/jquery/3.3.1/jquery.min.js"></script>
<script src="https://lib.baomitu.com/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="/assets/layer/layer.js"></script>
<script src="//static.geetest.com/static/tools/gt.js"></script>
<script src="/assets/js/MiniDialog-es5.min.js"></script>
<script type="text/javascript">

$(".accounts-login").click(function(){
  var user=$("input[name='user']").val();
  var pass=$("input[name='pwd']").val();
  if(user==''){layer.msg('账号不能为空！');return false;}
  if(pass==''){layer.msg('密码不能为空！');return false;}
  $.ajax({
      type : "POST",
      url : "jsajax/ajax.php?act=login",
      data : {user:user,pass:pass},
      dataType : 'json',
      success : function(data) {
        layer.msg('登录中..', {
          icon: 16
          ,shade: 0.01
        });
        if(data.code == 0){
          layer.msg('登录成功', {icon: 1});
       window.setTimeout(function () {
          window.location.href="./";
        }, 3000);
         }else{
          layer.msg(data.msg, {icon: 2});
         }
      }
  });
})

 $('.switch').find('a').bind('click', function() {
 $('.switch').find('a').removeClass('switch_btn_focus');
 $('.switch').find('a').addClass('switch_btn');
 $(this).removeClass('switch_btn');
 $(this).addClass('switch_btn_focus');
 $('#typeid').val($(this).attr('tabindex'));

    if($(this).attr('tabindex') == 1){
        $('#qqwxlogin iframe').attr('src',$('#qqwxlogin iframe').attr('data-qx-src'));
        $('#zhanghao').show();
        $('#Cancel').show();
        $('#Verification').hide();
        $('#qqwxlogin').hide();

    }
    if($(this).attr('tabindex') == 2){
        $('#qqwxlogin iframe').attr('src',$('#qqwxlogin iframe').attr('data-qx-src'));
        $('#Verification').show();
        $('#Cancel').show();
        $('#zhanghao').hide();
        $('#qqwxlogin').hide();

    }
   if($(this).attr('tabindex') == 3){
        $('#qqwxlogin iframe').attr('src',$('#qqwxlogin iframe').attr('data-qq-src'));
        $('#qqwxlogin').show();
        $('#zhanghao').hide();
        $('#Cancel').hide();
        $('#Verification').hide();

    }
    if($(this).attr('tabindex') == 4){
        $('#qqwxlogin iframe').attr('src',$('#qqwxlogin iframe').attr('data-wx-src'));
        $('#qqwxlogin').show();
        $('#zhanghao').hide();
        $('#Cancel').hide();
        $('#Verification').hide();
        

    }
     if($(this).attr('tabindex') == 5){
        $('#qqwxlogin iframe').attr('src',$('#qqwxlogin iframe').attr('data-qx-src'));
        $('#gblogin').hide();
        $('#mmzh').show();
        $('#mmzhs').show();
        

    }
    if($(this).attr('tabindex') == 6){
        $('#qqwxlogin iframe').attr('src',$('#qqwxlogin iframe').attr('data-qx-src'));
        $('#zhanghao').show();
        $('#gblogin').show();
        $('#Cancel').show();
        $('#mmzh').hide();
        $('#mmzhs').hide();
        $('#qqwxlogin').hide();
        $('#Verification').hide();
        

    }

});

function invokeSettime(obj){
    var countdown=60;
    settime(obj);
    function settime(obj) {
        if (countdown == 0) {
            $(obj).attr("data-lock", "false");
            $(obj).text("获取验证码");
            countdown = 60;
            return;
        } else {
      $(obj).attr("data-lock", "true");
            $(obj).attr("disabled",true);
            $(obj).text("(" + countdown + ") s 重新发送");
            countdown--;
        }
        setTimeout(function() {
                    settime(obj) }
                ,1000)
    }
}
var handlerEmbed = function (captchaObj) {
  var sendto;
  captchaObj.onReady(function () {
    $("#wait").hide();
  }).onSuccess(function () {
    var result = captchaObj.getValidate();
    if (!result) {
      return alert('请完成验证');
    }
    var ii = layer.load(2, {shade:[0.1,'#fff']});
    $.ajax({
      type : "POST",
      url : "jsajax/ajax.php?act=sendlogin",
      data : {sendto:sendto,geetest_challenge:result.geetest_challenge,geetest_validate:result.geetest_validate,geetest_seccode:result.geetest_seccode},
      dataType : 'json',
      success : function(data) {
        layer.close(ii);
        if(data.code == 0){
          new invokeSettime("#sendcode");
          layer.msg('发送成功，请注意查收！');
        }else{
          layer.alert(data.msg);
          captchaObj.reset();
        }
      } 
    });
  });
  $('#sendcode').click(function () {
    if ($(this).attr("data-lock") === "true") return;
      sendto=$("input[name='phone']").val();
      if(sendto==''){layer.msg('手机号码不能为空！');return false;}
      if(sendto.length!=11){layer.msg('手机号码不正确！');return false;}
    captchaObj.verify();
  })
};
$(document).ready(function(){

  $("#submit").click(function(){
    if ($(this).attr("data-lock") === "true") return;
    var phone=$("input[name='phone']").val();
    var code=$("input[name='code']").val();
    if(phone==''){layer.msg('手机号码不能为空！');return false;}
    if(code==''){layer.msg('验证码不能为空！');return false;}
    var ii = layer.load(2, {shade:[0.1,'#fff']});
    $(this).attr("data-lock", "true");
    $.ajax({
      type : "POST",
      url : "jsajax/ajax.php?act=codelog",
      data : {phone:phone,code:code},
      dataType : 'json',
      success : function(data) {
        $("#submit").attr("data-lock", "false");
        layer.close(ii);
        if(data.code == 0){
         layer.msg(data.msg,function(index){
          parent.layer.closeAll()
          window.location.reload();
          });
          window.parent.location.reload();
        }else{
          layer.msg(data.msg);
        }
      }
    });
  });
  $("#zhmm").click(function(){
    if ($(this).attr("data-lock") === "true") return;
    var email=$("input[name='email']").val();
    if(email==''){layer.alert('邮箱不能为空！');return false;}
    var reg = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/;
    if(!reg.test(email)){layer.alert('邮箱格式不正确！');return false;}
    var ii = layer.load(2, {shade:[0.1,'#fff']});
    $.ajax({
      type : "POST",
      url : "./jsajax/ajax.php?act=find",
      data : {email:email},
      dataType : 'json',
      success : function(data) {
        layer.close(ii);
        if(data.code == 0){
          layer.msg('发送成功，请注意查收！');
        }else{
          layer.alert(data.msg);
        }
      } 
    });
  });
  $.ajax({
    // 获取id，challenge，success（是否启用failback）
    url: "jsajax/ajax.php?act=captcha&t=" + (new Date()).getTime(), // 加随机数防止缓存
    type: "get",
    dataType: "json",
    success: function (data) {
      console.log(data);
      // 使用initGeetest接口
      // 参数1：配置参数
      // 参数2：回调，回调的第一个参数验证码对象，之后可以使用它做appendTo之类的事件
      initGeetest({
        width: '100%',
        gt: data.gt,
        challenge: data.challenge,
        new_captcha: data.new_captcha,
        product: "bind", // 产品形式，包括：float，embed，popup。注意只对PC版验证码有效
        offline: !data.success // 表示用户后台检测极验服务器是否宕机，一般不需要关注
        // 更多配置参数请参见：http://www.geetest.com/install/sections/idx-client-sdk.html#config
      }, handlerEmbed);
    }
  });
});
</script>
</body>
</html>