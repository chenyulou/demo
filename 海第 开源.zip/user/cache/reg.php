<?php
$is_defend=true;
if($conf['is_reg']!=1)sysmsg('未开放商户申请');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<title>申请商户 | <?php echo $conf['web_name']?></title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css" />
<link rel="stylesheet" href="assets/css/app.min.css" type="text/css" />
</head>
<body>
<div class="app app-header-fixed  ">
     <div class="container w-xxl w-auto-xs" ng-controller="SigninFormController" ng-init="app.settings.container = false;">

       <span class="navbar-brand block" style="height: 60px;"><?php echo $conf['web_name']?> - 用户注册</span>
          
          <font id="reg">
          	<div class="list-group-item m-t">
            <div class="input-group">
              <input type="text" name="user" placeholder="请输入账号" class="form-control no-border" required>
            </div>
            </div>

              <div class="list-group-item">
            <div class="input-group">
              <input type="password" name="pwd" placeholder="请输入密码" class="form-control no-border" required>
            </div>
            </div>

             <div class="list-group-item">
            <div class="input-group">
              <input type="password" name="pwds" placeholder="请再次输入密码" class="form-control no-border" required>
            </div>
            </div>
            <?php if($conf['verifytype']==1){?>
            	<div class="list-group-item">
            <div class="input-group">
              <input type="text" name="phone" placeholder="请输入手机号码" class="form-control no-border" required>
            </div>
            </div>
            <input type="hidden" name="data"  value="1">
            	<?php }else{?>
              <div class="list-group-item">
            <div class="input-group">
              <input type="text" name="email" placeholder="请输入邮箱号码" class="form-control no-border" required>
            </div>
            </div>
            <input type="hidden" name="data"  value="2">
            	<?php }?>
            <div class="list-group-item">
			<div class="input-group">
			<input type="text" name="code" placeholder="验证码" class="form-control no-border" required>
			<a class="input-group-addon" id="sendcode">获取验证码</a>
			</div>
			</div>
			<button type="button" id="submit" class="btn btn-lg btn-primary btn-block" ng-click="login()" ng-disabled='form.$invalid' style="margin-bottom: 10px;">立即注册</button>
          </font>
          <div style="height: 40px;">
          <a href="?login" style="float: left;">已有账号，去登录</a>
          <?php if ($conf['lyhbd']==1) {?>
          <a href="./binding.php" style="float: right;">老用户绑定</a>
	      <?php } ?>
          </div>
     </div>
</div>


<script src="https://lib.baomitu.com/jquery/3.3.1/jquery.min.js"></script>
<script src="/assets/layer/layer.js"></script>
<script src="//static.geetest.com/static/tools/gt.js"></script>
<script>


function invokeSettime(obj){
    var countdown=60;
    settime(obj);
    function settime(obj) {
        if (countdown == 0) {
            $(obj).attr("data-lock", "false");
            $(obj).text("获取验证码");
            countdown = 60;
            return;
        } else {
			$(obj).attr("data-lock", "true");
            $(obj).attr("disabled",true);
            $(obj).text("(" + countdown + ") s 重新发送");
            countdown--;
        }
        setTimeout(function() {
                    settime(obj) }
                ,1000)
    }
}

var sendto;

var handlerEmbed = function (captchaObj) {
	
	captchaObj.onReady(function () {
		$("#wait").hide();
	}).onSuccess(function () {
		var result = captchaObj.getValidate();
		if (!result) {
			return alert('请完成验证');
		}
		var ii = layer.load(2, {shade:[0.1,'#fff']});
		$.ajax({
			type : "POST",
			url : "jsajax/ajax.php?act=sendcode",
			data : {sendto:sendto,geetest_challenge:result.geetest_challenge,geetest_validate:result.geetest_validate,geetest_seccode:result.geetest_seccode},
			dataType : 'json',
			success : function(data) {
				layer.close(ii);
				if(data.code == 0){
					new invokeSettime("#sendcode");
					layer.msg('发送成功，请注意查收！');
				}else{
					layer.alert(data.msg);
					captchaObj.reset();
				}
			} 
		});
	});


	$('#sendcode').click(function () {

		var data=$("input[name='data']").val();

		var email=$("input[name='email']").val()

		var phone=$("input[name='phone']").val()

		if ($(this).attr("data-lock") === "true") return;
            
       if(data==2){

			if(email==''){layer.alert('邮箱不能为空！');return false;}
			
			var reg = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/;
			
			if(!reg.test(email)){layer.alert('邮箱格式不正确！');return false;}
			sendto=email;

		}else if(data==1){

			if(phone==''){layer.alert('手机号不能为空！');return false;}
			
			if(phone.length!=11){layer.alert('手机号码不正确！');return false;}
			sendto=phone;

		}else{

			layer.alert('参数错误！');return false;

		}


		captchaObj.verify();

	})

};

$(document).ready(function(){

	$("select[name='type']").change();

	 $("#submit").click(function(){

		if ($(this).attr("data-lock") === "true") return;

		var user=$("input[name='user']").val();

		var pwd=$("input[name='pwd']").val();

		var pwds=$("input[name='pwds']").val();

		var email=$("input[name='email']").val();

		var phone=$("input[name='phone']").val();

		var code=$("input[name='code']").val();

		var data=$("input[name='data']").val();

		if(user=='' || pwd=='' || pwds=='' || code==''){

			layer.alert('请确保各项不能为空！');

			return false;
		}

		if(data==2){

			if(email==''){layer.alert('邮箱不能为空！');return false;}
			
			var reg = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/;
			
			if(!reg.test(email)){layer.alert('邮箱格式不正确！');return false;}

		}else if(data==1){

			if(phone==''){layer.alert('手机号不能为空！');return false;}
			
			if(phone.length!=11){layer.alert('手机号码不正确！');return false;}

		}else{

			layer.alert('参数错误！');return false;

		}
		

		if(pwd != pwds){

			layer.alert('两次输入的密码不一致！');

			return false;

		}



		var ii = layer.load(2, {shade:[0.1,'#fff']});

		$(this).attr("data-lock", "true");

		$.ajax({

			type : "POST",

			url : "jsajax/ajax.php?act=reg",

			data : {user:user,pwd:pwd,pwds:pwds,email:email,phone:phone,code:code},

			dataType : 'json',

			success : function(data) {

				$("#submit").attr("data-lock", "false");

				layer.close(ii);

				if(data.code == 1){

					layer.open({

					  type: 1,

					  title: '商户申请成功',

					  skin: 'layui-layer-rim',

					  content: '<li class="list-group-item"><b>账号：</b>'+data.user+'</li><li class="list-group-item"><b>密码：</b>'+data.pwd+'</li><li class="list-group-item">请牢记你的账号密码哦！</li><li class="list-group-item"><a href="?login" class="btn btn-default btn-block">返回登录</a></li>'
					});

				}else{
					layer.alert(data.msg);
				}
			}
		});
	});

	$.ajax({
		url: "jsajax/ajax.php?act=captcha&t=" + (new Date()).getTime(), 
		dataType: "json",
		success: function (data) {
			console.log(data);
			initGeetest({
				width: '100%',
				gt: data.gt,
				challenge: data.challenge,
				new_captcha: data.new_captcha,
				product: "bind", 
				offline: !data.success 
			}, handlerEmbed);
		}
	});
});
</script>
</body>
</html>