<?php

function proxy_get($url)
{

    return 0;

}

function curl_get($url)
{

    $ch = curl_init($url);

    $httpheader[] = "Accept:*/*";

    $httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";

    $httpheader[] = "Connection:close";

    curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);

    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 4.4.1; zh-cn; R815T Build/JOP40D) AppleWebKit/533.1 (KHTML, like Gecko)Version/4.0 MQQBrowser/4.5 Mobile Safari/533.1');

    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $content = curl_exec($ch);

    curl_close($ch);

    return ($content);

}

function do_notify($url)
{

    $return = curl_get($url);

    if (strpos($return, 'success') !== false) {

        return true;

    } else {

        proxy_get($url);

    }

}

function get_curl($url, $post = 0, $referer = 0, $cookie = 0, $header = 0, $ua = 0, $nobaody = 0)
{

    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $url);

    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

    $httpheader[] = "Accept:*/*";

    $httpheader[] = "Accept-Encoding:gzip,deflate,sdch";

    $httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";

    $httpheader[] = "Connection:close";

    curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);

    if ($post) {

        curl_setopt($ch, CURLOPT_POST, 1);

        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);

    }

    if ($header) {

        curl_setopt($ch, CURLOPT_HEADER, true);

    }

    if ($cookie) {

        curl_setopt($ch, CURLOPT_COOKIE, $cookie);

    }

    if ($referer) {

        if ($referer == 1) {

            curl_setopt($ch, CURLOPT_REFERER, 'http://m.qzone.com/infocenter?g_f=');

        } else {

            curl_setopt($ch, CURLOPT_REFERER, $referer);

        }

    }

    if ($ua) {

        curl_setopt($ch, CURLOPT_USERAGENT, $ua);

    } else {

        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Linux; U; Android 4.0.4; es-mx; HTC_One_X Build/IMM76D) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0");

    }

    if ($nobaody) {

        curl_setopt($ch, CURLOPT_NOBODY, 1);

    }

    curl_setopt($ch, CURLOPT_ENCODING, "gzip");

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

    $ret = curl_exec($ch);

    curl_close($ch);

    return $ret;

}

function real_ip()
{

    $ip = $_SERVER['REMOTE_ADDR'];

    if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) && preg_match_all('#\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}#s', $_SERVER['HTTP_X_FORWARDED_FOR'], $matches)) {

        foreach ($matches[0] as $xip) {

            if (!preg_match('#^(10|172\.16|192\.168)\.#', $xip)) {

                $ip = $xip;

                break;

            }

        }

    } elseif (isset($_SERVER['HTTP_CLIENT_IP']) && preg_match('/^([0-9]{1,3}\.){3}[0-9]{1,3}$/', $_SERVER['HTTP_CLIENT_IP'])) {

        $ip = $_SERVER['HTTP_CLIENT_IP'];

    } elseif (isset($_SERVER['HTTP_CF_CONNECTING_IP']) && preg_match('/^([0-9]{1,3}\.){3}[0-9]{1,3}$/', $_SERVER['HTTP_CF_CONNECTING_IP'])) {

        $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];

    } elseif (isset($_SERVER['HTTP_X_REAL_IP']) && preg_match('/^([0-9]{1,3}\.){3}[0-9]{1,3}$/', $_SERVER['HTTP_X_REAL_IP'])) {

        $ip = $_SERVER['HTTP_X_REAL_IP'];

    }

    return $ip;

}

function ip_city_str($str)
{

    return str_replace(array('省', '市'), '', $str);

}

function get_ip_city($ip)
{

    $unknown = ‘unknown’;
    if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) && $_SERVER['HTTP_X_FORWARDED_FOR'] && strcasecmp($_SERVER['HTTP_X_FORWARDED_FOR'], $unknown)) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } elseif (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], $unknown)) {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    $url   = 'http://api.map.baidu.com/location/ip?ip=' . $ip . '&ak=zyjHt3iUKWVHB5HjQYy7th1DTbKTPcGY';
    $html  = file_get_contents($url);
    $res   = json_decode($html);
    $cheng = $res->content->address_detail->province; //城市
    $sheng = $res->content->address_detail->city; //省份
    $city  = $cheng . $sheng;
    return $city;

}

function send_mail($to, $sub, $msg)
{
    global $conf;

    include_once 'smtp.class.php';
    $From      = $conf['mail_name'];
    $Host      = $conf['mail_smtp'];
    $Port      = $conf['mail_port'];
    $SMTPAuth  = 1;
    $Username  = $conf['mail_name'];
    $Password  = $conf['mail_pwd'];
    $Nickname  = $conf['web_name'];
    $SSL       = $conf['mail_port'] == 465 ? 1 : 0;
    $mail      = new SMTP($Host, $Port, $SMTPAuth, $Username, $Password, $SSL);
    $mail->att = array();
    if ($mail->send($to, $From, $sub, $msg, $Nickname)) {
        return true;
    } else {
        return $mail->log;
    }
}

function send_sms($phone, $code, $tnum, $moban = '1')
{

    global $conf;

    $host = "https://ali-sms.showapi.com";

    $path = "/sendSms";

    $method = "GET"; //请求方式

    $appcode = $conf['dx_code']; //阿里云——>云市场——>已购买的服务列表——AppCode

    $tNum = $tnum; //模板编号T170317004554

    $as = array('code' => $code);

    $conte = json_encode($as, true);

    $headers = array();

    array_push($headers, "Authorization:APPCODE " . $appcode);

    $querys = "content=" . $conte . "&mobile=" . $phone . "&tNum=" . $tNum; //发送短信

    $bodys = "";

    $url = $host . $path . "?" . $querys;

    $curl = curl_init();

    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);

    curl_setopt($curl, CURLOPT_URL, $url);

    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

    curl_setopt($curl, CURLOPT_FAILONERROR, false);

    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

    //curl_setopt($curl, CURLOPT_HEADER, true);

    if (1 == strpos("$" . $host, "https://")) {

        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);

    }

    $data = curl_exec($curl);

    $arr = json_decode($data, true);

    if ($arr["showapi_res_body"]["remark"] == '提交成功!') {

        return true;

    } else {

        return $arr["showapi_res_body"]["remark"];

    }

}

function daddslashes($string, $force = 0, $strip = false)
{

    !defined('MAGIC_QUOTES_GPC') && define('MAGIC_QUOTES_GPC', get_magic_quotes_gpc());

    if (!MAGIC_QUOTES_GPC || $force) {

        if (is_array($string)) {

            foreach ($string as $key => $val) {

                $string[$key] = daddslashes($val, $force, $strip);

            }

        } else {

            $string = addslashes($strip ? stripslashes($string) : $string);

        }

    }

    return $string;

}

function strexists($string, $find)
{

    return !(strpos($string, $find) === false);

}

function dstrpos($string, $arr)
{

    if (empty($string)) {
        return false;
    }

    foreach ((array) $arr as $v) {

        if (strpos($string, $v) !== false) {

            return true;

        }

    }

    return false;

}

function checkmobile()
{

    $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);

    $ualist = array('android', 'midp', 'nokia', 'mobile', 'iphone', 'ipod', 'blackberry', 'windows phone');

    if ((dstrpos($useragent, $ualist) || strexists($_SERVER['HTTP_ACCEPT'], "VND.WAP") || strexists($_SERVER['HTTP_VIA'], "wap"))) {
        return true;
    } else {
        return false;
    }

}

function authcode($string, $operation = 'DECODE', $key = '', $expiry = 0)
{

    $ckey_length = 4;

    $key = md5($key ? $key : ENCRYPT_KEY);

    $keya = md5(substr($key, 0, 16));

    $keyb = md5(substr($key, 16, 16));

    $keyc = $ckey_length ? ($operation == 'DECODE' ? substr($string, 0, $ckey_length) : substr(md5(microtime()), -$ckey_length)) : '';

    $cryptkey = $keya . md5($keya . $keyc);

    $key_length = strlen($cryptkey);

    $string = $operation == 'DECODE' ? base64_decode(substr($string, $ckey_length)) : sprintf('%010d', $expiry ? $expiry + time() : 0) . substr(md5($string . $keyb), 0, 16) . $string;

    $string_length = strlen($string);

    $result = '';

    $box = range(0, 255);

    $rndkey = array();

    for ($i = 0; $i <= 255; $i++) {

        $rndkey[$i] = ord($cryptkey[$i % $key_length]);

    }

    for ($j = $i = 0; $i < 256; $i++) {

        $j = ($j + $box[$i] + $rndkey[$i]) % 256;

        $tmp = $box[$i];

        $box[$i] = $box[$j];

        $box[$j] = $tmp;

    }

    for ($a = $j = $i = 0; $i < $string_length; $i++) {

        $a = ($a + 1) % 256;

        $j = ($j + $box[$a]) % 256;

        $tmp = $box[$a];

        $box[$a] = $box[$j];

        $box[$j] = $tmp;

        $result .= chr(ord($string[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));

    }

    if ($operation == 'DECODE') {

        if ((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0) && substr($result, 10, 16) == substr(md5(substr($result, 26) . $keyb), 0, 16)) {

            return substr($result, 26);

        } else {

            return '';

        }

    } else {

        return $keyc . str_replace('=', '', base64_encode($result));

    }

}

function random($length, $numeric = 0)
{

    $seed = base_convert(md5(microtime() . $_SERVER['DOCUMENT_ROOT']), 16, $numeric ? 10 : 35);

    $seed = $numeric ? (str_replace('0', '', $seed) . '012340567890') : ($seed . 'zZ' . strtoupper($seed));

    $hash = '';

    $max = strlen($seed) - 1;

    for ($i = 0; $i < $length; $i++) {

        $hash .= $seed{mt_rand(0, $max)};

    }

    return $hash;

}

function showmsg($content = '未知的异常', $type = 4, $back = false)
{

    switch ($type) {

        case 1:

            $panel = "success";

            break;

        case 2:

            $panel = "info";

            break;

        case 3:

            $panel = "warning";

            break;

        case 4:

            $panel = "danger";

            break;

    }

    echo '<div class="panel panel-' . $panel . '">

      <div class="panel-heading">

        <h3 class="panel-title">提示信息</h3>

        </div>

        <div class="panel-body">';

    echo $content;

    if ($back) {

        echo '<hr/><a href="' . $back . '"><< 返回上一页</a>';

    } else {
        echo '<hr/><a href="javascript:history.back(-1)"><< 返回上一页</a>';
    }

    echo '</div>

    </div>';

}

function sysmsg($msg = '未知的异常', $die = true)
{

    ?>

    <!DOCTYPE html>

    <html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">

    <head>

        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title>站点提示信息</title>

        <style type="text/css">

html{background:#eee}body{background:#fff;color:#333;font-family:"微软雅黑","Microsoft YaHei",sans-serif;margin:2em auto;padding:1em 2em;max-width:700px;-webkit-box-shadow:10px 10px 10px rgba(0,0,0,.13);box-shadow:10px 10px 10px rgba(0,0,0,.13);opacity:.8}h1{border-bottom:1px solid #dadada;clear:both;color:#666;font:24px "微软雅黑","Microsoft YaHei",,sans-serif;margin:30px 0 0 0;padding:0;padding-bottom:7px}#error-page{margin-top:50px}h3{text-align:center}#error-page p{font-size:9px;line-height:1.5;margin:25px 0 20px}#error-page code{font-family:Consolas,Monaco,monospace}ul li{margin-bottom:10px;font-size:9px}a{color:#21759B;text-decoration:none;margin-top:-10px}a:hover{color:#D54E21}.button{background:#f7f7f7;border:1px solid #ccc;color:#555;display:inline-block;text-decoration:none;font-size:9px;line-height:26px;height:28px;margin:0;padding:0 10px 1px;cursor:pointer;-webkit-border-radius:3px;-webkit-appearance:none;border-radius:3px;white-space:nowrap;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;-webkit-box-shadow:inset 0 1px 0 #fff,0 1px 0 rgba(0,0,0,.08);box-shadow:inset 0 1px 0 #fff,0 1px 0 rgba(0,0,0,.08);vertical-align:top}.button.button-large{height:29px;line-height:28px;padding:0 12px}.button:focus,.button:hover{background:#fafafa;border-color:#999;color:#222}.button:focus{-webkit-box-shadow:1px 1px 1px rgba(0,0,0,.2);box-shadow:1px 1px 1px rgba(0,0,0,.2)}.button:active{background:#eee;border-color:#999;color:#333;-webkit-box-shadow:inset 0 2px 5px -3px rgba(0,0,0,.5);box-shadow:inset 0 2px 5px -3px rgba(0,0,0,.5)}table{table-layout:auto;border:1px solid #333;empty-cells:show;border-collapse:collapse}th{padding:4px;border:1px solid #333;overflow:hidden;color:#333;background:#eee}td{padding:4px;border:1px solid #333;overflow:hidden;color:#333}

        </style>

    </head>

    <body id="error-page">

        <?php echo '<h3>站点提示信息</h3>';

    echo $msg; ?>

    </body>

    </html>

    <?php

    if ($die == true) {

        exit;

    }

}

function creat_callback($data)
{

    global $DB;

    $userrow = $DB->query("SELECT * FROM pay_user WHERE id='{$data['pid']}' limit 1")->fetch();

    $array = array('pid' => $data['pid'], 'trade_no' => $data['trade_no'], 'out_trade_no' => $data['out_trade_no'], 'type' => $data['type'], 'name' => $data['name'], 'money' => $data['money'], 'trade_status' => 'TRADE_SUCCESS');

    $arg = argSort(paraFilter($array));

    $prestr = createLinkstring($arg);

    $urlstr = createLinkstringUrlencode($arg);

    $sign = md5Sign($prestr, $userrow['key']);

    if (strpos($data['notify_url'], '?')) {
        $url['notify'] = $data['notify_url'] . '&' . $urlstr . '&sign=' . $sign . '&sign_type=MD5';
    } else {
        $url['notify'] = $data['notify_url'] . '?' . $urlstr . '&sign=' . $sign . '&sign_type=MD5';
    }

    if (strpos($data['return_url'], '?')) {
        $url['return'] = $data['return_url'] . '&' . $urlstr . '&sign=' . $sign . '&sign_type=MD5';
    } else {
        $url['return'] = $data['return_url'] . '?' . $urlstr . '&sign=' . $sign . '&sign_type=MD5';
    }

    return $url;

}

function getdomain($url)
{

    $arr = parse_url($url);

    return $arr['host'];

}

function processOrder($srow, $notify = true)
{

    global $DB, $conf;

    $res = $DB->query("SELECT * FROM  pay_jie WHERE id='{$srow['type_id']}' limit 1")->fetch();

    $userrow = $DB->query("SELECT * FROM pay_user WHERE id='{$srow['pid']}' limit 1")->fetch();

    $money = $srow['money'];

    if (isset($conf['money_rate']) && $conf['money_rate'] >= '0' && $conf['money_rate'] <= 1) {

        $rate = $conf['money_rate'];

    }

    if (isset($res['api_shaui']) && $res['api_shaui'] >= '0' && $res['api_shaui'] <= 1) {

        $rate = $res['api_shaui'];

    }

    if ($srow['type'] == 'alipay' && isset($userrow['rate_ali']) && $userrow['rate_ali'] >= '0' && $userrow['rate_ali'] <= 1) {

        $rate = $userrow['rate_ali'];

    } elseif ($srow['type'] == 'wxpay' && isset($userrow['rate_wx']) && $userrow['rate_wx'] >= '0' && $userrow['rate_wx'] <= 1) {

        if ($res['donlx'] == 1) {

            $rate = $userrow['rate_wxh5'];

        } else {

            $rate = $userrow['rate_wx'];

        }

    } elseif ($srow['type'] == 'qqpay' && isset($userrow['rate_qq']) && $userrow['rate_qq'] >= '0' && $userrow['rate_qq'] <= 1) {

        $rate = $userrow['rate_qq'];

    }

    $date = date("Y-m-d H:i:s");

    $addmoney = round($srow['money'] * $rate, 2);

    $addmoney = $money - $addmoney;

    //file_put_contents('a.txt',$addmoney);

    if ($srow['uid'] == 0 || $srow['uid'] == '') {

        $DB->exec("update pay_user set money=money+{$addmoney} where id='{$srow['pid']}'");

        $userrow = $DB->query("SELECT * FROM pay_user WHERE id='{$srow['pid']}' limit 1")->fetch();

        $money = $userrow['money'];

        $DB->exec("INSERT INTO `pay_money` (`uid`, `name`, `money`, `addmoney`, `time`) VALUES ('{$srow['pid']}', '订单', '+{$addmoney}', '{$money}', '{$date}')");

    } else {

        $DB->exec("update pay_user set money=money+{$addmoney} where id='{$srow['uid']}'");

        $userrow = $DB->query("SELECT * FROM pay_user WHERE id='{$srow['uid']}' limit 1")->fetch();

        $money = $userrow['money'];

        $DB->exec("INSERT INTO `pay_money` (`uid`, `name`, `money`, `addmoney`, `time`) VALUES ('{$srow['uid']}', '充值', '+{$addmoney}', '{$money}', '{$date}')");

    }

    if ($notify == true) {

        $url = creat_callback($srow);

        do_notify($url['notify']);

    }

}

function bankInfo($card)
{

    require_once 'bankList.php';

    $card_8 = substr($card, 0, 8);

    if (isset($bankList[$card_8])) {

        return $bankList[$card_8];

    }

    $card_6 = substr($card, 0, 6);

    if (isset($bankList[$card_6])) {

        return $bankList[$card_6];

    }

    $card_5 = substr($card, 0, 5);

    if (isset($bankList[$card_5])) {

        return $bankList[$card_5];

    }

    $card_4 = substr($card, 0, 4);

    if (isset($bankList[$card_4])) {

        return $bankList[$card_4];

    }

    if ($card != '') {

        return '该卡号信息暂未录入';

    }

}

function is_idcard($id)
{
    $id        = strtoupper($id);
    $regx      = "/(^\d{15}$)|(^\d{17}([0-9]|X)$)/";
    $arr_split = array();
    if (!preg_match($regx, $id)) {
        return false;
    }
    if (15 == strlen($id)) //检查15位
    {
        $regx = "/^(\d{6})+(\d{2})+(\d{2})+(\d{2})+(\d{3})$/";

        @preg_match($regx, $id, $arr_split);
        //检查生日日期是否正确
        $dtm_birth = "19" . $arr_split[2] . '/' . $arr_split[3] . '/' . $arr_split[4];
        if (!strtotime($dtm_birth)) {
            return false;
        } else {
            return true;
        }
    } else //检查18位
    {
        $regx = "/^(\d{6})+(\d{4})+(\d{2})+(\d{2})+(\d{3})([0-9]|X)$/";
        @preg_match($regx, $id, $arr_split);
        $dtm_birth = $arr_split[2] . '/' . $arr_split[3] . '/' . $arr_split[4];
        if (!strtotime($dtm_birth)) //检查生日日期是否正确
        {
            return false;
        } else {
            //检验18位身份证的校验码是否正确。
            //校验位按照ISO 7064:1983.MOD 11-2的规定生成，X可以认为是数字10。
            $arr_int = array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2);
            $arr_ch  = array('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2');
            $sign    = 0;
            for ($i = 0; $i < 17; $i++) {
                $b = (int) $id{$i};
                $w = $arr_int[$i];
                $sign += $b * $w;
            }
            $n       = $sign % 11;
            $val_num = $arr_ch[$n];
            if ($val_num != substr($id, 17, 1)) {
                return false;
            } else {
                return true;
            }
        }
    }

}

function Sfyz($sfzhm, $name, $conf)
{

    $host    = "http://checkidc.market.alicloudapi.com";
    $path    = "/idcard/VerifyIdcardv2";
    $method  = "GET";
    $appcode = $conf['sfyz_code'];
    $headers = array();
    array_push($headers, "Authorization:APPCODE " . $appcode);
    $querys = "cardNo=" . $sfzhm . "&realName=" . $name;
    $bodys  = "";
    $url    = $host . $path . "?" . $querys;

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_FAILONERROR, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    //curl_setopt($curl, CURLOPT_HEADER, true);
    if (1 == strpos("$" . $host, "https://")) {
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    }

    $data = curl_exec($curl);

    $arr = json_decode($data, true);

    return $arr;
}

function shourz($phone, $sfzhm, $name, $conf)
{

    $host    = "http://cphone.market.alicloudapi.com";
    $path    = "/efficient/cellphone";
    $method  = "GET";
    $appcode = $conf['shourz'];
    $headers = array();
    array_push($headers, "Authorization:APPCODE " . $appcode);
    $querys = "idCard=" . $sfzhm . "&mobile=" . $phone . "&realName=" . $name;
    $bodys  = "";
    $url    = $host . $path . "?" . $querys;

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_FAILONERROR, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    //curl_setopt($curl, CURLOPT_HEADER, true);
    if (1 == strpos("$" . $host, "https://")) {
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    }
    $data = curl_exec($curl);

    $arr = json_decode($data, true);

    $result = $arr['result'];

    return $result;

}

function yhkrz($yhkh, $sfzhm, $name, $conf)
{

    $host    = "https://aliyuncardby4element.haoservice.com";
    $path    = "/creditop/BankCardQuery/QryBankCardBy3Element";
    $method  = "GET";
    $appcode = "0691a05c14b8437e97360640d5f73307";
    $headers = array();
    array_push($headers, "Authorization:APPCODE " . $appcode);
    $querys = "accountNo=" . $yhkh . "&idCardCode=" . $sfzhm . "&name=" . $name;
    $bodys  = "";
    $url    = $host . $path . "?" . $querys;

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_FAILONERROR, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    // curl_setopt($curl, CURLOPT_HEADER, true);
    if (1 == strpos("$" . $host, "https://")) {
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    }

    $data = curl_exec($curl);

    $arr = json_decode($data, true);

    $result = $arr['result'];

    $resty = $result['result'];

    return $resty;

}

function youfas($code)
{
    global $DB, $conf;
    $text = ' <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title,haidi！</title>
</head>
<body>
<div style="width:900px; margin:0 auto; background:#fafafa;">
    <table cellpadding="0" cellspacing="0" border="0" align="center" width="900px" style="">
        <tbody>
        <tr bgcolor="#35bdbc" height="80">
            <td width="580" style="line-height:10px;" align="center">
                <span style="font-size:24px; color:#ffffff;"></span><br>
                <span style="color:#ffffff; font-size:36px;"><span>' . $conf['web_name'] . '</span> - <span>操作通知</span></span></td>
        </tr>
        </tbody>
    </table>
    &nbsp;&nbsp;
<table cellpadding="0" cellspacing="0" border="0" align="center" width="860px" style="">
    <tbody>
    <tr height="20"></tr>
    <tr>
        <td style="">
            <img style="margin-right:5px; " src="http://www.jiankongbao.com/img/report/mark.png"><b>操作通知</b>
        </td>
    </tr>
    <tr height="20"></tr>
    </tbody>
</table>
<table cellpadding="0" cellspacing="0" border="0" align="center" width="860px" style="background-color: white;">
    <tbody>
    <tr height="20"></tr>
    <tr>
        <td style="" align="center">
             <span style="font-size:24px; color:#000;">' . $code . '</span>
        </td>
    </tr>
    <tr height="20"></tr>
    </tbody>
</table>

<table width="100%" cellspacing="0" border="0" cellpadding="0" style="background-color: #fafafa;">
  <tbody><tr>
          <td width="20"></td>
          <td>
              <table width="100%" cellspacing="0" border="0" cellpadding="0">
                  <tbody><tr><td height="20"></td></tr>
                  <tr>

                  </tr>
                <tr><td height="20"></td></tr>
              </tbody></table>
          </td>
          <td width="20"></td>
      </tr>
  </tbody>
</table>
<table width="100%" cellspacing="0" border="0" cellpadding="0" style="background-color: #35bdbc;">
  <tbody><tr>
          <td width="20"></td>
          <td>
              <table width="100%" cellspacing="0" border="0" cellpadding="0">
                  <tbody><tr><td height="20"></td></tr>
                  <tr>
                      <td style="font-size:13px;text-align:center;">Copyright &nbsp;© 2019 <strong>' . $conf['web_name'] . '</strong>版权所有</td>
                  </tr>
                <tr><td height="20"></td></tr>
              </tbody></table>
          </td>
          <td width="20"></td>
      </tr>
  </tbody>
</table>
</div>
</body>
</html>';
    return $text;
}
function display_type($type)
{
    if ($type == 1) {
        return '支付宝';
    } elseif ($type == 2) {
        return '微信';
    } elseif ($type == 3) {
        return 'QQ钱包';
    } elseif ($type == 4) {
        return '银行卡';
    } else {
        return 1;
    }

}
function disdown_type($type)
{
    if ($type == 1) {
        return '结算';
    } elseif ($type == 2) {
        return '系统';
    } elseif ($type == 3) {
        return '安全';
    } elseif ($type == 4) {
        return '紧急';
    } else {
        return 1;
    }

}
function sub_str($str, $length = 0, $append = true)
{
    $str       = trim($str);
    $strlength = strlen($str);

    if ($length == 0 || $length >= $strlength) {
        return $str; //截取长度等于0或大于等于本字符串的长度，返回字符串本身
    } elseif ($length < 0) //如果截取长度为负数
    {
        $length = $strlength + $length; //那么截取长度就等于字符串长度减去截取长度
        if ($length < 0) {
            $length = $strlength; //如果截取长度的绝对值大于字符串本身长度，则截取长度取字符串本身的长度
        }
    }

    if (function_exists('mb_substr')) {
        $newstr = mb_substr($str, 0, $length, EC_CHARSET);
    } elseif (function_exists('iconv_substr')) {
        $newstr = iconv_substr($str, 0, $length, EC_CHARSET);
    } else {
        //$newstr = trim_right(substr($str, 0, $length));
        $newstr = substr($str, 0, $length);
    }

    if ($append && $str != $newstr) {
        $newstr .= '...';
    }

    return $newstr;
}

function is_mobile()
{

    $user_agent = strtolower($_SERVER['HTTP_USER_AGENT']);

    $mobile_agents = array("ipad", "wap", "android", "iphone", "sec", "sam", "ericsson", "240x320", "acer", "acoon", "acs-", "abacho", "ahong", "airness", "alcatel", "amoi", "anywhereyougo.com", "applewebkit/525", "applewebkit/532", "asus", "audio", "au-mic", "avantogo", "becker", "benq", "bilbo", "bird", "blackberry", "blazer", "bleu", "cdm-", "compal", "coolpad", "danger", "dbtel", "dopod", "elaine", "eric", "etouch", "fly ", "fly_", "fly-", "go.web", "goodaccess", "gradiente", "grundig", "haier", "hedy", "hitachi", "htc", "huawei", "hutchison", "inno", "ipaq", "ipod", "jbrowser", "kddi", "kgt", "kwc", "lenovo", "lg", "lg2", "lg3", "lg4", "lg5", "lg7", "lg8", "lg9", "lg-", "lge-", "lge9", "longcos", "maemo", "mercator", "meridian", "micromax", "midp", "mini", "mitsu", "mmm", "mmp", "mobi", "mot-", "moto", "nec-", "netfront", "newgen", "nexian", "nf-browser", "nintendo", "nitro", "nokia", "nook", "novarra", "obigo", "palm", "panasonic", "pantech", "philips", "phone", "pg-", "playstation", "pocket", "pt-", "qc-", "qtek", "rover", "sagem", "sama", "samu", "sanyo", "samsung", "sch-", "scooter", "sec-", "sendo", "sgh-", "sharp", "siemens", "sie-", "softbank", "sony", "spice", "sprint", "spv", "symbian", "tcl-", "teleca", "telit", "tianyu", "tim-", "toshiba", "tsm", "up.browser", "utec", "utstar", "verykool", "virgin", "vk-", "voda", "voxtel", "vx", "wellco", "wig browser", "wii", "windows ce", "wireless", "xda", "xde", "zte", "ben", "hai", "phili");

    $is_mobile = false;

    foreach ($mobile_agents as $device) {

        if (stristr($user_agent, $device)) {

            $is_mobile = true;

            break;

        }

    }

    return $is_mobile;

}
function rzfrequency($frequency)
{
    if ($frequency == 2) {
        return 2;
    } elseif ($frequency == 3) {
        return 1;
    } elseif ($frequency == 4) {
        return 0;
    } else {
        return 3;
    }

}
function Status($status)
{
    if ($status == 1) {
        return "<font color=green>已结算</font>";
    } elseif ($status == 2) {
        return "<font color=blue>未结算</font>";
    } elseif ($status == 3) {
        return "<font color=khaki>处理中</font>";
    } elseif ($status == 4) {
        return "<font color=firebrick>已驳回</font>";
    }

}

function convertUrlQuery($query)
{
    $queryParts = explode('&', $query);
    $params     = array();
    foreach ($queryParts as $param) {
        $item             = explode('=', $param);
        $params[$item[0]] = $item[1];
    }
    return $params;
}

function getFile($url, $save_dir = '', $filename = '', $type = 0)
{
    if (trim($url) == '') {
        return false;
    }
    if (trim($save_dir) == '') {
        $save_dir = './';
    }
    if (0 !== strrpos($save_dir, '/')) {
        $save_dir .= '/';
    }
    if (!file_exists($save_dir) && !mkdir($save_dir, 0777, true)) {
        return false;
    }
    if ($type) {
        $ch      = curl_init();
        $timeout = 5;
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        $content = curl_exec($ch);
        curl_close($ch);
    } else {
        ob_start();
        readfile($url);
        $content = ob_get_contents();
        ob_end_clean();
    }
    $size = strlen($content);
    $fp2  = @fopen($save_dir . $filename, 'a');
    fwrite($fp2, $content);
    fclose($fp2);
    unset($content, $url);
    return true;
}
function get_zip_originalsize($filename, $path)
{
    if (!file_exists($filename)) {
        die("解压文件不存在！");
    }
    $starttime = explode(' ', microtime());
    $filename  = iconv("utf-8", "gb2312", $filename);
    $path      = iconv("utf-8", "gb2312", $path);
    $resource  = zip_open($filename);
    $i         = 1;
    while ($dir_resource = zip_read($resource)) {
        if (zip_entry_open($resource, $dir_resource)) {
            $file_name = $path . zip_entry_name($dir_resource);
            $file_path = substr($file_name, 0, strrpos($file_name, "/"));
            if (!is_dir($file_path)) {
                mkdir($file_path, 0777, true);
            }
            if (!is_dir($file_name)) {
                $file_size = zip_entry_filesize($dir_resource);
                if ($file_size < (1024 * 1024 * 6)) {
                    $file_content = zip_entry_read($dir_resource, $file_size);
                    file_put_contents($file_name, $file_content);
                } else {
                    echo "<p> " . $i++ . " 此文件已被跳过，原因：文件过大， -> " . iconv("gb2312", "utf-8", $file_name) . " </p>";
                }
            }
            zip_entry_close($dir_resource);
        }
    }
    zip_close($resource);
    $endtime  = explode(' ', microtime());
    $thistime = $endtime[0] + $endtime[1] - ($starttime[0] + $starttime[1]);
    $thistime = round($thistime, 3);
    return true;
}

function del_DirAndFile($dirName)
{
    if (is_dir($dirName)) {
        if ($handle = opendir("$dirName")) {
            while (false !== ($item = readdir($handle))) {
                if ($item != "." && $item != "..") {
                    if (is_dir("$dirName/$item")) {
                        del_DirAndFile("$dirName/$item");
                    } else {
                        unlink("$dirName/$item");
                    }
                }
            }
            closedir($handle);
            rmdir($dirName);
        }
    }
}

function recurse_copy($src, $dst)
{
    $dir = opendir($src);
    @mkdir($dst);
    while (false !== ($file = readdir($dir))) {
        if (($file != '.') && ($file != '..')) {
            if (is_dir($src . '/' . $file)) {
                recurse_copy($src . '/' . $file, $dst . '/' . $file);
            } else {
                copy($src . '/' . $file, $dst . '/' . $file);
            }
        }
    }
    closedir($dir);
}

function qqimg($qq)
{
    if ($qq) {
        $qqimg = 'http://q2.qlogo.cn/headimg_dl?bs=qq&dst_uin=' . $qq . '&src_uin=' . $qq . '&fid=' . $qq . '&spec=100&url_enc=0&referer=bu_interface&term_type=PC';
    } else {
        $qqimg = '/assets/img/user.png';
    }
    return $qqimg;

}

?>