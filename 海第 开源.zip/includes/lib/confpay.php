<?php
$type=NOTIFY_TYPE;
$notifyjiepsy=NOTIFY_HTPAY;
$Identification=$_GET['identifi'];

#小薇
if ($Identification=='x' || $type=='xwnotify' || $notifyjiepsy=='xw') {
	if ($type=="xwnotify") {
		$eshang_rand=$DB->query("SELECT * FROM pay_jie where id='{$srow['type_id']}' limit 1")->fetch();
	}else{
		$eshangll=$DB->query("SELECT count(*) from pay_jie where api_type='eshangpay' and status=1")->fetchColumn();
		$eshang=$DB->query("SELECT * FROM pay_jie where api_type='eshangpay' and status=1  order by id desc limit {$eshangll}")->fetchAll();
		$eshangll=unique_rand($eshangll-1);
		$eshang_rand=$eshang[$eshangll];
}
define('MCHS_XW_ID',$eshang_rand['id']);
define('MCHS_ES_ID',$eshang_rand['api_appid']);
define('MCHS_ES_PID',$eshang_rand['api_mck']);
define('MCHS_ES_KEY',$eshang_rand['api_key']);
define('MCHS_ES_URL',$eshang_rand['api_callback']);

}

#微信
if ($Identification=='w' || $type=='wxnotify' || $notifyjiepsy=='wx') {
  if($donlx==1){
	    #H5
		$wxall=$DB->query("SELECT count(*) from pay_jie where api_type='wxpay' and status=1 and donlx=1")->fetchColumn();
		$wx=$DB->query("SELECT * FROM pay_jie where api_type='wxpay' and status=1 and donlx=1 order by id desc limit {$wxall}")->fetchAll();
		$wxall=unique_rand($wxall-1);
		$wx_rand=$wx[$wxall];

	}else if($zzwx=='1'){
		#转账
		$rs_wx=$DB->query("select * from pay_jie where api_type='zzwx' limit 1")->fetch();//获取转账接口配置
	}else if ($type=='wxnotify') {

	    $wx_rand=$DB->query("SELECT * FROM pay_jie where id='{$srow['type_id']}' LIMIT 1")->fetch();//用于回调

    }else{

    	#扫码
		$wxall=$DB->query("SELECT count(*) from pay_jie where api_type='wxpay' and status=1 and donlx<>1")->fetchColumn();
		$wx=$DB->query("SELECT * FROM pay_jie where api_type='wxpay' and status=1 and donlx<>1 order by id desc limit {$wxall}")->fetchAll();
		$wxall=unique_rand($wxall-1);
		$wx_rand=$wx[$wxall];
 }

define('MCHS_W_ID',$wx_rand['id']);
define('MCHS_WX_ID',$wx_rand['api_appid']);
define('MCHS_WX_PID',$wx_rand['api_mck']);
define('MCHS_WX_KEY',$wx_rand['api_key']);
define('MCHS_WX_APP',$wx_rand['api_callback']);
}

// #QQ
if ($Identification=='q' || $type=='qqnotify' || $notifyjiepsy=='qq') {
	if($zzqq=='1'){
		$qq_rand=$DB->query("SELECT * FROM pay_jie where api_type='zzqq' limit 1")->fetch();
	}else if ($type=='qqnotify') {
		$qq_rand=$DB->query("SELECT * FROM pay_jie where id='{$srow['type_id']}' LIMIT 1")->fetch();//用于回调
	}else{
		$qqall=$DB->query("SELECT count(*) from pay_jie where api_type='qqpay' and status=1")->fetchColumn();
	    $qq=$DB->query("SELECT * FROM pay_jie where api_type='qqpay' and status=1  order by id desc limit {$qqall}")->fetchAll();
	    $qqall=unique_rand($qqall-1);
		$qq_rand=$qq[$qqall];
	}
 define('MCHS_Q_ID',$qq_rand['id']);
 define('MCHS_QQ_ID',$qq_rand['api_appid']);
 define('MCHS_QQ_KEY',$qq_rand['api_key']);
 define('MCHS_QQ_USERID',$qq_rand['api_mck']);
 define('MCHS_QQ_USERPWD',$qq_rand['api_callback']);
}


#支付宝当面付
if ($Identification=='d' || $type=='dmnotify' || $notifyjiepsy=='dm') {
	if ($type=='dmnotify') {
		$dmpay_rand=$DB->query("SELECT * FROM pay_jie where id='{$srow['type_id']}' LIMIT 1")->fetch();//用于回调
	}else{
		$dmAll=$DB->query("SELECT count(*) from pay_jie where api_type='dmpay' and status=1")->fetchColumn();
		$dmpay=$DB->query("SELECT * FROM pay_jie where api_type='dmpay' and status=1  order by id desc limit {$dmAll}")->fetchAll();
		$dmAll=unique_rand($dmAll-1);
		$dmpay_rand=$dmpay[$dmAll];
	}
define('MCHS_D_ID',$dmpay_rand['id']);
define('MCHS_DM_ID',$dmpay_rand['api_appid']);
define('MCHS_DM_PID',$dmpay_rand['api_mck']);
define('MCHS_DM_APP',$dmpay_rand['api_callback']);
}

#威富通
if ($Identification=='f' || $type=='wftnotify' || $notifyjiepsy=='wft') {
$wftll=$DB->query("SELECT count(*) from pay_jie where api_type='wftpay' and status=1")->fetchColumn();
$wft=$DB->query("SELECT * FROM pay_jie where api_type='wftpay' and status=1  order by id desc limit {$wftll}")->fetchAll();
$wftll=unique_rand($wftll-1);
$wft_rand=$wft[$wftll];
define('MCHS_F_ID',$wft_rand['id']);
define('MCHS_WFT_ID',$wft_rand['api_appid']);
define('MCHS_WFT_KEY',$wft_rand['api_key']);
}


#易支付
if ($Identification=='e' || $type=='enotify' || $notifyjiepsy=='epay') {
  if($donlx==1){
  	$eall=$DB->query("SELECT count(*) from pay_jie where api_name='{$_GET['type']}' and api_type='epay' and status=1 and donlx=1")->fetchColumn();
	$epay=$DB->query("SELECT * FROM pay_jie where api_name='{$_GET['type']}' and api_type='epay' and status=1 and donlx=1 order by id desc limit {$eall}")->fetchAll();
	$eall=unique_rand($eall-1);
	$epay_rand=$epay[$eall];
 }else if($type=='enotify'){
    $epay_rand=$DB->query("SELECT * FROM pay_jie where id='{$srow['type_id']}' LIMIT 1")->fetch();//用于回调
 }else{
    $eall=$DB->query("SELECT count(*) from pay_jie where api_name='{$_GET['type']}' and api_type='epay' and status=1 and donlx<>1")->fetchColumn();
	$epay=$DB->query("SELECT * FROM pay_jie where api_name='{$_GET['type']}' and api_type='epay' and status=1 and donlx<>1 order by id desc limit {$eall}")->fetchAll();
	$eall=unique_rand($eall-1);
	$epay_rand=$epay[$eall];
}

define('MCHS_EID',$epay_rand['id']);
define('MCHS_E_ID',$epay_rand['api_appid']);
define('MCHS_E_PID',$epay_rand['api_mck']);
define('MCHS_E_KEY',$epay_rand['api_key']);
}
#支付宝
if ($Identification=='a' || $type=='alinotify' || $notifyjiepsy=='ali') {
	if($type=='alinotify'){
		$ali_rand=$DB->query("SELECT * FROM pay_jie where id='{$srow['type_id']}' LIMIT 1")->fetch();//用于回调
	}else{
		$aliall=$DB->query("SELECT count(*) from pay_jie where api_type='alipay' and status=1")->fetchColumn();
		$ali=$DB->query("SELECT * FROM pay_jie where api_type='alipay' and status=1  order by id desc limit {$aliall}")->fetchAll();
		$aliall=unique_rand($aliall-1);
		$ali_rand=$ali[$aliall];
}
define('MCHS_A_ID',$ali_rand['id']);
define('MCHS_ALI_ID',$ali_rand['api_appid']);
define('MCHS_ALI_PID',$ali_rand['api_mck']);
define('MCHS_ALI_KEY',$ali_rand['api_key']);
}
?>