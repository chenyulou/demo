<?php

//数据库更新文件


#后台数据库更新
$DB->exec("ALTER TABLE `pay_admin` ADD `user` VARCHAR(20) NULL COMMENT '管理账号' AFTER `id`");
$DB->exec("ALTER TABLE `pay_admin` ADD `pwd` VARCHAR(30) NULL COMMENT '管理密码' AFTER `user`");
$DB->exec("ALTER TABLE `pay_admin` ADD `local_domain` VARCHAR(30) NULL COMMENT '平台域名' AFTER `pwd`");
$DB->exec("ALTER TABLE `pay_admin` ADD `web_name` VARCHAR(30) NULL COMMENT '网站名称' AFTER `local_domain`");
$DB->exec("ALTER TABLE `pay_admin` ADD `web_qq` VARCHAR(10) NULL COMMENT '	站长QQ' AFTER `web_name`");
$DB->exec("ALTER TABLE `pay_admin` ADD `qqgroup` VARCHAR(100) NULL COMMENT 'QQ加群URL' AFTER `web_qq`");
$DB->exec("ALTER TABLE `pay_admin` ADD `web_id` VARCHAR(10) NULL COMMENT '充值收费ID' AFTER `qqgroup`");
$DB->exec("ALTER TABLE `pay_admin` ADD `web_log` int(11) NULL COMMENT '商户登陆方式' AFTER `web_id`");
$DB->exec("ALTER TABLE `pay_admin` ADD `wxtransfer_desc` VARCHAR(50) NULL COMMENT '微信企业付款说明' AFTER `web_log`");
$DB->exec("ALTER TABLE `pay_admin` ADD `payer_show_name	` VARCHAR(50) NULL COMMENT '支付宝付款方显示姓名' AFTER `wxtransfer_desc`");
$DB->exec("ALTER TABLE `pay_admin` ADD `alipay_appid` VARCHAR(32) NULL COMMENT '支付宝转账应用APPID' AFTER `payer_show_name`");
$DB->exec("ALTER TABLE `pay_admin` ADD `privatekey` VARCHAR(2500) NULL COMMENT '支付宝转账公钥' AFTER `alipay_appid`");
$DB->exec("ALTER TABLE `pay_admin` ADD `money_rate` VARCHAR(10) NULL COMMENT '默认支付分成比例' AFTER `privatekey`");
$DB->exec("ALTER TABLE `pay_admin` ADD `settle_money` VARCHAR(10) NULL COMMENT '提现最小金额' AFTER `money_rate`");
$DB->exec("ALTER TABLE `pay_admin` ADD `settle_money_max` VARCHAR(10) NULL COMMENT '提现最大金额' AFTER `settle_money`");
$DB->exec("ALTER TABLE `pay_admin` ADD `settle_every` VARCHAR(10) NULL COMMENT '每次可结' AFTER `settle_money_max`");
$DB->exec("ALTER TABLE `pay_admin` ADD `is_reg` int(11) NULL COMMENT '是否开启商户注册' AFTER `settle_every`");
$DB->exec("ALTER TABLE `pay_admin` ADD `is_pay` int(11) NULL COMMENT '通道收费' AFTER `is_reg`");
$DB->exec("ALTER TABLE `pay_admin` ADD `is_qqpay` decimal(10,2) NULL COMMENT 'QQ通道费用' AFTER `is_pay`");
$DB->exec("ALTER TABLE `pay_admin` ADD `is_wxpay` decimal(10,2) NULL COMMENT '微信通道费用' AFTER `is_qqpay`");
$DB->exec("ALTER TABLE `pay_admin` ADD `is_wxh5` decimal(10,2) NULL COMMENT '微信H5权限费用' AFTER `is_wxpay`");
$DB->exec("ALTER TABLE `pay_admin` ADD `is_alipay` decimal(10,2) NULL COMMENT '支付宝通道费用' AFTER `is_wxh5`");
$DB->exec("ALTER TABLE `pay_admin` ADD `settle_open` int(11) NULL COMMENT '是否开启商户自结' AFTER `is_alipay`");
$DB->exec("ALTER TABLE `pay_admin` ADD `verifytype` int(11) NULL COMMENT '验证码获取方式' AFTER `settle_open`");
$DB->exec("ALTER TABLE `pay_admin` ADD `stype_1` int(11) NULL COMMENT '是否开启支付宝结算' AFTER `verifytype`");
$DB->exec("ALTER TABLE `pay_admin` ADD `stype_2` int(11) NULL COMMENT '是否开启微信结算' AFTER `stype_1`");
$DB->exec("ALTER TABLE `pay_admin` ADD `stype_3` int(11) NULL COMMENT '是否开启QQ钱包结算' AFTER `stype_2`");
$DB->exec("ALTER TABLE `pay_admin` ADD `stype_4` int(11) NULL COMMENT '是否开启银行卡结算' AFTER `stype_3`");
$DB->exec("ALTER TABLE `pay_admin` ADD `mail_smtp` VARCHAR(30) NULL COMMENT 'SMTP地址' AFTER `stype_4`");
$DB->exec("ALTER TABLE `pay_admin` ADD `mail_port` int(11) NULL COMMENT 'SMTP端口' AFTER `mail_smtp`");
$DB->exec("ALTER TABLE `pay_admin` ADD `mail_name` VARCHAR(30) NULL COMMENT '邮箱账号' AFTER `mail_port`");
$DB->exec("ALTER TABLE `pay_admin` ADD `mail_pwd` VARCHAR(50) NULL COMMENT '邮箱密码（授权码）' AFTER `mail_name`");
$DB->exec("ALTER TABLE `pay_admin` ADD `dx_code` VARCHAR(32) NULL COMMENT '阿里云AppCode' AFTER `mail_pwd`");
$DB->exec("ALTER TABLE `pay_admin` ADD `dx_mb_log` VARCHAR(15) NULL COMMENT '登录模板编号' AFTER `dx_code`");
$DB->exec("ALTER TABLE `pay_admin` ADD `dx_mb_reg` VARCHAR(15) NULL COMMENT '注册模板编号' AFTER `dx_mb_log`");
$DB->exec("ALTER TABLE `pay_admin` ADD `dx_mb_tix` VARCHAR(15) NULL COMMENT '提现模板编号' AFTER `dx_mb_reg`");
$DB->exec("ALTER TABLE `pay_admin` ADD `dx_mb_zhu` VARCHAR(15) NULL COMMENT '找回模板编号' AFTER `dx_mb_tix`");
$DB->exec("ALTER TABLE `pay_admin` ADD `dx_mb_code` VARCHAR(15) NULL COMMENT '验证码模板编号' AFTER `dx_mb_zhu`");
$DB->exec("ALTER TABLE `pay_admin` ADD `bak_type` int(11) NULL COMMENT '备份功能' AFTER `dx_mb_code`");
$DB->exec("ALTER TABLE `pay_admin` ADD `bak_type2` int(11) NULL COMMENT '保存位置' AFTER `bak_type`");
$DB->exec("ALTER TABLE `pay_admin` CHANGE `bak_type2` `bak_type2` VARCHAR(30) NULL DEFAULT NULL COMMENT '阿里云OSS存储目录'");//3.8.7版本更新
$DB->exec("ALTER TABLE `pay_admin` ADD `bak_date` VARCHAR(30) NULL COMMENT '备份时间' AFTER `bak_type2`");
$DB->exec("ALTER TABLE `pay_admin` CHANGE `bak_date` `bak_date` VARCHAR(30) NULL DEFAULT NULL COMMENT '备份相隔时间'");//3.8.7版本更新
$DB->exec("ALTER TABLE `pay_admin` ADD `bak_url` VARCHAR(50) NULL COMMENT 'FTP地址' AFTER `bak_date`");
$DB->exec("ALTER TABLE `pay_admin` CHANGE `bak_url` `bak_url` VARCHAR(30) NULL DEFAULT NULL COMMENT '阿里云OSSKeyId'");//3.8.7版本更新
$DB->exec("ALTER TABLE `pay_admin` ADD `bak_user` VARCHAR(50) NULL COMMENT 'FTP账号' AFTER `bak_url`");
$DB->exec("ALTER TABLE `pay_admin` CHANGE `bak_user` `bak_user` VARCHAR(30) NULL DEFAULT NULL COMMENT '阿里云OSSKeySecret'");//3.8.7版本更新
$DB->exec("ALTER TABLE `pay_admin` ADD `bak_pwd` VARCHAR(50) NULL COMMENT 'FTP密码' AFTER `bak_user`");
$DB->exec("ALTER TABLE `pay_admin` CHANGE `bak_pwd` `bak_pwd` VARCHAR(50) NULL DEFAULT NULL COMMENT '阿里云OSS访问域名'");//3.8.7版本更新
$DB->exec("ALTER TABLE `pay_admin` ADD `CAPTCHA_ID` VARCHAR(150) NULL COMMENT '极限验证码id' AFTER `bak_pwd`");
$DB->exec("ALTER TABLE `pay_admin` ADD `PRIVATE_KEY` VARCHAR(150) NULL COMMENT '极限验证码key' AFTER `CAPTCHA_ID`");
$DB->exec("ALTER TABLE `pay_admin` ADD `Login` int(11) NULL COMMENT '登录提醒' AFTER `PRIVATE_KEY`");
$DB->exec("ALTER TABLE `pay_admin` ADD `gxdate` int(11) NULL COMMENT '更新提醒' AFTER `Login`");
$DB->exec("ALTER TABLE `pay_admin` ADD `gxm` VARCHAR(50) NULL COMMENT '更新码' AFTER `gxdate`");
$DB->exec("ALTER TABLE `pay_admin` ADD `postlj` int(11) NULL COMMENT 'POST拦截' AFTER `gxm`");
$DB->exec("ALTER TABLE `pay_admin` ADD `getlj` int(11) NULL COMMENT 'GET拦截' AFTER `postlj`");
$DB->exec("ALTER TABLE `pay_admin` ADD `cookielj` int(11) NULL COMMENT 'cookie拦截' AFTER `getlj`");
$DB->exec("ALTER TABLE `pay_admin` ADD `paylj` int(11) NULL COMMENT '支付拦截' AFTER `cookielj`");
$DB->exec("ALTER TABLE `pay_admin` ADD `ljname` VARCHAR(1000) NULL COMMENT '拦截内容' AFTER `paylj`");
$DB->exec("ALTER TABLE `pay_admin` ADD `smrz` int(11) NULL COMMENT '实名认证' AFTER `ljname`");
$DB->exec("ALTER TABLE `pay_admin` ADD `shourz` VARCHAR(64) NULL COMMENT '手机认证AppCode' AFTER `smrz`");
$DB->exec("ALTER TABLE `pay_admin` ADD `sfyz_code` VARCHAR(64) NULL COMMENT '身份认证AppCode	' AFTER `shourz`");
$DB->exec("ALTER TABLE `pay_admin` ADD `yhkrz_code` VARCHAR(64) NULL COMMENT '银行认证AppCode' AFTER `sfyz_code`");
$DB->exec("ALTER TABLE `pay_admin` ADD `sjrz` int(11) NULL COMMENT '手机认证' AFTER `yhkrz_code`");
$DB->exec("ALTER TABLE `pay_admin` ADD `sfrz` int(11) NULL COMMENT '身份认证' AFTER `sjrz`");
$DB->exec("ALTER TABLE `pay_admin` ADD `yhrz` int(11) NULL COMMENT '银行认证' AFTER `sfrz`");
$DB->exec("ALTER TABLE `pay_admin` ADD `adminurl` VARCHAR(30) NULL COMMENT '后台目录' AFTER `yhrz`");
$DB->exec("ALTER TABLE `pay_admin` ADD `qq_login` int(11) NULL COMMENT 'QQ登录' AFTER `adminurl`");
$DB->exec("ALTER TABLE `pay_admin` ADD `wx_login` int(11) NULL COMMENT '微信登陆' AFTER `qq_login`");
$DB->exec("ALTER TABLE `pay_admin` ADD `yuezz` int(11) NULL COMMENT '余额转账' AFTER `wx_login`");
$DB->exec("ALTER TABLE `pay_admin` ADD `lyhbd` int(11) NULL COMMENT '老用户绑定' AFTER `yuezz`");
$DB->exec("ALTER TABLE `pay_admin` ADD `protocol` VARCHAR(5) NULL COMMENT '访问协议' AFTER `lyhbd`");

#商户数据库更新
$DB->exec("ALTER TABLE `pay_user` ADD `user` VARCHAR(30) NULL COMMENT '商户账号' AFTER `id`");
$DB->exec("ALTER TABLE `pay_user` ADD `pwd` VARCHAR(30) NULL COMMENT '商户密码' AFTER `user`");
$DB->exec("ALTER TABLE `pay_user` ADD `key` VARCHAR(32) NULL COMMENT '私密' AFTER `pwd`");
$DB->exec("ALTER TABLE `pay_user` ADD `account` VARCHAR(32) NULL COMMENT '结算账号' AFTER `key`");
$DB->exec("ALTER TABLE `pay_user` ADD `accounts` VARCHAR(10) NULL COMMENT '行业类型' AFTER `account`");
$DB->exec("ALTER TABLE `pay_user` ADD `username` VARCHAR(30) NULL COMMENT '姓名' AFTER `account`");
$DB->exec("ALTER TABLE `pay_user` ADD `alipay_appid` VARCHAR(30) NULL COMMENT '' AFTER `username`");
$DB->exec("ALTER TABLE `pay_user` ADD `alipay_uid` VARCHAR(32) NULL COMMENT '' AFTER `alipay_appid`");
$DB->exec("ALTER TABLE `pay_user` ADD `qq_uid` VARCHAR(200) NULL COMMENT '' AFTER `alipay_uid`");
$DB->exec("ALTER TABLE `pay_user` ADD `qq_name` VARCHAR(50) NULL COMMENT 'QQ名称' AFTER `qq_uid`");
$DB->exec("ALTER TABLE `pay_user` ADD `money` decimal(10,2) NULL COMMENT '商户余额' AFTER `qq_name`");
$DB->exec("ALTER TABLE `pay_user` ADD `settle_id` int(1) NULL COMMENT '结算方式' AFTER `money`");
$DB->exec("ALTER TABLE `pay_user` ADD `email` VARCHAR(50) NULL COMMENT '商户邮箱' AFTER `settle_id`");
$DB->exec("ALTER TABLE `pay_user` ADD `phone` VARCHAR(11) NULL COMMENT '商户手机号' AFTER `email`");
$DB->exec("ALTER TABLE `pay_user` ADD `qq` VARCHAR(10) NULL COMMENT '商户QQ' AFTER `phone`");
$DB->exec("ALTER TABLE `pay_user` ADD `wxid` VARCHAR(32) NULL COMMENT '	微信openid' AFTER `qq`");
$DB->exec("ALTER TABLE `pay_user` ADD `wx_name` VARCHAR(50) NULL COMMENT '微信名称' AFTER `wxid`");
$DB->exec("ALTER TABLE `pay_user` ADD `url` VARCHAR(50) NULL COMMENT '用户域名' AFTER `wx_name`");
$DB->exec("ALTER TABLE `pay_user` ADD `addtime` datetime NULL COMMENT '注册时间' AFTER `url`");
$DB->exec("ALTER TABLE `pay_user` ADD `apply` int(1) 0 COMMENT '' AFTER `addtime`");
$DB->exec("ALTER TABLE `pay_user` ADD `level` int(1) 1 COMMENT '' AFTER `apply`");
$DB->exec("ALTER TABLE `pay_user` ADD `type` int(1) 0 COMMENT '' AFTER `level`");
$DB->exec("ALTER TABLE `pay_user` ADD `active` int(1) 0 COMMENT '' AFTER `type`");
$DB->exec("ALTER TABLE `pay_user` CHANGE `rate` `rate_qq` VARCHAR(8) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'QQ通道率费' AFTER `active`");
$DB->exec("ALTER TABLE `pay_user` ADD `rate_qq` VARCHAR(8) NULL COMMENT 'QQ通道率费' AFTER `active`");
$DB->exec("ALTER TABLE `pay_user` ADD `rate_wx` VARCHAR(8) NULL COMMENT '微信通道率费' AFTER `rate_qq`");
$DB->exec("ALTER TABLE `pay_user` ADD `rate_ali` VARCHAR(8) NULL COMMENT '支付宝通道率费' AFTER `rate_wx`");
$DB->exec("ALTER TABLE `pay_user` ADD `rate_wxh5` VARCHAR(8) NULL COMMENT '微信H5通道率费' AFTER `rate_ali`");
$DB->exec("ALTER TABLE `pay_user` ADD `wxh5pay` VARCHAR(20) NULL COMMENT '微信H5权限' AFTER `alipay`");
$DB->exec("ALTER TABLE `pay_user` CHANGE `wxh5pay` `wxh5pay` INT NULL DEFAULT NULL COMMENT '微信H5权限'");
$DB->exec("ALTER TABLE `pay_user` ADD `zfmm` int(6) NULL COMMENT '支付密码' AFTER `wxh5pay`");
$DB->exec("ALTER TABLE `pay_user` ADD `sfzhm` VARCHAR(18) NULL COMMENT '身份证号码' AFTER `zfmm`");
$DB->exec("ALTER TABLE `pay_user` ADD `xieyi` INT NULL COMMENT '协议同意' AFTER `sfzhm`");
$DB->exec("ALTER TABLE `pay_user` ADD `sj_rz` INT NULL COMMENT '手机认证' AFTER `xieyi`");
$DB->exec("ALTER TABLE `pay_user` ADD `sf_rz` INT NULL COMMENT '身份认证' AFTER `sj_rz`"); 
$DB->exec("ALTER TABLE `pay_user` ADD `yh_rz` INT NULL COMMENT '银行认证' AFTER `sf_rz`");
$DB->exec("ALTER TABLE `pay_user` ADD `Bank` VARCHAR(18) NULL COMMENT '银行卡号' AFTER `yh_rz`");



#接口数据库更新
$DB->exec("ALTER TABLE `pay_jie` ADD `name` VARCHAR(20) NULL COMMENT '接口名称' AFTER `id`");
$DB->exec("ALTER TABLE `pay_jie` ADD `api_name` VARCHAR(30) NULL COMMENT '接口类型' AFTER `name`");
$DB->exec("ALTER TABLE `pay_jie` ADD `api_type` VARCHAR(30) NULL COMMENT '接口标识' AFTER `api_name`");
$DB->exec("ALTER TABLE `pay_jie` ADD `api_appid` VARCHAR(50) NULL COMMENT '接口ID' AFTER `api_type`");
$DB->exec("ALTER TABLE `pay_jie` ADD `api_key` VARCHAR(50) NULL COMMENT '接口密钥' AFTER `api_appid`");
$DB->exec("ALTER TABLE `pay_jie` ADD `api_mck` VARCHAR(2000) NULL COMMENT '通用字段' AFTER `api_key`");
$DB->exec("ALTER TABLE `pay_jie` ADD `api_callback` VARCHAR(2000) NULL COMMENT '通用字段' AFTER `api_mck`");
$DB->exec("ALTER TABLE `pay_jie` ADD `status` INT NULL DEFAULT '0' COMMENT '接口状态' AFTER `api_callback`");
$DB->exec("ALTER TABLE `pay_jie` ADD `api_shaui` VARCHAR(30) NULL COMMENT '	通道率费' AFTER `status`");
$DB->exec("ALTER TABLE `pay_jie` ADD `donlx` INT NULL COMMENT '微信通道H5' AFTER `api_shaui`");

$DB->exec("ALTER TABLE `pay_jie` CHANGE `api_name` `api_name` VARCHAR(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '接口类型'");
$DB->exec("ALTER TABLE `pay_jie` CHANGE `api_type` `api_type` VARCHAR(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '接口标识'");



#订单数据库更新

$DB->exec("ALTER TABLE `pay_order` ADD `type_id` VARCHAR(20) NULL COMMENT '接口id' AFTER `status`");
$DB->exec("ALTER TABLE `pay_order` ADD `uid` VARCHAR(20) NULL DEFAULT '0' AFTER `buyer`");

#余额流向记录更新

$DB->exec("CREATE TABLE `pay_money` (`id` int(11) NOT NULL,`uid` varchar(20) NOT NULL COMMENT '商户ID',`name` varchar(20) NOT NULL COMMENT '流向类型',`money` varchar(10) NOT NULL COMMENT '流向余额',`addmoney` varchar(10) NOT NULL COMMENT '流向后余额',`time` datetime NOT NULL COMMENT '流向时间') ENGINE=InnoDB DEFAULT CHARSET=utf8");
$DB->exec("ALTER TABLE `pay_money` ADD PRIMARY KEY (`id`)");
$DB->exec("ALTER TABLE `pay_money` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1");

#备份记录数据库更新
$DB->exec("ALTER TABLE `pay_bak` ADD PRIMARY KEY( `id`)");//3.8.7版本更新
$DB->exec("ALTER TABLE `pay_bak` CHANGE `id` `id` INT(11) NOT NULL AUTO_INCREMENT");//3.8.7版本更新
$DB->exec("ALTER TABLE `pay_bak` CHANGE `active` `active` VARCHAR(30) NOT NULL");//3.8.7版本更新

#插件数据库更新
$DB->exec("CREATE TABLE `pay_plug` (`id` int(11) NOT NULL, `type` varchar(20) DEFAULT NULL COMMENT '类型', `name` varchar(20) DEFAULT NULL COMMENT '名称', `logimg` varchar(200) DEFAULT NULL COMMENT 'logo照片', `title` varchar(300) DEFAULT NULL COMMENT '介绍内容', `author` varchar(5) DEFAULT NULL COMMENT '插件作者', `download` varchar(400) DEFAULT NULL COMMENT '下载地址', `time` datetime DEFAULT NULL COMMENT '发布时间') ENGINE=InnoDB DEFAULT CHARSET=utf8");
$DB->exec("ALTER TABLE `pay_plug` ADD PRIMARY KEY (`id`)");
$DB->exec("ALTER TABLE `pay_plug` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1");

#数据库索引更新
$DB->exec("ALTER TABLE `pays`.`pay_order` ADD INDEX `pid` (`pid`)");
$DB->exec("ALTER TABLE `pays`.`pay_order` ADD INDEX `addtime` (`addtime`)");
$DB->exec("ALTER TABLE `pays`.`pay_order` ADD INDEX `endtime` (`endtime`)");
$DB->exec("ALTER TABLE `pays`.`pay_order` ADD INDEX `out_trade_no` (`out_trade_no`)");


?>
