<?php
//威富通配置文件
class Config{
    private $cfg = array(
        'mchId'=> MCHS_WFT_ID,//'288510019978',//商户号
        'key'=> MCHS_WFT_KEY,//'3a00bdbbf681c513335441c6b0c40568',//商户密钥
        'version'=>'2.0'
       );
    
    public function C($cfgName){
        return $this->cfg[$cfgName];
    }
}
?>