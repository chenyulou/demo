<?php
/*易商户支付配置*/
return [
    'app_key' => MCHS_ES_KEY, //用户中心开发设置中获取
    'app_url' => MCHS_ES_URL,//接口地址
    'app_secret' => MCHS_ES_PID, //用户中心开发设置中获取
    'sub_mch_id' => MCHS_ES_ID,  //https://1shanghu.com/user/wechat/certification 获取
    'notify' => $payurl.'/content/Payment/Esnemt/eshanghu_notify.php', //回调地址
];
?>