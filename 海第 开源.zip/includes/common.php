<?php

error_reporting(0);

define('SYSTEM_ROOT', dirname(__FILE__).'/');

define('ROOT', dirname(SYSTEM_ROOT).'/');

date_default_timezone_set('Asia/Shanghai');

$jt = date("Y-m-d");//当前时间

$zt = date("Y-m-d",strtotime("-1 day"));//昨天时间

$mt = date("Y-m-d",strtotime("+1 day"));//今天时间

$date = date("Y-m-d H:i:s");

session_start();

$php=phpversion();

$zipurl="http://newt.haidism.cn";//删除则无法获取更新

if(is_file(ROOT.'content/360safe/360webscan.php')){//360网站卫士
    require_once(ROOT.'content/360safe/360webscan.php');
}

$arr = $_POST;
foreach($arr as $k=>$v){
$_POST[$k] = htmlspecialchars($v);
}
$arr = $_GET;
foreach($arr as $k=>$v){
$_GET[$k] = htmlspecialchars($v);
}

require ROOT.'config.php';
try {
    $DB = new PDO("mysql:host={$dbconfig['host']};dbname={$dbconfig['dbname']};port={$dbconfig['port']}",$dbconfig['user'],$dbconfig['pwd']);
}catch(Exception $e){
	exit('链接数据库失败:'.$e->getMessage().'<hr>为什么会失败？可能没有配置或者配置账号密码错误或者数据库没有数据');
}
$DB->exec("set names utf8");
$conf=$DB->query("select * from pay_admin where id='1' limit 1")->fetch();
if(!$conf['local_domain'])$conf['local_domain']=$_SERVER['HTTP_HOST'];
$password_hash='!@#%!s!0';

$scriptpath=str_replace('\\','/',$_SERVER['SCRIPT_NAME']);
$sitepath = substr($scriptpath, 0, strrpos($scriptpath, '/'));
$siteurl = $conf['protocol'].'://'.$_SERVER['HTTP_HOST'].$sitepath.'/';

$payurl=$conf['protocol'].'://'.$_SERVER['HTTP_HOST'].'/';

$begin_timedata = array(

    date("Y-m-d " . "00:00:00", strtotime('-6 day')),
    date("Y-m-d " . "00:00:00", strtotime('-5 day')),
    date("Y-m-d " . "00:00:00", strtotime('-4 day')),
    date("Y-m-d " . "00:00:00", strtotime('-3 day')),
    date("Y-m-d " . "00:00:00", strtotime('-2 day')),
    date("Y-m-d " . "00:00:00", strtotime('-1 day')),
    date("Y-m-d " . "00:00:00", strtotime('0 day')),
);

$end_timedata = array(

    date("Y-m-d " . "23:59:59", strtotime('-6 day')),
    date("Y-m-d " . "23:59:59", strtotime('-5 day')),
    date("Y-m-d " . "23:59:59", strtotime('-4 day')),
    date("Y-m-d " . "23:59:59", strtotime('-3 day')),
    date("Y-m-d " . "23:59:59", strtotime('-2 day')),
    date("Y-m-d " . "23:59:59", strtotime('-1 day')),
    date("Y-m-d " . "23:59:59", strtotime('0 day')),
);

     $end_timedata2 = array(

    date("Y-m-d " , strtotime('-6 day')),
    date("Y-m-d " , strtotime('-5 day')),
    date("Y-m-d " , strtotime('-4 day')),
    date("Y-m-d " , strtotime('-3 day')),
    date("Y-m-d " , strtotime('-2 day')),
    date("Y-m-d " , strtotime('-1 day')),
    date("Y-m-d ", strtotime('0 day')),
);
function unique_rand($max) {
    if ($max<=0) {
        return false;
    }else{
        //从0开始选择
        $min = 0;
        //获取多少个数据数
        $num = 1;
        //初始化变量为0
        $count = 0;
        //建一个新数组
        $return = array();
        while ($count < $num) {
        //在一定范围内随机生成一个数放入数组中
        $return[] = mt_rand($min, $max);
        //去除数组中的重复值用了“翻翻法”，就是用array_flip()把数组的key和value交换两次。这种做法比用 array_unique() 快得多。
        $return = array_flip(array_flip($return));
        //将数组的数量存入变量count中
        $count = count($return);
        }
        //为数组赋予新的键名
        shuffle($return);
        return $return[0];
    }
}
//QQ互联appid
$QC_config["appid"]  = 101786497;

//QQ互联appkey
$QC_config["appkey"] = "17384586d70fdcc06619473fdd349239";

//callback url
$QC_config["callback"] = 'http://cspay.haidism.cn/user/connect.php';
include_once(SYSTEM_ROOT."lib/QC.class.php");
include_once(SYSTEM_ROOT."lib/confpay.php");
require_once(SYSTEM_ROOT."pay/alipay/alipay_core.function.php");
require_once(SYSTEM_ROOT."pay/alipay/alipay_md5.function.php");
include_once(SYSTEM_ROOT."lib/svgicon.php");
include_once(SYSTEM_ROOT."lib/version.php");
include_once(SYSTEM_ROOT."lib/function.php");
include_once(SYSTEM_ROOT."lib/member.php");
$is_mobile=is_mobile();

if(substr($php,0,1)<7)sysmsg('为了保证程序正常使用，请使用PHP7.0或者以上版本！');

if (!file_exists(ROOT.'content/storage/udatesql.lock')) {
    include(SYSTEM_ROOT."lib/mysql.php");//更新数据库
    file_put_contents(ROOT.'content/storage/udatesql.lock', '数据库更新检测文件');//生成数据库检测文件
}

unlink(ROOT . 'user/default.php');
unlink(ROOT . 'admin/default.php');
?>