<?php
require './includes/common.php';

$act      = isset($_GET['act']) ? daddslashes($_GET['act']) : null;
$url      = daddslashes($_GET['url']);
$authcode = daddslashes($_GET['authcode']);
if ($act == 'add') {
    exit('{"code":-4,"msg":"当前接口仅作为备用接口使用"}');
    $type = 1;
    $key  = random(32);
    $sds  = $DB->exec("INSERT INTO `pay_user` (`key`, `url`, `addtime`, `type`, `active`) VALUES ('{$key}', '{$url}', '{$date}', '{$type}', '1')");
    $pid  = $DB->lastInsertId();

    if ($sds) {
        $result = array("code" => 1, "msg" => "添加支付商户成功！", "pid" => $pid, "key" => $key, "type" => $type);
    } else {
        $result = array("code" => -1, "msg" => "添加支付商户失败！");
    }
} elseif ($act == 'apply') {
    $token = daddslashes($_GET['token']);
    $row   = $DB->query("SELECT * FROM panel_user WHERE token='{$token}' limit 1")->fetch();
    if ($row && $row['active'] == 1) {
        $type = 0;
        $key  = random(32);
        $sds  = $DB->exec("INSERT INTO `pay_user` (`key`, `url`, `addtime`, `type`, `active`, `uid`) VALUES ('{$key}', '{$url}', '{$date}', '{$type}', '1', '{$row['id']}')");
        $pid  = $DB->lastInsertId();

        if ($sds) {
            $result = array("code" => 1, "msg" => "添加支付商户成功！", "pid" => $pid, "key" => $key, "type" => $type);
        } else {
            $result = array("code" => -1, "msg" => "添加支付商户失败！");
        }
    } else {
        $result = array("code" => -1, "msg" => "TOKEN ERROR");
    }
} elseif ($act == 'query') {
    $pid = intval($_GET['pid']);
    $key = daddslashes($_GET['key']);
    $row = $DB->query("SELECT * FROM pay_user WHERE id='{$pid}' limit 1")->fetch();
    if ($row) {
        if ($key == $row['key']) {
            $orders = $DB->query("SELECT count(*) from pay_order WHERE pid={$pid}")->fetchColumn();

            $lastday     = date("Y-m-d", strtotime("-1 day")) . ' 00:00:00';
            $today       = date("Y-m-d") . ' 00:00:00';
            $order_today = $DB->query("SELECT sum(money) from pay_order where pid={$pid} and status=1 and endtime>='$today'")->fetchColumn();

            $order_lastday = $DB->query("SELECT sum(money) from pay_order where pid={$pid} and status=1 and endtime>='$lastday' and endtime<'$today'")->fetchColumn();

            //$settle_money=$DB->query("SELECT sum(money) from pay_settle where pid={$pid} and status=1")->fetchColumn();

            $result = array("code" => 1, "pid" => $pid, "key" => $key, "type" => $row['settle_id'], "active" => $row['active'], "money" => $row['money'], "account" => $row['account'], "username" => $row['username'], "settle_money" => $conf['settle_money'], "settle_fee" => $conf['settle_fee'], "money_rate" => $conf['money_rate'], "orders" => $orders, "order_today" => $order_today, "order_lastday" => $order_lastday);
        } else {
            $result = array("code" => -2, "msg" => "KEY校验失败");
        }
    } else {
        $result = array("code" => -3, "msg" => "PID不存在");
    }
} elseif ($act == 'change') {
    $pid      = intval($_GET['pid']);
    $key      = daddslashes($_GET['key']);
    $stype    = daddslashes($_GET['type']);
    $account  = daddslashes($_GET['account']);
    $username = daddslashes($_GET['username']);
    $row      = $DB->query("SELECT * FROM pay_user WHERE id='{$pid}' limit 1")->fetch();
    if ($row) {
        if ($key == $row['key']) {
            if ($account == null || $username == null) {
                $result = array("code" => -1, "msg" => "保存错误,请确保每项都不为空!");
            } elseif ($row['type'] != 2 && !empty($row['account']) && !empty($row['username']) && $row['account'] != $account) {
                $result = array("code" => -1, "msg" => "为保障您的资金安全，暂不支持直接修改结算账号信息，如需修改请联系QQ" . $conf['web_qq']);
            } else {
                $type = 1;
                $sds  = $DB->exec("update `pay_user` set `account`='{$account}',`username`='{$username}',`type`='{$type}',`settle_id`='{$stype}',`url`='{$url}' where id='{$pid}' limit 1");
                if ($sds >= 0) {
                    $result = array("code" => 1, "msg" => "修改收款账号成功！", "pid" => $pid, "key" => $key, "type" => $type);
                } else {
                    $result = array("code" => -1, "msg" => "修改收款账号失败！");
                }
            }
        } else {
            $result = array("code" => -2, "msg" => "KEY校验失败");
        }
    } else {
        $result = array("code" => -3, "msg" => "PID不存在");
    }
} elseif ($act == 'settle') {
    $pid   = intval($_GET['pid']);
    $key   = daddslashes($_GET['key']);
    $limit = $_GET['limit'] ? intval($_GET['limit']) : 10;
    if ($limit > 50) {
        $limit = 50;
    }

    $row = $DB->query("SELECT * FROM pay_user WHERE id='{$pid}' limit 1")->fetch();
    if ($row) {
        if ($key == $row['key']) {
            $rs = $DB->query("SELECT * FROM pay_settle WHERE pid='{$pid}' order by id desc limit {$limit}");
            while ($row = $rs->fetch()) {
                $data[] = $row;
            }
            if ($rs) {
                $result = array("code" => 1, "msg" => "查询结算记录成功！", "pid" => $pid, "key" => $key, "type" => $type, "data" => $data);
            } else {
                $result = array("code" => -1, "msg" => "查询结算记录失败！");
            }
        } else {
            $result = array("code" => -2, "msg" => "KEY校验失败");
        }
    } else {
        $result = array("code" => -3, "msg" => "PID不存在");
    }
} elseif ($act == 'order') {
    $pid = intval($_GET['pid']);
    $key = daddslashes($_GET['key']);
    $row = $DB->query("SELECT * FROM pay_user WHERE id='{$pid}' limit 1")->fetch();
    if ($row) {
        if ($key == $row['key']) {
            if (isset($_GET['trade_no'])) {
                $trade_no = daddslashes($_GET['trade_no']);
                $row      = $DB->query("SELECT * FROM pay_order WHERE pid='{$pid}' and trade_no='{$trade_no}' limit 1")->fetch();
            } elseif (isset($_GET['out_trade_no'])) {
                $out_trade_no = daddslashes($_GET['out_trade_no']);
                $row          = $DB->query("SELECT * FROM pay_order WHERE pid='{$pid}' and out_trade_no='{$out_trade_no}' limit 1")->fetch();
            } else {
                exit('{"code":-4,"msg":"参数不完整"}');
            }
            if ($row) {
                $result = array("code" => 1, "msg" => "查询订单号成功！", "trade_no" => $row['trade_no'], "out_trade_no" => $row['out_trade_no'], "type" => $row['type'], "pid" => $row['pid'], "addtime" => $row['addtime'], "endtime" => $row['endtime'], "name" => $row['name'], "money" => $row['money'], "status" => $row['status']);
            } else {
                $result = array("code" => -1, "msg" => "订单号不存在");
            }
        } else {
            $result = array("code" => -2, "msg" => "KEY校验失败");
        }
    } else {
        $result = array("code" => -3, "msg" => "PID不存在");
    }
} elseif ($act == 'orders') {
    $pid   = intval($_GET['pid']);
    $key   = daddslashes($_GET['key']);
    $limit = $_GET['limit'] ? intval($_GET['limit']) : 10;
    if ($limit > 50) {
        $limit = 50;
    }

    $row = $DB->query("SELECT * FROM pay_user WHERE id='{$pid}' limit 1")->fetch();
    if ($row) {
        if ($key == $row['key']) {
            $rs = $DB->query("SELECT * FROM pay_order WHERE pid='{$pid}' order by trade_no desc limit {$limit}");
            while ($row = $rs->fetch()) {
                $data[] = $row;
            }
            if ($rs) {
                $result = array("code" => 1, "msg" => "查询订单记录成功！", "data" => $data);
            } else {
                $result = array("code" => -1, "msg" => "查询订单记录失败！");
            }
        } else {
            $result = array("code" => -2, "msg" => "KEY校验失败");
        }
    } else {
        $result = array("code" => -3, "msg" => "PID不存在");
    }
} elseif ($act == 'downAndunZip') {

    include "./includes/lib/mysql.php";

    $arr = file_get_contents($zipurl . '/newt.php?url=' . $_SERVER['HTTP_HOST'] . '&gxm=' . $conf['gxm']);

    var_dump($arr);

    $data = json_decode($arr, true);

    $version = $data['version'];

    if ($version > $vin) {

        $url = $data['zipaddress'] . urlencode(iconv("GB2312", "UTF-8", $data['zipname']));

        $filename = "Update.zip";

        $res = getFile($url, ROOT, $filename, 1);

        if ($res != true) {
            exit('{"code":-1,"msg":"更新包不存在，或者下载失败！"}');
        }

        $size = get_zip_originalsize(ROOT . $filename, ROOT);

        if ($size != true) {
            exit('{"code":-1,"msg":"' . $size . '"}');
        }
        $msg = $conf['web_name'] . '-更新通知！'; //邮件标题
        if ($conf['gxdate'] == 1) {
            $result = send_mail($conf['mail_name'], $msg, "嗨！亲爱的站长，你操作易支付程序更新成功啦！已经更新至V" . $version . "，具体更新内容请在平台中查看！"); //发送邮件
        }
        unlink(ROOT . $filename);
        $config = "<?php
\$vin = '{$version}';
\$tmie = '{$date}';
\$display = '1';
?>
";
        file_put_contents(SYSTEM_ROOT . 'lib/version.php', $config); //更新·本地版本号
        if ($conf['adminurl'] != 'admin') {
            unlink(ROOT . 'content/storage/udatesql.lock'); //删除数据库更新检测文件
            recurse_copy(ROOT . 'admin', ROOT . $conf['adminurl']);
            del_DirAndFile(ROOT . 'admin');
            exit('{"code":1,"msg":"程序更新完毕！"}');
        } else {
            unlink(ROOT . 'content/storage/udatesql.lock'); //删除数据库检测文件
            exit('{"code":1,"msg":"程序更新完毕！"}');
        }
    } else {
        exit('{"code":-1,"msg":"无新版本更新！"}');
    }

} else if ($act == 'bak') {

    require "./content/alioss/alioss.php";

    $res = $DB->query("show tables");

    $row = $DB->query("select * from `pay_bak` order by `time` desc limit 1")->fetch();

    $t = date("Y-m-d H:i:s", time() - 60 * $conf['bak_date']);
    if ($conf['bak_type'] == 1) {

        if ($t > $row['time']) {

            while ($t = $res->fetch()) {
                $table = $t[0];
                $q2    = $DB->query("show create table `$table`");
                $sql   = $q2->fetch();
                $mysql .= $sql['Create Table'] . ";\n";

                $q3 = $DB->query("select * from `$table`");
                while ($data = $q3->fetch(\PDO::FETCH_ASSOC)) {
                    $keys = array_keys($data);
                    $keys = array_map('addslashes', $keys);
                    $keys = join('`,`', $keys);
                    $keys = "`" . $keys . "`";
                    $vals = array_values($data);

                    $vals = array_map('addslashes', $vals);

                    $vals = join("','", $vals);
                    $vals = "'" . $vals . "'";
                    $mysql .= "insert into `$table`($keys) values($vals);\n";
                }
                $mysql .= "\n";
            }
#保存文件位置
            $filen = 'content/backups/' . date('YmjHis') . ".sql";

            $fp = fopen($filen, 'w'); //生成文件

            $tp = fputs($fp, $mysql); //写入文件

            if ($tp) {
                $result = array('code' => 0, 'msg' => '文件下载成功！');
                #执行上传的阿里云OSS
                $aliyun = new AliYunUpload($conf['bak_url'], $conf['bak_user'], $conf['bak_pwd'], $conf['bak_type2']);

                $ailoss = $aliyun->upLocalFiles($_SERVER["DOCUMENT_ROOT"] . '/' . $filen);

                if ($ailoss) {
                    $result = array('code' => 0, 'msg' => '数据库已经备份至你的阿里云OSS！');
                    #插入备份记录
                    $DB->exec("INSERT INTO `pay_bak` (`name`, `time`, `active`, `wan`) VALUES ('{$ailoss['error']}', '{$date}', '{$ailoss['dst']}', '1')");
                    $DB->lastInsertId();
                }
#删除本地存储的数据库文件
                unlink('./' . $filen);
            }
        } else {

            $result = "Sorry! The condition is not met.";

        }

    } else {
        $result = "未开启备份功能！";
    }

} else if ($act == 'cron') {

    $thtime = date("Y-m-d") . ' 00:00:00';
    $row    = $DB->query("SELECT * FROM pay_batch WHERE time>='{$thtime}' limit 1")->fetch();
    if ($row) {
        exit('batch list is already created');
    }

    $limit = '1000';

    $rs = $DB->query("SELECT * from pay_user where money>='{$conf['settle_money']}' and account is not null and username is not null and type!=2 limit {$limit}");

    $batch    = date("Ymd") . rand(111, 999);
    $i        = 0;
    $allmoney = 0;
    while ($row = $rs->fetch()) {
        $i++;
        $allmoneys = $row['money'];
        $fee       = round($row['money'] * $conf['settle_rate'], 2);

        if ($fee < $conf['settle_fee_min']) {
            $fee = $conf['settle_fee_min'];
        }

        if ($fee > $conf['settle_fee_max']) {
            $fee = $conf['settle_fee_max'];
        }

        $row['money'] = $row['money'] - $fee;

        $DB->exec("update `pay_user` set `money`='0',`apply`='1' where `id`='{$row['id']}'");

        $DB->exec("INSERT INTO `pay_money` (`uid`, `name`, `money`, `addmoney`, `time`) VALUES ('{$row['id']}', '结算', '-{$row['money']}', '0', '{$date}')");

        $DB->exec("INSERT INTO `pay_settle` (`pid`, `batch`, `type`, `username`, `account`, `money`,`allmoney`, `fee`, `time`, `status`) VALUES ('{$row['id']}', '{$batch}', '{$row['settle_id']}', '{$row['username']}', '{$row['account']}', '{$row['money']}','{$allmoneys}', '{$fee}', '{$date}', '1')");

        $allmoney += $row['money'];

    }
    $DB->exec("INSERT INTO `pay_batch` (`batch`, `allmoney`, `time`, `status`) VALUES ('{$batch}', '{$allmoney}', '{$date}', '0')");

    exit('{"code":0,"msg":"生成成功！"}');

} else {
    $result = array("code" => -5, "msg" => "No Act!");
}

echo json_encode($result);
