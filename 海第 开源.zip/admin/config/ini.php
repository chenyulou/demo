<?php

	$jt = date("Y-m-d");//当前时间

	$today=date("Y-m-d").' 00:00:00';
	
	$zt = date("Y-m-d",strtotime("-1 day"));//昨天时间
	
	$mt = date("Y-m-d",strtotime("+1 day"));//今天时间

	$lastday=date("Y-m-d",strtotime("-1 day")).' 00:00:00';

	$mysqlversion=$DB->query("select VERSION()")->fetch();

	$count1=$DB->query("SELECT count(*) from pay_order")->fetchColumn();

	$count2=$DB->query("SELECT count(*) from pay_user")->fetchColumn();

	$count3=$DB->query("SELECT count(*) from pay_email")->fetchColumn();

	$count4=$DB->query("SELECT count(*) from pay_settle where status=3")->fetchColumn();

	$jt_dd=$DB->query("SELECT count(*) from pay_order where addtime >= '".$jt."' and addtime < '".$mt."'")->fetchColumn();

	$sum = $DB->query("SELECT sum(money) from pay_order where status = 1")->fetchColumn();

    $today=$DB->query("SELECT sum(money) from pay_order where status=1 and endtime>='$today'")->fetchColumn();

	$jt_sum = $DB->query("SELECT sum(money) from pay_order where status = 1 and addtime >= '".$jt."' and addtime < '".$mt."'")->fetchColumn();
	
	$zt_sum = $DB->query("SELECT sum(money) from pay_order where status = 1 and addtime >= '".$zt."' and addtime < '".$jt."'")->fetchColumn();

	$jt_alipay=$DB->query("SELECT sum(money) from pay_order where status = 1 and type = 'alipay' and addtime >= '".$jt."' and addtime < '".$mt."'")->fetchColumn();//支付宝的
	
	$jt_qqpay=$DB->query("SELECT sum(money) from pay_order where status = 1 and type = 'qqpay' and addtime >= '".$jt."' and addtime < '".$mt."'")->fetchColumn();//QQ的
	
	$jt_wxpay=$DB->query("SELECT sum(money) from pay_order where status = 1 and type = 'wxpay' and addtime >= '".$jt."' and addtime < '".$mt."'")->fetchColumn();//微信的


	#订单统计表数据获取
	$zhexiandata = [];
	$zhexiandatakey = [];
	$zhexiandatavalue = [];
	$zhexiandatamoney = [];
	$zhexiandatauser = [];
	for($i=0;$i<count($begin_timedata);$i++)
	{
	  $rss = $DB->query("SELECT count(money) as money from pay_order where addtime >= '".$begin_timedata[$i]."' and addtime <= '".$end_timedata[$i]."'")->fetch();
	  $rsss = $DB->query("SELECT sum(money) as money from pay_order where addtime >= '".$begin_timedata[$i]."' and addtime <= '".$end_timedata[$i]."' and  status=1")->fetch();
	  $rsuser = $DB->query("SELECT count(user) as user from pay_user where addtime >= '".$begin_timedata[$i]."' and addtime <= '".$end_timedata[$i]."'")->fetch();
	  $zhexiandata[] = $rss["money"];//订单数
	  $zhexiandatakey[] = $end_timedata2[$i];//时间
	  $zhexiandatavalue[] = $rss["money"];
	  $zhexiandatauser[] = $rsuser['user'];
	  $zhexiandatamoney[] = round($rsss["money"],2);//金额

	}

	#订单统计表数据获取
	$zhexiandata_qq = [];
	$zhexiandata_wx = [];
	$zhexiandata_ali = [];
	$zhexiandata_time = [];

	for($i=0;$i<count($begin_timedata);$i++)
	{
	  $rss_qq = $DB->query("SELECT sum(money) as money from pay_order where type='qqpay' and addtime >= '".$begin_timedata[$i]."' and addtime <= '".$end_timedata[$i]."' and  status=1")->fetch();
	  $rss_wx = $DB->query("SELECT sum(money) as money from pay_order where type='wxpay' and addtime >= '".$begin_timedata[$i]."' and addtime <= '".$end_timedata[$i]."' and  status=1")->fetch();
	  $rss_ali = $DB->query("SELECT sum(money) as money from pay_order where type='alipay' and addtime >= '".$begin_timedata[$i]."' and addtime <= '".$end_timedata[$i]."' and  status=1")->fetch();
	  $zhexiandata_qq[] = round($rss_qq["money"],2);//QQ
	  $zhexiandata_wx[] = round($rss_wx["money"],2);//微信
	  $zhexiandata_ali[] = round($rss_ali["money"],2);//支付宝
	  $zhexiandata_time[] = $end_timedata2[$i];//时间
	}

function batchTotal($batch,$type){
    	global $DB;

		$batch_Total=$DB->query("SELECT count(*) from pay_settle where batch='{$batch}' and type='{$type}'")->fetchColumn();
        
        return  round($batch_Total,2);

    }
 function batchTotals($batch,$type){
    	global $DB;

		$batch_Totals=$DB->query("SELECT count(*) from pay_settle where batch='{$batch}' and type='{$type}' and status=1")->fetchColumn();
        
        return  round($batch_Totals,2);

    }

   	$count_qq=$DB->query("SELECT count(*) from pay_jie where api_name='qqpay'")->fetchColumn();

   	$count_wx=$DB->query("SELECT count(*) from pay_jie where api_name='wxpay'")->fetchColumn();

   	$count_ali=$DB->query("SELECT count(*) from pay_jie where api_name='alipay'")->fetchColumn();

?>