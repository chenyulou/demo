<?php
include "../../includes/common.php";

if (isset($_GET['login'])) {
    $user = $_POST['user'];
    $pass = $_POST['pass'];
    if ($user !== $conf['user']) {
        exit('{"code":-1,"msg":"抱歉！账号或者密码不正确"}');
    }
    if ($pass !== $conf['pwd']) {
        exit('{"code":-1,"msg":"抱歉！账号或者密码不正确"}');
    }

    $city = get_ip_city($clientip);
    $DB->query("insert into `pay_log` (`uid`,`type`,`date`,`city`,`data`) values ('1','登录系统','" . $date . "','" . $city . "','IP:" . $clientip . "')");
    $session = md5($user . $pass . $password_hash);
    $token   = authcode("{$user}\t{$session}", 'ENCODE', SYS_KEY);
    setcookie("admin_token", $token, time() + 604800, "/" . $conf['adminurl']);
    @header('Content-Type: text/html; charset=UTF-8');
    if ($conf['Login'] == 1) {
        $true   = $conf['web_name'] . "-登录通知！";
        $text   = "嗨！站长，刚刚你易支付网站后台操作登录成功，若不是你本人登录请尽快做好安全措施！";
        $msg    = youfas($text);
        $result = send_mail($conf['mail_name'], $true, $msg); //好困
    }
    exit('{"code":0,"msg":"登陆成功！"}');
}

if (isset($_GET['logout'])) {
    setcookie("admin_token", "", time() - 604800, "/" . $conf['adminurl']);
    @header('Content-Type: text/html; charset=UTF-8');
    exit('{"code":-1,"msg":"退出成功！"}');
}
if ($islogin == 1) {} else {
    exit('{"code":-3,"msg":"No Login"}');
}

$act = isset($_GET['act']) ? daddslashes($_GET['act']) : null;

@header('Content-Type: application/json; charset=UTF-8');

switch ($act) {

    case 'set':
        $name       = trim(daddslashes($_POST['name']));
        $url        = trim(daddslashes($_POST['url']));
        $qq         = trim(daddslashes($_POST['qq']));
        $gxm        = trim(daddslashes($_POST['gxm']));
        $adminurl   = trim(daddslashes($_POST['adminurl']));
        $qqgroup    = trim(daddslashes($_POST['qqgroup']));
        $web_id     = trim(daddslashes($_POST['web_id']));
        $is_reg     = trim(daddslashes($_POST['is_reg']));
        $is_pay     = trim(daddslashes($_POST['is_pay']));
        $yuezz      = trim(daddslashes($_POST['yuezz']));
        $lyhbd      = trim(daddslashes($_POST['lyhbd']));
        $is_qqpay   = trim(daddslashes($_POST['is_qqpay']));
        $is_wxpay   = trim(daddslashes($_POST['is_wxpay']));
        $is_wxh5    = trim(daddslashes($_POST['is_wxh5']));
        $is_alipay  = trim(daddslashes($_POST['is_alipay']));
        $money_rate = trim(daddslashes($_POST['money_rate']));
        $verifytype = trim(daddslashes($_POST['verifytype']));
        $protocol   = trim(daddslashes($_POST['protocol']));
        if ($is_qqpay == '') {
            $is_qqpay = $conf['is_qqpay'];
        } else if ($is_wxpay == '') {
            $is_wxpay = $conf['is_wxpay'];
        } else if ($is_wxh5 == '') {
            $is_wxh5 = $conf['is_wxh5'];
        } else if ($is_alipay == '') {
            $is_alipay = $conf['is_alipay'];
        }
        if ($name == '') {
            exit('{"code":-1,"msg":"网站名称不能为空！"}');
        } else if ($url == '') {
            exit('{"code":-1,"msg":"网站域名不能为空！"}');
        }
        if ($conf['adminurl'] !== $adminurl) {
            $res = rename($_SERVER["DOCUMENT_ROOT"] . '/' . $conf['adminurl'], $_SERVER["DOCUMENT_ROOT"] . '/' . $adminurl);
        }
        $sql = "update `pay_admin` set `web_name` ='{$name}',`local_domain` ='{$url}',`web_qq` ='{$qq}',`qqgroup` ='{$qqgroup}',`web_id` ='{$web_id}',`is_reg` ='{$is_reg}',`is_pay` ='{$is_pay}',`is_qqpay` ='$is_qqpay',`is_wxpay` ='$is_wxpay',`is_wxh5`='$is_wxh5',`money_rate`='{$money_rate}',`is_alipay` ='$is_alipay',`verifytype`='{$verifytype}',`gxm`='{$gxm}',`adminurl`='{$adminurl}',`yuezz`='{$yuezz}',`lyhbd`='{$lyhbd}',`protocol`='{$protocol}' where `id`='1'";
        if ($DB->exec($sql)) {
            if (!$res) {
                $content = "后台目录修改失败，信息";
            }
            exit('{"code":0,"msg":"' . $content . '修改成功！"}');
        } else {
            exit('{"code":-1,"msg":"修改失败！"}');
        }
        break;
    case 'plug':
        $id       = trim(daddslashes($_POST['id']));
        $name     = trim(daddslashes($_POST['name']));
        $img      = trim(daddslashes($_POST['img']));
        $type     = trim(daddslashes($_POST['type']));
        $title    = trim(daddslashes($_POST['title']));
        $author   = trim(daddslashes($_POST['author']));
        $download = trim(daddslashes($_POST['download']));
        if ($_GET['add'] != 'sc') {
            if ($name == '') {
                exit('{"code":-1,"msg":"插件名称不能为空！"}');
            } else if ($img == '') {
                exit('{"code":-1,"msg":"插件LOGO名不能为空！"}');
            } else if ($download == '') {
                exit('{"code":-1,"msg":"插件下载地址不能为空！"}');
            }}
        if ($_GET['add'] == 'xg') {
            $sql = "update `pay_plug` set `name` ='{$name}',`logimg` ='{$img}',`type` ='{$type}',`title` ='{$title}',`author`='$author',`download` ='{$download}',`time` ='{$date}' where `id`='$id'";
            if ($DB->exec($sql)) {
                exit('{"code":0,"msg":"修改成功！"}');
            } else {
                exit('{"code":-1,"msg":"修改失败！"}');
            }} else if ($_GET['add'] == 'sc') {
            $rows = $DB->query("select * from pay_plug where id='{$id}' limit 1")->fetch();
            if (!$rows) {
                exit('{"code":1,"msg":"当前记录不存在！"}');
            }
            $sql = "DELETE FROM pay_plug WHERE id='{$id}'";
            if ($DB->exec($sql)) {
                exit('{"code":0,"msg":"删除成功！"}');
            } else {
                exit('{"code":1,"msg":"删除失败！"}');
            }} else {
            $sql = $DB->exec("INSERT INTO `pay_plug` (`name`,`logimg`,`type`,`title`,`author`,`download`,`time`) VALUES ('{$name}','{$img}','{$type}','{$title}','{$author}','{$download}','{$date}')");
            if ($sql) {
                exit('{"code":0,"msg":"添加成功！"}');
            } else {
                exit('{"code":-1,"msg":"添加失败！"}');
            }}

        break;

    case 'certify':
        $smrz    = trim(daddslashes($_POST['smrz']));
        $sjrz    = trim(daddslashes($_POST['sjrz']));
        $sfrz    = trim(daddslashes($_POST['sfrz']));
        $yhrz    = trim(daddslashes($_POST['yhrz']));
        $sj_code = trim(daddslashes($_POST['shourz']));
        $sf_code = trim(daddslashes($_POST['sfyz_code']));
        $yh_code = trim(daddslashes($_POST['yhkrz_code']));
        $sql     = "update `pay_admin` set `smrz`='$smrz',`shourz` ='{$sj_code}',`sfyz_code` ='{$sf_code}',`yhkrz_code` ='{$yh_code}',`sjrz` ='{$sjrz}',`sfrz` ='{$sfrz}',`yhrz` ='{$yhrz}' where `id`='1'";
        if ($DB->exec($sql)) {
            exit('{"code":0,"msg":"修改成功！"}');
        } else {
            exit('{"code":-1,"msg":"修改失败！"}');
        }
        break;

    case 'bakxg':

        $bak_type  = $_POST['bak_type'];
        $bak_type2 = $_POST['bak_type2'];
        $bak_date  = $_POST['bak_date'];
        $host      = $_POST['bak_url'];
        $user      = $_POST['bak_user'];
        $pwd       = $_POST['bak_pwd'];

        if ($host == '' || $user == '' || $pwd == '') {
            exit('{"code":-1,"msg":"请检查每项不能为空！"}');
        }

        $sql = "update `pay_admin` set `bak_type` ='{$bak_type}',`bak_type2` ='{$bak_type2}',`bak_date` ='{$bak_date}',`bak_url` ='{$host}',`bak_user` ='{$user}',`bak_pwd` ='{$pwd}' where `id`='1'";
        if ($DB->exec($sql)) {
            exit('{"code":0,"msg":"修改成功！"}');
        } else {
            exit('{"code":-1,"msg":"修改失败！"}');
        }
        break;

    case "pass":
        $user = daddslashes($_POST['user']);

        $jpass = daddslashes($_POST['jpass']);

        $xpass = daddslashes($_POST['xpass']);

        if ($jpass == '' || $xpass == '') {
            $xpass = $conf['pwd'];
        } else {

            if ($jpass != $conf['pwd']) {

                exit('{"code":1,"msg":"旧密码有误！"}');

            }
        }
        $sql = "update pay_admin set `user`='{$user}',`pwd` = '{$xpass}' where `id`='1'";
        $sqs = $DB->exec($sql);
        if ($sqs) {
            $session = md5($user . $xpass . $password_hash);
            $token   = authcode("{$user}\t{$session}", 'ENCODE', SYS_KEY);
            setcookie("admin_token", $token, time() + 604800, "/admin");
            exit('{"code":0,"msg":"修改成功！"}');
        } else {
            exit('{"code":1,"msg":"修改失败！"}');
        }
        break;

    case 'email':

        $mail_smtp = trim(daddslashes($_POST['mail_smtp']));
        $mail_port = trim(daddslashes($_POST['mail_port']));
        $mail_name = trim(daddslashes($_POST['mail_name']));
        $mail_pwd  = trim(daddslashes($_POST['mail_pwd']));
        if ($mail_smtp == '' || $mail_port == '' || $mail_name == '' || $mail_pwd == '') {
            exit('{"code":-1,"msg":"请检查每项不能为空！"}');
        }

        $sql = "update `pay_admin` set `mail_smtp` ='{$mail_smtp}',`mail_port` ='{$mail_port}',`mail_name` ='{$mail_name}',`mail_pwd` ='{$mail_pwd}' where `id`='1'";
        if ($DB->exec($sql)) {
            exit('{"code":0,"msg":"修改成功！"}');
        } else {
            exit('{"code":-1,"msg":"修改失败！"}');
        }
        break;

    case 'jie':

        $settle_open      = trim(daddslashes($_POST['settle_open']));
        $settle_money     = trim(daddslashes($_POST['settle_money']));
        $settle_money_max = trim(daddslashes($_POST['settle_money_max']));
        $settle_rate      = trim(daddslashes($_POST['settle_rate']));
        $settle_fee_min   = trim(daddslashes($_POST['settle_fee_min']));
        $settle_fee_max   = trim(daddslashes($_POST['settle_fee_max']));
        $settle_every     = trim(daddslashes($_POST['settle_every']));
        $stype_1          = trim(daddslashes($_POST['stype_1']));
        $stype_2          = trim(daddslashes($_POST['stype_2']));
        $stype_3          = trim(daddslashes($_POST['stype_3']));
        $stype_4          = trim(daddslashes($_POST['stype_4']));

        if ($settle_money == '' || $settle_money_max == '' || $settle_rate == '' || $settle_fee_min == '' || $settle_fee_max == '') {
            exit('{"code":-1,"msg":"请检查每项不能为空！"}');
        }

        $sql = "update `pay_admin` set `settle_open` ='{$settle_open}',`settle_money` ='{$settle_money}',`settle_money_max` ='{$settle_money_max}',`settle_every`='{$settle_every}',`settle_rate` ='{$settle_rate}',`settle_fee_min` ='{$settle_fee_min}',`settle_fee_max` ='{$settle_fee_max}',`stype_1` ='{$stype_1}',`stype_2` ='{$stype_2}',`stype_3` ='{$stype_3}',`stype_4` ='{$stype_4}' where `id`='1'";
        if ($DB->exec($sql)) {
            exit('{"code":0,"msg":"修改成功！"}');
        } else {
            exit('{"code":-1,"msg":"修改失败！"}');
        }
        break;

    case 'jieali':

        $alipay_appid = trim(daddslashes($_POST['alipay_appid']));
        $privatekey   = trim(daddslashes($_POST['privatekey']));
        if ($alipay_appid == '' || $privatekey == '') {
            exit('{"code":-1,"msg":"请检查每项不能为空！"}');
        }

        $sql = "update `pay_admin` set `alipay_appid` ='{$alipay_appid}',`privatekey` ='{$privatekey}' where `id`='1'";
        if ($DB->exec($sql)) {
            exit('{"code":0,"msg":"修改成功！"}');
        } else {
            exit('{"code":-1,"msg":"修改失败！"}');
        }
        break;

    case 'duan':

        $dx_code    = trim(daddslashes($_POST['dx_code']));
        $dx_mb_log  = trim(daddslashes($_POST['dx_mb_log']));
        $dx_mb_reg  = trim(daddslashes($_POST['dx_mb_reg']));
        $dx_mb_tix  = trim(daddslashes($_POST['dx_mb_tix']));
        $dx_mb_zhu  = trim(daddslashes($_POST['dx_mb_zhu']));
        $dx_mb_code = trim(daddslashes($_POST['dx_mb_code']));

        if ($dx_code == '') {
            exit('{"code":-1,"msg":"AppCode不能为空！"}');
        }

        $sql = "update `pay_admin` set `dx_code` ='{$dx_code}',`dx_mb_log` ='{$dx_mb_log}',`dx_mb_reg` ='{$dx_mb_reg}',`dx_mb_tix` ='{$dx_mb_tix}',`dx_mb_zhu` ='{$dx_mb_zhu}',`dx_mb_code` ='{$dx_mb_code}' where `id`='1'";
        if ($DB->exec($sql)) {
            exit('{"code":0,"msg":"修改成功！"}');
        } else {
            exit('{"code":-1,"msg":"修改失败！"}');
        }
        break;

    case 'cjmb':
        $tNum = trim(daddslashes($_POST['id']));

        $type = trim(daddslashes($_POST['type']));

        $host = "https://ali-sms.showapi.com";
        if ($type == 2) {
            $path = "/delTemplate";
        } else {
            $path = "/createTemplate";
        }
        $method = "GET"; //请求方式

        $appcode = $conf['dx_code']; //阿里云——>云市场——>已购买的服务列表——AppCode

        $content = trim(daddslashes($_POST['text'])); //短信模板

        $phone = trim(daddslashes($_POST['phone'])); //将审核的情况发送至该手机号码

        $title = trim(daddslashes($_POST['name'])); //短信的签名

        $headers = array();

        array_push($headers, "Authorization:APPCODE " . $appcode);

        $querys = "content=" . $content . "&notiPhone=" . $phone . "&tNum=" . $tNum . "&title=" . $title; //提交参数  创建模板

        $bodys = "";
        $url   = $host . $path . "?" . $querys;

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_FAILONERROR, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        //curl_setopt($curl, CURLOPT_HEADER, true);
        if (1 == strpos("$" . $host, "https://")) {
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        }

        $data = curl_exec($curl);

        $arr = json_decode($data, true);

        $tNum = $arr['showapi_res_body']['tNum'];

        $remark = $arr['showapi_res_body']['remark'];

        if ($remark == '查询成功!') {
            exit('{"code":0,"msg":"删除成功！"}');
        }

        if ($tNum != '') {
            $taa = $DB->exec("INSERT INTO `pay_duan` (`name`, `tnum`, `phone`, `text`, `time`, `active`) VALUES ('{$title}', '{$tNum}', '{$phone}', '{$content}', '{$date}', 0)");
            if ($taa) {
                exit('{"code":0,"msg":"' . $remark . '"}');
            } else {
                exit('{"code":-1,"msg":"' . $remark . '"}');
            }
        } else {
            exit('{"code":-1,"msg":"' . $remark . '"}');
        }
        break;

    case 'jieko':

        $id = $_POST['id'];

        $name = $_POST['name'];

        $type = $_POST['type'];

        $type1 = $_POST['type1'];

        $date = $_POST['date'];

        if ($_POST['mch_shaui'] == '') {
            $api_shaui = '';
        } else {
            $api_shaui = $_POST['mch_shaui'];
        }

        if ($_POST['h5type'] == '') {
            $h5type = '';
        } else {
            $h5type = $_POST['h5type'];
        }
        if ($date == 1) {
            if ($type == '') {
                exit('{"code":-1,"msg":"请选择接口类型"}');
            }

            if ($type1 == '') {
                exit('{"code":-1,"msg":"请选择接口标识(商)"}');
            }
        }
        if ($name == '') {
            exit('{"code":-1,"msg":"请输入接口名称"}');
        }

        if ($type1 == 'alipay') {
#支付宝
            $api_appid    = $_POST['mch_ali_id'];
            $api_key      = $_POST['mch_ali_key'];
            $api_mck      = $_POST['mch_ali_hid'];
            $api_callback = '0';

        } else if ($type1 == 'dmpay') {
#支付宝当面付
            $api_appid    = $_POST['mch_d_id'];
            $api_key      = '0';
            $api_mck      = $_POST['mch_d_gy'];
            $api_callback = $_POST['mch_d_sy'];

        } else if ($type1 == 'wftpay') {
            $api_appid    = $_POST['mch_wft_id'];
            $api_key      = $_POST['mch_wft_key'];
            $api_mck      = '0';
            $api_callback = '0';

        } else if ($type1 == 'qqpay') {
            $api_appid    = $_POST['mch_qq_id'];
            $api_key      = $_POST['mch_qq_key'];
            $api_mck      = '0';
            $api_callback = '0';

        } else if ($type1 == 'wxpay') {
#微信
            $api_appid    = $_POST['mch_wx_id'];
            $api_key      = $_POST['mch_wx_key'];
            $api_mck      = $_POST['mch_wx_hid'];
            $api_callback = $_POST['mch_wx_sec'];

        } else if ($type1 == 'epay') {
#易支付
            $api_appid    = $_POST['mch_e_id'];
            $api_key      = $_POST['mch_e_key'];
            $api_mck      = $_POST['mch_e_url'];
            $api_callback = '0';

        } else if ($type1 == 'eshangpay') {
            $api_appid    = $_POST['mch_y_id'];
            $api_key      = $_POST['mch_y_key'];
            $api_mck      = $_POST['mch_y_sec'];
            $api_callback = $_POST['mch_y_url'];

        } else if ($type1 == 'zzqq') {
#QQ转账
            $api_name     = 'QQ转账接口';
            $api_appid    = $_POST['mch_qq_id'];
            $api_key      = $_POST['mch_qq_key'];
            $api_mck      = $_POST['mch_qq_hid'];
            $api_callback = $_POST['mch_qq_pwd'];

        } else if ($type1 == 'zzwx') {
#微信转账
            $api_name     = '微信转账接口';
            $api_appid    = $_POST['mch_wx_id'];
            $api_key      = $_POST['mch_wx_key'];
            $api_mck      = $_POST['mch_wx_hid'];
            $api_callback = $_POST['mch_wx_sec'];

        }

# $date = 1 为添加接口
        # $date = 2 为修改接口

        if ($date == 1) {

            $apibuy = $DB->exec("INSERT INTO `pay_jie` (`name`,`api_name`, `api_type`, `api_appid`, `api_key`, `api_mck`, `api_callback`,`api_shaui`,`donlx`) VALUES ('{$name}','{$type}', '{$type1}', '{$api_appid}', '{$api_key}', '{$api_mck}', '{$api_callback}', '{$api_shaui}', '{$h5type}')");

            if ($apibuy) {

                if ($type1 == 'zzqq' || $type1 == 'zzwx') {
//如果等于这两个就是添加转账接口 所以显示修改成功

                    exit('{"code":0,"msg":"修改成功"}');

                } else {

                    exit('{"code":0,"msg":"添加成功"}');

                }

            } else {

                if ($type1 == 'zzqq' || $type1 == 'zzwx') {

                    exit('{"code":1,"msg":"修改失败"}');

                } else {

                    exit('{"code":1,"msg":"添加失败"}');

                }

            }

        } else if ($date == 2) {
#支付接口修改
            if ($type1 == 'alipay') {

                $sql = "update `pay_jie` set `name` ='{$name}',`api_appid` ='{$api_appid}',`api_key` ='{$api_key}',`api_mck` ='{$api_mck}',`api_shaui` ='{$api_shaui}' where `id`='$id'";

            } else if ($type1 == 'qqpay' || $type1 == 'wftpay') {

                $sql = "update `pay_jie` set `name` ='{$name}',`api_appid` ='{$api_appid}',`api_key` ='{$api_key}',`api_shaui` ='{$api_shaui}' where `id`='$id'";

            } else if ($type1 == 'dmpay') {

                $sql = "update `pay_jie` set `name` ='{$name}',`api_appid` ='{$api_appid}',`api_mck` ='{$api_mck}',`api_callback` ='{$api_callback}',`api_shaui` ='{$api_shaui}' where `id`='$id'";

            } else if ($type1 == 'wxpay') {

                $sql = "update `pay_jie` set `name` ='{$name}',`api_appid` ='{$api_appid}',`api_key` ='{$api_key}',`api_mck` ='{$api_mck}',`api_callback` ='{$api_callback}',`api_shaui` ='{$api_shaui}',`donlx` ='{$h5type}' where `id`='$id'";

            } else if ($type1 == 'epay') {

                $sql = "update `pay_jie` set `name` ='{$name}',`api_appid` ='{$api_appid}',`api_key` ='{$api_key}',`api_mck` ='{$api_mck}',`api_shaui` ='{$api_shaui}',`donlx` ='{$h5type}' where `id`='$id'";

            } else if ($type1 == 'eshangpay') {

                $sql = "update `pay_jie` set `name` ='{$name}',`api_appid` ='{$api_appid}',`api_key` ='{$api_key}',`api_mck` ='{$api_mck}',`api_shaui` ='{$api_shaui}',`api_callback`='{$api_callback}' where `id`='$id'";

            } else if ($type1 == 'zzqq') {

                $sql = "update `pay_jie` set `api_appid` ='{$api_appid}',`api_key` ='{$api_key}',`api_mck` ='{$api_mck}',`api_callback` ='{$api_callback}' where `id`='$id'";

            } else if ($type1 == 'zzwx') {

                $sql = "update `pay_jie` set `api_appid` ='{$api_appid}',`api_key` ='{$api_key}',`api_mck` ='{$api_mck}',`api_callback` ='{$api_callback}' where `id`='$id'";

            }

            if ($DB->exec($sql)) {
                exit('{"code":0,"msg":"修改成功！"}');
            } else {
                exit('{"code":-1,"msg":"修改失败！ "}');
            }

        }
        break;

    case 'deijk':
        $id   = daddslashes($_POST['id']);
        $rows = $DB->query("select * from pay_jie where id='{$id}' limit 1")->fetch();
        if (!$rows) {
            exit('{"code":1,"msg":"当前记录不存在！"}');
        }
        $sql = "DELETE FROM pay_jie WHERE id='{$id}'";
        if ($DB->exec($sql)) {
            exit('{"code":0,"msg":"删除成功！"}');
        } else {
            exit('{"code":1,"msg":"删除失败！"}');
        }

        break;

    case 'qfa':

        if ($_POST['type2'] == 0) {
            exit('{"code":1,"msg":"请选择发送对象！"}');
        }
        if ($_POST['type2'] == 2) {

            $uid = $_POST['email'];

        } else {

            $uid = "所有人";

        }

        $rs = $DB->query("SELECT * FROM pay_user order by id desc");

        $mailtitle = "" . $_POST['min'];

        $time = date("Y-m-d H:i:s", time());

        $mailcontent = "" . $_POST['name'] . "";

        if ($_POST['type2'] == 1) {

            while ($res = $rs->fetch()) {
                $result = send_mail($res['email'], $mailtitle, $mailcontent);
            }
        } else {
            $result = send_mail($_POST['email'], $mailtitle, $mailcontent);
        }
        if ($result) {

            $DB->exec("INSERT INTO `pay_email` (`uid`, `name`, `time`, `ems`, `min`) VALUES ('{$uid}', '{$mailcontent}', '{$time}', '{$_POST['type2']}', '{$mailtitle}')");

            exit('{"code":0,"msg":"发送成功"}');
        }

        break;
    case 'youdei':
        $id   = daddslashes($_POST['id']);
        $rows = $DB->query("select * from pay_email where id='{$id}' limit 1")->fetch();
        if (!$rows) {
            exit('{"code":1,"msg":"当前记录不存在！"}');
        }
        $sql = "DELETE FROM pay_email WHERE id='{$id}'";
        if ($DB->exec($sql)) {
            exit('{"code":0,"msg":"删除成功！"}');
        } else {
            exit('{"code":1,"msg":"删除失败！"}');
        }

        break;

    case 'bak':

        $type  = daddslashes($_POST['type']);
        $type2 = daddslashes($_POST['type2']);
        $date  = daddslashes($_POST['bak_date']);
        $url   = daddslashes($_POST['bak_url']);
        $user  = daddslashes($_POST['bak_user']);
        $pwd   = daddslashes($_POST['bak_pwd']);

        $sql = "update `pay_admin` set `bak_type` ='{$type}',`bak_type2` ='{$type2}',`bak_date` ='{$date}',`bak_url` ='{$url}',`bak_user` ='{$user}',`bak_pwd` ='{$pwd}' where `id`='1'";
        if ($DB->exec($sql)) {
            exit('{"code":0,"msg":"修改成功！"}');
        } else {
            exit('{"code":-1,"msg":"修改失败！"}');
        }
        break;

    case 'delete_sh':
        $id   = daddslashes($_POST['id']);
        $rows = $DB->query("select * from pay_user where id='{$id}' limit 1")->fetch();
        if (!$rows) {
            exit('{"code":1,"msg":"当前记录不存在！"}');
        }
        $sql = "DELETE FROM pay_user WHERE id='{$id}'";
        if ($DB->exec($sql)) {
            exit('{"code":0,"msg":"删除商户成功！"}');
        } else {
            exit('{"code":1,"msg":"删除商户失败！"}');
        }
        break;

    case 'add_submit':
        $user = $_POST['user'];
        $rows = $DB->query("select * from pay_user where user='$user' limit 1")->fetch();
        if ($rows) {
            exit('{"code":1,"msg":"该账号已经存在！"}');
        }
        $pwd       = $_POST['pwd'];
        $settle_id = $_POST['settle_id'];
        $account   = $_POST['account'];
        $username  = $_POST['username'];
        $money     = '0.00';
        $url       = $_POST['url'];
        $email     = $_POST['email'];

        $qq        = $_POST['qq'];
        $type      = $_POST['type'];
        $rate      = $_POST['rate'];
        $active    = $_POST['active'];
        $qqpay     = $_POST['qqpay'];
        $wxpay     = $_POST['wxpay'];
        $alipay    = $_POST['alipay'];
        $wxh5pay   = $_POST['wxh5pay'];
        $rate_qq   = $_POST['rate_qq'];
        $rate_wx   = $_POST['rate_wx'];
        $rate_ali  = $_POST['rate_ali'];
        $rate_wxh5 = $_POST['rate_wxh5'];
        if ($account == null or $username == null) {
            exit('{"code":1,"msg":"保存错误,请确保加*项都不为空！"}');
        } else {
            $key = random(32);
            $sds = $DB->exec("INSERT INTO `pay_user` (`user`,`pwd`,`key`, `account`, `username`, `money`, `url`, `addtime`, `type`, `settle_id`, `email`, `qq`, `rate_qq`,`rate_wx`,`rate_ali`,`rate_wxh5`, `active`, `qqpay`, `wxpay`, `alipay`,`wxh5pay`) VALUES ('{$user}','{$pwd}','{$key}', '{$account}', '{$username}', '{$money}', '{$url}', '{$date}', '{$type}', '{$settle_id}', '{$email}', '{$qq}', '{$rate_qq}','{$rate_wx}','{$rate_ali}','{$rate_wxh5}', '{$active}', '{$qqpay}', '{$wxpay}', '{$alipay}','{$wxh5pay}')");
            $pid = $DB->lastInsertId();
            if ($sds) {
                exit('{"code":0,"msg":"添加成功！"}');
            } else {
                exit('{"code":1,"msg":"添加失败！"}');
            }

        }

        break;

    case 'edit_submit':
        $id   = $_POST['id'];
        $rows = $DB->query("select * from pay_user where id='$id' limit 1")->fetch();
        if (!$rows) {
            exit('{"code":1,"msg":"当前记录不存在！"}');
        }

        $user      = $_POST['user'];
        $pwd       = $_POST['pwd'];
        $settle_id = $_POST['settle_id'];
        $account   = $_POST['account'];
        $username  = $_POST['username'];
        $money     = $_POST['money'];
        $url       = $_POST['url'];
        $email     = $_POST['email'];
        $qq        = $_POST['qq'];
        $phone     = $_POST['phone'];
        $type      = $_POST['type'];
        $rate      = $_POST['rate'];
        $active    = $_POST['active'];
        $qqpay     = $_POST['qqpay'];
        $wxpay     = $_POST['wxpay'];
        $alipay    = $_POST['alipay'];
        $wxh5pay   = $_POST['wxh5pay'];
        $rate_qq   = $_POST['rate_qq'];
        $rate_wx   = $_POST['rate_wx'];
        $rate_ali  = $_POST['rate_ali'];
        $rate_wxh5 = $_POST['rate_wxh5'];
        if ($account == null or $username == null) {
            exit('{"code":1,"msg":"保存错误，请确保加*项都不为空！"}');
        } else {
            $sql = "update `pay_user` set `user` ='{$user}',`pwd` ='{$pwd}',`account` ='{$account}',`username` ='{$username}',`money` ='{$money}',`url` ='{$url}',`type` ='{$type}',`settle_id` ='{$settle_id}',`email` ='{$email}',`qq` ='{$qq}',`phone` ='{$phone}',`rate_qq` ='{$rate_qq}',`rate_wx` ='{$rate_wx}',`rate_ali` ='{$rate_ali}',`rate_wxh5` ='{$rate_wxh5}',`active` ='{$active}',`qqpay` ='{$qqpay}' ,`wxpay` ='{$wxpay}' ,`alipay` ='{$alipay}',`wxh5pay`='{$wxh5pay}' where `id`='$id'";
            if ($_POST['resetkey'] == 1) {
                $key = random(32);
                $sqs = $DB->exec("update `pay_user` set `key` ='{$key}' where `id`='$id'");
            }
            if ($DB->exec($sql) || $sqs) {
                exit('{"code":0,"msg":"修改成功！"}');
            } else {
                exit('{"code":1,"msg":"修改失败！"}');
            }

        }
        break;
    case "apiStatusEdit":
        $id     = intval($_GET["id"]);
        $status = intval($_GET["status"]);
        $sql    = "update pay_jie set status = {$status} where id = {$id}";
        $sqs    = $DB->exec($sql);
        if ($sqs) {
            exit('{"code":0,"msg":"修改成功！"}');
        } else {
            exit('{"code":1,"msg":"修改失败！"}');
        }

        break;

    case "log":
        $status = intval($_GET["status"]);
        $sql    = "update pay_admin set Login = {$status} where id = 1";
        $sqs    = $DB->exec($sql);
        if ($sqs) {
            exit('{"code":0,"msg":"修改成功！"}');
        } else {
            exit('{"code":1,"msg":"修改失败！"}');
        }

        break;

    case "logs":
        $type   = $_GET['type'];
        $status = intval($_GET["status"]);
        if ($type == "qq") {
            $sql = "update pay_admin set qq_login = {$status} where id = 1";
        } else if ($type == "wx") {
            $sql = "update pay_admin set wx_login = {$status} where id = 1";
        }
        $sqs = $DB->exec($sql);
        if ($sqs) {
            exit('{"code":0,"msg":"修改成功！"}');
        } else {
            exit('{"code":1,"msg":"修改失败！"}');
        }

        break;

    case "update":
        $status = intval($_GET["status"]);
        $sql    = "update pay_admin set gxdate = {$status} where id = 1";
        $sqs    = $DB->exec($sql);
        if ($sqs) {
            exit('{"code":0,"msg":"修改成功！"}');
        } else {
            exit('{"code":1,"msg":"修改失败！"}');
        }

        break;
    case 'del_mali':
        $id   = daddslashes($_POST['id']);
        $rows = $DB->query("select * from pay_email where id='{$id}' limit 1")->fetch();
        if (!$rows) {
            exit('{"code":1,"msg":"当前记录不存在！"}');
        }

        $sql = "DELETE FROM pay_email WHERE id='{$id}'";
        if ($DB->exec($sql)) {
            exit('{"code":0,"msg":"删除成功！"}');
        } else {
            exit('{"code":1,"msg":"删除失败！"}');
        }

        break;
    case 'userlog':

        $user = daddslashes($_POST['user']);

        $pass = daddslashes($_POST['pass']);

        $userrow = $DB->query("SELECT * FROM pay_user WHERE user='{$user}' limit 1")->fetch();

        if (!$userrow) {
            exit('{"code":-1,"msg":"账号不存在！"}');
        }

        if ($pass == $userrow['pwd']) {

            $session = md5($userrow['id'] . $userrow['pwd'] . $password_hash);

            $expiretime = time() + 604800;

            $token = authcode("{$userrow['id']}\t{$session}\t{$expiretime}", 'ENCODE', SYS_KEY);

            setcookie("user_token", $token, time() + 604800, "/user");

            @header('Content-Type: text/html; charset=UTF-8');

            exit('{"code":0,"msg":"登陆成功！"}');

        } else {

            exit('{"code":-1,"msg":"密码不正确！"}');

        }

        break;

    case 'creat':

        $limit = '1000';

        $rs = $DB->query("SELECT * from pay_user where money>='{$conf['settle_money']}' and account is not null and username is not null and type!=2 limit {$limit}");

        $batch    = date("Ymd") . rand(111, 999);
        $i        = 0;
        $allmoney = 0;
        while ($row = $rs->fetch()) {
            $i++;
            $allmoneys = $row['money'];
            $fee       = round($row['money'] * $conf['settle_rate'], 2);

            if ($fee < $conf['settle_fee_min']) {
                $fee = $conf['settle_fee_min'];
            }

            if ($fee > $conf['settle_fee_max']) {
                $fee = $conf['settle_fee_max'];
            }

            $money = $row['money'] - $fee;

            $DB->exec("update `pay_user` set `money`='0',`apply`='1' where `id`='{$row['id']}'");
            $DB->exec("INSERT INTO `pay_money` (`uid`, `name`, `money`, `addmoney`, `time`) VALUES ('{$row['id']}', '结算', '-{$row['money']}', '0', '{$date}')");
            $DB->exec("INSERT INTO `pay_settle` (`pid`, `batch`, `type`, `username`, `account`, `money`,`allmoney`, `fee`, `time`, `status`) VALUES ('{$row['id']}', '{$batch}', '{$row['settle_id']}', '{$row['username']}', '{$row['account']}', '{$money}','{$allmoneys}', '{$fee}', '{$date}', '2')");

            $allmoney += $row['money'];

        }
        $DB->exec("INSERT INTO `pay_batch` (`batch`, `allmoney`, `time`, `status`) VALUES ('{$batch}', '{$allmoney}', '{$date}', '0')");

        exit('{"code":0,"msg":"生成成功！"}');

        break;

    case 'jies':

        $batch = daddslashes($_POST['batch']);

        $rs = $DB->query("SELECT * FROM pay_settle WHERE batch='{$batch}' limit 1")->fetch();

        $DB->exec("update `pay_user` set `apply`='0' where `id`='{$rs['pid']}'");

        $DB->exec("update `pay_settle` set `status`='3' where `batch`='{$batch}'");

        $DB->exec("update `pay_batch` set `status`='1' where `batch`='{$batch}'");

        exit('{"code":0,"msg":"结算成功！"}');

        break;

    case 'close':

        $title = daddslashes($_POST['title']);
        $type  = daddslashes($_POST['type']);
        $name  = daddslashes($_POST['name']);
        if ($title == null or $name == null) {
            exit('{"code":1,"msg":"请确保每项都不为空！"}');
        }

        $res = $DB->exec("INSERT INTO `pay_notice` (`title`, `type`, `name`, `time`) VALUES ('{$title}', '{$type}', '{$name}', '{$date}')");

        if ($res) {
            exit('{"code":0,"msg":"发布成功！"}');
        } else {
            exit('{"code":1,"msg":"发布失败！"}');
        }

# code...
        break;

    case 'del_down':
        $id   = daddslashes($_POST['id']);
        $rows = $DB->query("select * from pay_notice where id='{$id}' limit 1")->fetch();
        if (!$rows) {
            exit('{"code":1,"msg":"当前记录不存在！"}');
        }

        $sql = "DELETE FROM pay_notice WHERE id='{$id}'";
        if ($DB->exec($sql)) {
            exit('{"code":0,"msg":"删除成功！"}');
        } else {
            exit('{"code":1,"msg":"删除失败！"}');
        }

        break;

    case 'addown':

        $id = daddslashes($_POST['id']);

        $name = daddslashes($_POST['name']);

        $title = daddslashes($_POST['title']);

        $res = $DB->exec("update `pay_notice` set `title`='{$title}',`name`='{$name}' where `id`='{$id}'");
        if ($res) {
            exit('{"code":0,"msg":"保存成功！"}');
        } else {
            exit('{"code":1,"msg":"保存失败！"}');
        }
        break;

    case 'upgx':

        $id = daddslashes($_POST['sqm']);

        $url = $_SERVER['HTTP_HOST'];

        $arr = file_get_contents($zipurl . '?url=' . $_SERVER['HTTP_HOST'] . '&id=' . $id);

        $data = json_decode($arr, true);

        if ($data['code'] == 1) {
            $DB->exec("update `pay_admin` set `gxm`='{$id}' where `id`='1'");
            exit('{"code":0,"msg":"保存成功！"}');
        } else if ($data['code'] == 3) {
            exit('{"code":0,"msg":"' . $data['msg'] . '"}');
        } else {
            exit('{"code":1,"msg":"' . $data['msg'] . '"}');
        }
        break;

    case 'qqtransfer':

        define('NOTIFY_HTPAY', '1');

        $id = isset($_POST['id']) ? intval($_POST['id']) : exit('{"code":-1,"msg":"ID不能为空"}');

        $row = $DB->query("SELECT * FROM pay_settle WHERE id='{$id}' limit 1")->fetch();

        if (!$row) {
            exit('{"code":-1,"msg":"记录不存在"}');
        }

        if ($row['type'] != 3) {
            exit('{"code":-1,"msg":"该记录不是QQ结算"}');
        }

        if ($row['transfer_status'] == 1) {
            exit('{"code":0,"ret":2,"result":"QQ订单号:' . $row['transfer_result'] . ' 支付时间:' . $row['transfer_date'] . '"}');
        }

        if (!is_numeric($row['account']) || strlen($row['account']) < 6 || strlen($row['account']) > 10) {
            $a           = array();
            $a['code']   = 0;
            $a['ret']    = 0;
            $a['msg']    = 'fail';
            $a['result'] = 'QQ号格式错误';
            exit(json_encode($a));
        }
        $zzqq = 1;
        require_once SYSTEM_ROOT . 'pay/qqpay/qpayMchAPI.class.php';

        $out_biz_no = date("Ymd") . '000' . $id;

//入参
        $params                     = array();
        $params["input_charset"]    = 'UTF-8';
        $params["uin"]              = $row['account'];
        $params["out_trade_no"]     = $out_biz_no;
        $params["fee_type"]         = "CNY";
        $params["total_fee"]        = $row['money'] * 100;
        $params["memo"]             = $conf['wxtransfer_desc']; //付款备注
        $params["check_name"]       = 'false'; //校验用户姓名，"FORCE_CHECK"校验实名
        $params["re_user_name"]     = ''; //收款用户真实姓名
        $params["check_real_name"]  = "0"; //校验用户是否实名
        $params["op_user_id"]       = QpayMchConf::OP_USERID;
        $params["op_user_passwd"]   = md5(QpayMchConf::OP_USERPWD);
        $params["spbill_create_ip"] = $clientip;

//api调用
        $qpayApi = new QpayMchAPI('https://api.qpay.qq.com/cgi-bin/epay/qpay_epay_b2c.cgi', true, 10);
        $ret     = $qpayApi->reqQpay($params);
        $result  = QpayMchUtil::xmlToArray($ret);

        if ($result['return_code'] == 'SUCCESS' && $result['result_code'] == 'SUCCESS') {
            $data['code']   = 0;
            $data['ret']    = 1;
            $data['msg']    = 'success';
            $data['result'] = 'QQ订单号:' . $result["transaction_id"] . ' 交易时间:' . date('Y-m-d H:i:s', time());
            $DB->exec("update `pay_settle` set `status`='1',`transfer _status`='1',`transfer_result`='" . $result["transaction_id"] . "',`transfer_date`='" . date('Y-m-d H:i:s', time()) . "' where `id`='$id'");
        } elseif ($result['err_code'] == 'TRANSFER_FEE_LIMIT_ERROR' || $result['err_code'] == 'TRANSFER_FAIL' || $result['err_code'] == 'NOTENOUGH' || $result['err_code'] == 'APPID_OR_OPENID_ERR' || $result['err_code'] == 'TOTAL_FEE_OUT_OF_LIMIT' || $result['err_code'] == 'REALNAME_CHECK_ERROR' || $result['err_code'] == 'RE_USER_NAME_CHECK_ERROR') {
            $data['code']   = 0;
            $data['ret']    = 0;
            $data['msg']    = 'fail';
            $data['result'] = '转账失败 [' . $result["err_code"] . ']' . $result["err_code_des"];
            $DB->exec("update `pay_settle` set `transfer_status`='2',`transfer_result`='" . $data['result'] . "' where `id`='$id'");
        } elseif (isset($result['result_code'])) {
            $data['code']   = -1;
            $data['result'] = '转账失败 [' . $result["err_code"] . ']' . $result["err_code_des"];
        } else {
            $data['code']   = -1;
            $data['result'] = '未知错误 ' . $result["return_msg"];
        }

        echo json_encode($data);

        break;

    case 'wxtransfer':
        define('NOTIFY_HTPAY', '1');
        $zzwx = 1;
        require_once SYSTEM_ROOT . "pay/wxpay/WxPay.Api.php";

        $id = isset($_POST['id']) ? intval($_POST['id']) : exit('{"code":-1,"msg":"ID不能为空"}');

        $row = $DB->query("SELECT * FROM pay_settle WHERE id='{$id}' limit 1")->fetch();

        if (!$row) {
            exit('{"code":-1,"msg":"记录不存在"}');
        }

        if ($row['type'] != 2) {
            exit('{"code":-1,"msg":"该记录不是微信结算"}');
        }

        if ($row['transfer_status'] == 1) {
            exit('{"code":0,"ret":2,"result":"微信订单号:' . $row['transfer_result'] . ' 支付时间:' . $row['transfer_date'] . '"}');
        }

        $out_biz_no = date("Ymd") . '000' . $id;

        $input = new WxPayTransfer();
        $input->SetPartner_trade_no($out_biz_no);
        $input->SetOpenid($row['account']);
        $input->SetCheck_name('FORCE_CHECK');
        $input->SetRe_user_name($row['username']);
        $input->SetAmount($row['money'] * 100);
        $input->SetDesc($conf['wxtransfer_desc']);
        $input->SetSpbill_create_ip($_SERVER['SERVER_ADDR']);
        $result = WxPayApi::transfer($input);

        if ($result["result_code"] == 'SUCCESS') {
            $data['code']   = 0;
            $data['ret']    = 1;
            $data['msg']    = 'success';
            $data['result'] = '微信订单号:' . $result["payment_no"] . ' 支付时间:' . $result["payment_time"];
            $DB->exec("update `pay_settle` set `status`='1',`transfer_status`='1',`transfer_result`='" . $result["payment_no"] . "',`transfer_date`='" . $result["payment_time"] . "' where `id`='$id'");
        } elseif ($result["result_code"] == 'FAIL' && ($result["err_code"] == 'OPENID_ERROR' || $result["err_code"] == 'NAME_MISMATCH' || $result["err_code"] == 'MONEY_LIMIT' || $result["err_code"] == 'V2_ACCOUNT_SIMPLE_BAN')) {
            $data['code']   = 0;
            $data['ret']    = 0;
            $data['msg']    = 'fail';
            $data['result'] = '失败 [' . $result["err_code"] . ']' . $result["err_code_des"];
            $DB->exec("update `pay_settle` set `transfer_status`='2',`transfer_result`='" . $data['result'] . "' where `id`='$id'");} elseif (!empty($result["result_code"])) {
            $data['code'] = -1;
            $data['msg']  = '[' . $result["err_code"] . ']' . $result["err_code_des"];
        } else {
            $data['code'] = -1;
            $data['msg']  = '未知错误 ' . $result["return_msg"];
        }
        echo json_encode($data);

        break;

    case 'alitransfer':
        define('NOTIFY_HTPAY', '1');

        require_once SYSTEM_ROOT . "pay/f2fpay/lib/AopClient.php";
        require_once SYSTEM_ROOT . "pay/f2fpay/model/request/AlipayFundTransToaccountTransferRequest.php";

        $id = isset($_POST['id']) ? intval($_POST['id']) : exit('{"code":-1,"msg":"ID不能为空"}');

        $row = $DB->query("SELECT * FROM pay_settle WHERE id='{$id}' limit 1")->fetch();

        if (!$row) {
            exit('{"code":-1,"msg":"记录不存在"}');
        }

        if ($row['type'] != 1) {
            exit('{"code":-1,"msg":"该记录不是支付宝结算"}');
        }

        if ($row['transfer_status'] == 1) {
            exit('{"code":0,"ret":2,"result":"支付宝转账单据号:' . $row['transfer_result'] . ' 支付时间:' . $row['transfer_date'] . '"}');
        }

        $out_biz_no = date("Ymd") . '000' . $id;

        $BizContent = array(
            'out_biz_no'      => $out_biz_no, //商户转账唯一订单号
            'payee_type'      => 'ALIPAY_LOGONID', //收款方账户类型
            'payee_account'   => $row['account'], //收款方账户
            'amount'          => $row['money'], //转账金额
            'payer_show_name' => $conf['payer_show_name'], //付款方显示姓名
            'payee_real_name' => $row['username'], //收款方真实姓名
        );

        $aop                     = new AopClient();
        $aop->gatewayUrl         = 'https://openapi.alipay.com/gateway.do';
        $aop->appId              = $conf['alipay_appid'];
        $aop->rsaPrivateKey      = $conf['privatekey'];
        $aop->alipayrsaPublicKey = 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAm0frLLY3U/9pQvkdw3KC6jZ48CaSMxsXt8zryxDS21xBFJJKsqDJ0C01cwrMLaHXrx96Sd83Lj63HRzN3zyYgB/OJ5x2LiYDELFZ4Fe0ow5wajltw972hJlSeb+STIO+frDM5DXxZ9r2PIXyq0S1+1jDCX1ReNJfwPQ8x8WbDEnzXRaXoEfOaf7Qshlw0ih+i233aemZBbn1Liqj+dq2dLSV9pB1XV7XbDq8ZHORa48y00/EvOvSa6prgzc4vIjlbBxP/Yl2p5iTVNsDOkFFTF7/8CEmw72LOSNAYx9f+BASEgC7BQSSWL+ukT9kssUtdHiLYW51eF3659/9ktS5nwIDAQAB';
        $aop->apiVersion         = '1.0';
        $aop->signType           = 'RSA2';
        $aop->postCharset        = 'UTF-8';
        $aop->format             = 'json';
        $request                 = new AlipayFundTransToaccountTransferRequest();
        $request->setBizContent(json_encode($BizContent));
        $result = $aop->execute($request);

        $data         = array();
        $responseNode = str_replace(".", "_", $request->getApiMethodName()) . "_response";
        $resultCode   = $result->$responseNode->code;
        if (!empty($resultCode) && $resultCode == 10000) {
            $data['code']   = 0;
            $data['ret']    = 1;
            $data['msg']    = 'success';
            $data['result'] = '支付宝转账单据号:' . $result->$responseNode->order_id . ' 支付时间:' . $result->$responseNode->pay_date;
            $DB->exec("update `pay_settle` set `status`='1',`transfer_status`='1',`transfer_result`='" . $result->$responseNode->order_id . "',`transfer_date`='" . $result->$responseNode->pay_date . "' where `id`='$id'");
        } elseif ($resultCode == 40004) {
            $data['code']   = 0;
            $data['ret']    = 0;
            $data['msg']    = 'fail';
            $data['result'] = '失败 [' . $result->$responseNode->sub_code . ']' . $result->$responseNode->sub_msg;
            $DB->exec("update `pay_settle` set `transfer_status`='2',`transfer_result`='" . $data['result'] . "' where `id`='$id'");} elseif (!empty($resultCode)) {
            $data['code'] = -1;
            $data['msg']  = '[' . $result->$responseNode->sub_code . ']' . $result->$responseNode->sub_msg;
        } else {
            $data['code'] = -1;
            $data['msg']  = '未知错误';
        }
        echo json_encode($data);

        break;

    case 'transfer':

        $id = isset($_POST['id']) ? intval($_POST['id']) : exit('{"code":-1,"msg":"ID不能为空"}');

        $row = $DB->query("SELECT * FROM pay_settle WHERE id='{$id}' limit 1")->fetch();

        if (!$row) {
            exit('{"code":-1,"msg":"记录不存在"}');
        }

        if ($row['transfer_status'] == 1) {
            exit('{"code":0,"ret":2,"result":"操作成功！"}');
        }

        $row = $DB->exec("update `pay_settle` set `status`='1',`transfer_status`='1' where `id`='$id'");

        if ($row) {
            $data['code']   = 0;
            $data['ret']    = 1;
            $data['msg']    = 'success';
            $data['result'] = '操作成功！';
        } else {
            $data['code']   = 0;
            $data['ret']    = 0;
            $data['msg']    = 'fail';
            $data['result'] = '操作失败！';
        }

        echo json_encode($data);

        break;

    case 'ljpz':

        $postlj   = trim(daddslashes($_POST['postlj']));
        $getlj    = trim(daddslashes($_POST['getlj']));
        $cookielj = trim(daddslashes($_POST['cookielj']));
        $paylj    = trim(daddslashes($_POST['paylj']));
        $ljname   = trim(daddslashes($_POST['ljname']));

        $sql = "update `pay_admin` set `postlj` ='{$postlj}',`getlj` ='{$getlj}',`cookielj` ='{$cookielj}',`paylj` ='{$paylj}',`ljname` ='{$ljname}' where `id`='1'";
        if ($DB->exec($sql)) {
            exit('{"code":0,"msg":"修改成功！"}');
        } else {
            exit('{"code":-1,"msg":"修改失败！"}');
        }
        break;

    case 'operate':

        $id = trim(daddslashes($_POST['id']));

        $row = $DB->query("SELECT * FROM pay_settle WHERE id='{$id}' limit 1")->fetch();

        if (!$row) {

            exit('{"code":-1,"msg":"该记录不存在！"}');

        }

        $sql = "update `pay_settle` set `status` ='1' where `id`='{$row['id']}'";

        if ($DB->exec($sql)) {

            $DB->exec("update `pay_user` set `apply`=apply-1 where `id`='{$row['pid']}'");

            exit('{"code":0,"msg":"结算完成！"}');

        } else {

            exit('{"code":-1,"msg":"结算失败！"}');

        }

        break;

    case 'operates':

        $id = trim(daddslashes($_POST['id']));

        $content = daddslashes($_POST['content']);

        $row = $DB->query("SELECT * FROM pay_settle WHERE id='{$id}' limit 1")->fetch();

        if ($row) {

            $sql = "update `pay_settle` set `status` ='4',`transfer_result`='{$content}' where `id`='{$row['id']}'";

            if ($DB->exec($sql)) {

                $DB->exec("update `pay_user` set `money`=money+{$row['allmoney']}, `apply`=apply-1 where `id`='{$row['pid']}'");

                $rows = $DB->query("SELECT * FROM pay_user WHERE id='{$row['pid']}' limit 1")->fetch();

                $DB->exec("INSERT INTO `pay_money` (`uid`, `name`, `money`, `addmoney`, `time`) VALUES ('{$row['pid']}', '结算驳回', '+{$row['allmoney']}', '{$rows['money']}', '{$date}')");

                exit('{"code":0,"msg":"驳回完成！"}');

            } else {

                exit('{"code":-1,"msg":"驳回失败！"}');

            }

        } else {

            exit('{"code":-1,"msg":"该记录不存在！"}');

        }
        break;

    case 'Update':
        $type = daddslashes($_POST['type']);

        $arr = file_get_contents($zipurl . '/newt.php?url=' . $_SERVER['HTTP_HOST'] . '&gxm=' . $conf['gxm']);

        $data = json_decode($arr, true);

        $version = $data['version'];

        if ($type == 'jc') {

            if ($version > $vin) {

                exit('{"code":1,"msg":"有新版本啦！","version":"' . $version . '","name":"' . $data['name'] . '"}');

            } else {

                exit('{"code":-1,"msg":"无新版本更新！"}');

            }

        }

        if ($version > $vin) {

            $url = $data['zipaddress'] . urlencode(iconv("GB2312", "UTF-8", $data['zipname']));

            $save_dir = $_SERVER["DOCUMENT_ROOT"];

            $filename = "Update.zip";

            $res = getFile($url, $save_dir, $filename, 1);

            if ($res != true) {

                exit('{"code":-1,"msg":"更新包不存在，或者下载失败！"}');

            }

            $size = get_zip_originalsize('../../' . $filename, '../../');

            if ($size != true) {

                exit('{"code":-1,"msg":"' . $size . '"}');

            }

            include $_SERVER["DOCUMENT_ROOT"] . "/includes/lib/mysql.php";

            $msg = $conf['web_name'] . '-更新通知！';

            if ($conf['gxdate'] == 1) {

                $result = send_mail($conf['mail_name'], $msg, "嗨！亲爱的站长，你操作易支付程序更新成功啦！已经更新至V" . $version . "，具体更新内容请在平台中查看！"); //好困
            }
            unlink(ROOT . $filename);
            $config = "<?php
\$vin = '{$version}';
\$tmie = '{$date}';
\$display = '1';
?>
";

            file_put_contents(SYSTEM_ROOT . 'lib/version.php', $config);

            if ($conf['adminurl'] != 'admin') {
                recurse_copy(ROOT . 'admin', ROOT . $conf['adminurl']);
                del_DirAndFile(ROOT . 'admin');
                unlink(ROOT . 'content/storage/udatesql.lock');
                exit('{"code":1,"msg":"程序更新完毕！"}');
            } else {
                unlink(ROOT . 'content/storage/udatesql.lock');
                exit('{"code":1,"msg":"程序更新完毕！"}');
            }

        } else {
            exit('{"code":-1,"msg":"无新版本更新！"}');
        }

        break;

    case 'ddql':
        $ks = daddslashes($_POST['ks']) . " 00:00:00";
        $js = daddslashes($_POST['js']) . " 23:59:59";

        if ($ks > $js) {
            exit('{"code":0,"msg":"抱歉！时间选择错误"}');
        }

        $rows = $DB->query("SELECT * FROM pay_order WHERE `addtime`>='{$ks}' and `addtime`<='{$js}' and status<>1 ")->fetch();

        if (!$rows) {
            exit('{"code":0,"msg":"暂时无订单清理！"}');
        }

        $sql = "DELETE FROM pay_order WHERE `addtime`>='{$ks}' and `addtime`<='{$js}' and status<>1";
        if ($DB->exec($sql)) {
            exit('{"code":1,"msg":"清理完成！"}');
        } else {
            exit('{"code":0,"msg":"清理失败！"}');
        }

        break;

    case 'hqxy':
        if ($conf['protocol'] != '') {
            exit('{"code":0,"msg":"ok！"}');
        } else {
            exit('{"code":1,"msg":"no！"}');
        }
        break;
    case 'hqxys':

        $protocol = daddslashes($_POST['protocol']);

        $sql = "update `pay_admin` set `protocol` ='{$protocol}' where `id`='1'";
        if ($DB->exec($sql)) {
            exit('{"code":0,"msg":"修改成功！"}');
        } else {
            exit('{"code":-1,"msg":"设置失败！"}');
        }
        break;

    default:

        exit('{"code":-4,"msg":"请求方法不存在！"}');

        break;

}
