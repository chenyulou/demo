<?php 

include("../includes/common.php");


$directory = '/'.$conf['adminurl'].'/';//定义目录

$parameter = '?vparameter=';

$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://": "http://";//判断通讯协议

$adminurl = $protocol . $_SERVER['HTTP_HOST'].$directory.$parameter.$_SERVER['QUERY_STRING'];//拼接完整url

$arr = parse_url($adminurl);
 
//将URL中的参数取出来放到数组里
$arr_query = convertUrlQuery($arr['query']);

 if(isset($_GET['csv'])){exit(include 'views/pay_csv.php'); } //下载结算CSV

 if($islogin!=1){

	if($_SERVER['QUERY_STRING']){
		include 'routes/pay_'.$_SERVER['QUERY_STRING'].'.php'; 
	}
	header('Location: ?login'); 

}else{

	if ( isset($_GET['set']) || isset($_GET['email']) || isset($_GET['duan']) || isset($_GET['jieadd']) || isset($_GET['Intercept']) || isset($_GET['certify'])) {
		if (isset($_GET['mail']) || isset($_GET['jimail'])) {
			$yjli = "open active";
		}else{
			$xtpzli = "open active";
		}
	}else if(isset($_GET['ulist'])) {
		$yhglli = "open active";
	}elseif (isset($_GET['down'])) {
		$ggli = "open active";
	}elseif (isset($_GET['pei'])) {
		$jkli = "open active";
	}elseif (isset($_GET['slist']) || isset($_GET['operate']) || isset($_GET['settle'])) {
		$jsli = "open active";
	}elseif (isset($_GET['mail']) || isset($_GET['jimail'])) {
		$yjli = "open active";
	}elseif (isset($_GET['bak'])) {
		$bfli = "open active";
	}elseif (isset($_GET['plug'])) {
		$cjli = "open active";
	}elseif(!$_GET){
		$li = "open active";
	}

 	include './config/ini.php'; 
 	include './routes/pay_head.php';  

 	if($_SERVER['QUERY_STRING']=='login'){
 		header('Location: ./'); 

 	}

 	if($_SERVER['QUERY_STRING']){
		include 'views/pay_'.$arr_query['vparameter'].'.php'; 
	}else{
		include 'views/pay_index.php'; 
	}


}

 	include 'routes/pay_foot.php';

?>