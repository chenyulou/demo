<!DOCTYPE html>
<html class="no-js">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>支付管理中心</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <!-- Favicon -->
    <link rel="shortcut icon" href="favicon.ico" />

    <link rel="stylesheet" href="/assets/layui/css/layui.css"  media="all">
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="/assets/plugins/css/bootstrap.min.css">
    <!-- Fonts  -->
    <link rel="stylesheet" href="/assets/css/simple-line-icons.css">
    <!-- CSS Animate -->
    <link rel="stylesheet" href="/assets/plugins/css/animate.css">
    <!-- Daterange Picker -->
    <link rel="stylesheet" href="/assets/plugins/css/daterangepicker-bs3.css">
    <!-- Switchery -->
    <link rel="stylesheet" href="/assets/plugins/css/switchery.min.css">
    <!-- Custom styles for this theme -->
    <link rel="stylesheet" href="/assets/plugins/css/main.css">
    <!-- Feature detection -->
    <script src="/assets/plugins/js/modernizr-2.6.2.min.js"></script>

    <style type="text/css">

            @media (min-width:768px){
            .sms {
                 display: none!important;
               }
            #header {

                 width: 0px; 

            }
            .main-content-wrapper {
                padding-top: 0px;
            }
            }
    </style>
</head>

<body>
    <section id="main-wrapper" class="theme-default">
        <header id="header">
            <!--logo start-->
            <div class="brand" style="text-align: center;">
                <a href="./" class="logo">
                    <i class="fa fa-jsfiddle"></i>
                    <span>易支付</span>后台管理</a>
            </div>
            <!--logo end-->
            <ul class="nav navbar-nav navbar-left sms">
                <li class="toggle-navigation toggle-left">
                    <button class="sidebar-toggle" id="toggle-left">
                        <i class="fa fa-bars"></i>
                    </button>
                </li>
                <li class="toggle-profile hidden-xs">
                    <button type="button" class="btn btn-default" id="toggle-profile">
                        <i class="icon-user"></i>
                    </button>
                </li>
            </ul>
        </header>
        <!--sidebar left start-->
        <aside class="sidebar sidebar-left">
            <div class="sidebar-profile">
                <div class="avatar">
                      <img class="img-circle profile-image" src="<?php echo qqimg($conf['web_qq']);?>" alt="站长">
                    <i class="on border-dark animated bounceIn"></i>
                </div>
                <div class="profile-body dropdown">
                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><h4>嗨！管理员 <span class="caret"></span></h4></a>
                    <small class="title">欢迎回来</small>
                    <ul class="dropdown-menu animated fadeInRight" role="menu">
                        <li>
                            <a href="?pass">
                                <span class="icon"><i class="fa fa-cog"></i>
                                </span>密码管理</a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#" onclick="logout()">
                                <span class="icon"><i class="fa fa-sign-out"></i>
                                </span>退出登陆</a>
                        </li>
                    </ul>
                </div>
            </div>
            <nav>
                <h5 class="sidebar-header">导航</h5>
                <ul class="nav nav-pills nav-stacked">
                    <li class="<?php echo $li; ?>">
                        <a href="./" title="系统首页">
                            <i class="fa  fa-fw fa-desktop"></i> 系统首页
                        </a>
                    </li>
                    <li class="nav-dropdown <?php echo $xtpzli; ?>">
                        <a href="#" title="系统管理">
                            <i class="fa  fa-fw fa-cogs"></i> 系统管理
                        </a>
                        <ul class="nav-sub">
                            <li class="<?php if(isset($_GET['set'])){ echo "active"; } ?>">
                                <a href="?set" title="基本配置">
                                    <i class="fa fa-fw fa-file"></i>  基本配置
                                </a>
                            </li>
                            <li class="<?php if(!isset($_GET['mail']) && !isset($_GET['jimail']) && isset($_GET['email'])){ echo "active"; } ?>">
                                <a href="?email" title="邮箱配置">
                                    <i class="fa fa-fw fa-file"></i>  邮箱配置
                                </a>
                            </li>
                            <li class="<?php if(isset($_GET['duan'])){ echo "active"; } ?>">
                                <a href="?duan" title="短信配置">
                                    <i class="fa fa-fw fa-file"></i>  短信配置
                                </a>
                            </li>
                            <li class="<?php if(isset($_GET['jieadd'])){ echo "active"; } ?>">
                                <a href="?jieadd" title="结算配置">
                                    <i class="fa fa-fw fa-file"></i>  结算配置
                                </a>
                            </li>
                            <li class="<?php if(isset($_GET['Intercept'])){ echo "active"; } ?>">
                                <a href="?Intercept" title="拦截配置">
                                    <i class="fa fa-fw fa-file"></i>  拦截配置
                                </a>
                            </li>
                            <li class="<?php if(isset($_GET['certify'])){ echo "active"; } ?>">
                                <a href="?certify" title="认证配置">
                                    <i class="fa fa-fw fa-file"></i>  认证配置
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-dropdown <?php echo $yhglli; ?>">
                        <a href="#" title="用户管理">
                            <i class="fa fa-fw fa-user"></i>  用户管理
                        </a>
                        <ul class="nav-sub">
                            <li class="<?php if(isset($_GET['my'])){ echo "active"; } ?>">
                                <a href="?ulist&my=add" title="用户添加">
                                    <i class="fa fa-fw fa-file"></i>   用户添加
                                </a>
                            </li>
                            <li class="<?php if(!isset($_GET['my']) && isset($_GET['ulist'])){ echo "active"; } ?>">
                                <a href="?ulist" title="用户列表">
                                    <i class="fa fa-fw fa-file"></i>  用户列表
                                </a>
                            </li>
                        </ul>
                    </li>
                     <li class="nav-dropdown <?php echo $ggli; ?>">
                        <a href="#" title="公告管理">
                            <i class="fa fa-fw fa-volume-up"></i>  公告管理
                        </a>
                        <ul class="nav-sub">
                            <li class="<?php if(isset($_GET['close'])){ echo "active"; } ?>">
                                <a href="?down&close" title="公告发布">
                                    <i class="fa fa-fw fa-file"></i>   公告发布
                                </a>
                            </li>
                            <li class="<?php if(!isset($_GET['close']) && isset($_GET['down'])){ echo "active"; } ?>">
                                <a href="?down" title="公告列表">
                                    <i class="fa fa-fw fa-file"></i>  公告列表
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-dropdown <?php echo $jkli; ?>">
                        <a href="#" title="接口管理">
                            <i class="fa  fa-fw fa-sitemap"></i> 接口管理
                        </a>

                        <ul class="nav-sub">
                            <li class="<?php if(!isset($_GET['add']) && isset($_GET['pei'])){ echo "active"; } ?>">
                                <a href="?pei" title="接口添加">
                                    <i class="fa fa-fw fa-file"></i> 接口添加
                                </a>
                            </li>
                            <li class="<?php if(isset($_GET['add'])){ echo "active"; } ?>">
                                <a href="?pei&add" title="接口列表">
                                    <i class="fa fa-fw fa-file"></i> 接口列表
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-dropdown <?php echo $jsli; ?>">
                        <a href="#" title="结算管理">
                            <i class="fa  fa-fw fa-line-chart"></i> 结算管理
                            <span class="label label-primary label-circle pull-right" style="width: 10px;height: 10px;background-color: #F44336;"><?php if($count4!=0){  }?></span>
                        </a>
                        <ul class="nav-sub">
                            <li class="<?php if(isset($_GET['slist'])){ echo "active"; } ?>">
                                <a href="?slist" title="结算记录">
                                  <i class="fa fa-fw fa-file"></i>  结算记录
                                </a>
                            </li>
                            <li class="<?php if(isset($_GET['operate'])){ echo "active"; } ?>">
                                <a href="?operate" title="结算审核">
                                  <i class="fa fa-fw fa-file"></i>  结算审核
                                  <span class="label label-primary label-circle pull-right"><?php if($count4!=0){  }?></span>
                                </a>
                            </li>
                            <li class="<?php if(isset($_GET['settle'])){ echo "active"; } ?>">
                                <a href="?settle" title="结算操作">
                                    <i class="fa fa-fw fa-file"></i>  结算操作
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-dropdown <?php if(isset($_GET['order'])){ echo "active"; } ?>">
                        <a href="?order" title="订单管理">
                            <i class="fa fa-fw fa-bar-chart-o"></i> 订单管理
                        </a>
                    </li>
                    <li class="nav-dropdown <?php echo $yjli; ?>">
                         <a href="#" title="邮件管理">
                            <i class="fa fa-fw fa-envelope-o"></i> 邮件管理
                            <span class="label label-primary label-circle pull-right"><?php echo $count3;?></span>
                        </a>
                        <ul class="nav-sub">
                            <li class="<?php if(isset($_GET['mail'])){ echo "active"; } ?>">
                                <a href="?email&mail" title="发邮件">
                                  <i class="fa fa-fw fa-file"></i>   发邮件
                                </a>
                            </li>
                            <li class="<?php if(isset($_GET['jimail'])){ echo "active"; } ?>">
                                <a href="?email&jimail" title="发送记录">
                                    <i class="fa fa-fw fa-file"></i>  发送记录
                                </a>
                            </li>
                        </ul>
                    </li>
                      <li class="nav-dropdown <?php echo $bfli; ?>">
                        <a href="#" title="备份管理">
                            <i class="fa  fa-fw fa-file-text"></i> 备份管理
                        </a>
                        <ul class="nav-sub">
                            <li class="<?php if(!isset($_GET['act']) && isset($_GET['bak'])){ echo "active"; } ?>">
                                <a href="?bak" title="备份配置">
                                    <i class="fa fa-fw fa-file"></i>  备份配置
                                </a>
                            </li>

                            <li class="<?php if(isset($_GET['act'])){ echo "active"; } ?>">
                                <a href="?bak&act=add" title="备份记录">
                                    <i class="fa fa-fw fa-file"></i>  备份记录
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-dropdown <?php echo $cjli; ?>">
                        <a href="#" title="插件管理">
                            <i class="fa fa-fw fa-puzzle-piece"></i>  插件管理
                        </a>
                        <ul class="nav-sub">
                            <li class="<?php if(isset($_GET['add'])){ echo "active"; } ?>">
                                <a href="?plug&add" title="插件发布">
                                    <i class="fa fa-fw fa-file"></i>   插件发布
                                </a>
                            </li>
                            <li class="<?php if(!isset($_GET['add']) && isset($_GET['plug'])){ echo "active"; } ?>">
                                <a href="?plug" title="插件列表">
                                    <i class="fa fa-fw fa-file"></i>  插件列表
                                </a>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-dropdown <?php if(isset($_GET['money'])){ echo "active"; } ?>">
                        <a href="?money" title="流向记录">
                            <i class="fa fa-fw fa-area-chart"></i> 流向记录
                        </a>
                    </li>
                     <li class="nav-dropdown <?php if(isset($_GET['update'])){ echo "active"; } ?>">
                        <a href="?update" title="更新记录">
                            <i class="fa fa-fw fa-refresh fa-spin"></i> 程序更新
                        </a>
                    </li>
                    <li class="nav-dropdown <?php if(isset($_GET['basic'])){ echo "active"; } ?>">
                        <a href="?basic" title="使用帮助">
                            <i class="fa fa-fw fa-info-circle"></i> 使用帮助
                               <span class="pull-right badge badge-danger">new</span>
                        </a>
                    </li>
                </ul>
            </nav>
            <h5 class="sidebar-header">操作</h5>
            <div class="setting-list">
                <div class="row">
                    <div class="col-xs-8">
                        <label for="check1" class="control-label">登陆提醒</label>
                    </div>
                    <div class="col-xs-4">
                        <?php if($conf['Login']==1){?>
                        <input type="checkbox" value="<?php echo $conf['Login'];?>" log="log" class="js-switch" checked id="check1" />
                        <?php }else{?>
                        <input type="checkbox" value="<?php echo $conf['Login'];?>" log="log" class="js-switch" id="check2" />
                    <?php }?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-8">
                        <label for="check2" class="control-label">更新提醒</label>
                    </div>
                    <div class="col-xs-4">
                        <?php if($conf['gxdate']==1){?>
                        <input  type="checkbox" value="<?php echo $conf['gxdate'];?>" update="update" class="js-switch" checked id="check1" />
                        <?php }else{?>
                        <input  type="checkbox" value="<?php echo $conf['gxdate'];?>" update="update" class="js-switch" id="check2" />
                    <?php }?>
                    </div>
                </div>
            </div>
        </aside>
        <!--sidebar left end-->