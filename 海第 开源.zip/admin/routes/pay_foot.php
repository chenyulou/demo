<div class="modal fade" id="protocol" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title" id="myModalLabel">访问协议选择</h4>
                </div>
                <div class="modal-body">
                    <form class="form-horizontal" role="form">
                        <div class="form-group">
                            <label class="col-sm-3 control-label">访问协议</label>
                            <div class="col-sm-6">
                            <select class="form-control" name="protocol">
                                <option value="http" <?=$conf['protocol']=='http'?"selected":""?>>http</option>
                                <option value="https" <?=$conf['protocol']=='https'?"selected":""?>>https</option>
                            </select>
                            </div>
                        </div>
                        注意：选择当前你域名的协议http还是https，后续请在系统管理->基本配置中修改
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary protocol" style="margin-bottom: 0;">确定</button>
                </div>
            </div>
        </div>
    </div>
    <!--Global JS-->
      <script src="/assets/plugins/js/f7e76e000d.js"></script>
      <script src = "/assets/plugins/js/jquery.min.js" > </script> 
      <script src = "/assets/plugins/js/jquery-1.11.3.min.js" > </script> 
      <script src = "/assets/plugins/js/jquery-1.11.1.min.js" > </script> 
      <script src = "/assets/plugins/js/bootstrap.min.js" > </script> 
      <script src = "/assets/plugins/js/jquery.navgoco.min.js" > </script> 
      <script src = "/assets/plugins/js/app.js" > </script>

      <script src = "/assets/plugins/js/Chart.min.js" > </script>
      <!-- Morris  -->
      <script src = "/assets/plugins/js/morris.min.js" > </script> 
      <script src = "/assets/plugins/js/raphael.2.1.0.min.js" > </script>
      <!-- Gauge  -->
      <script src = "/assets/plugins/js/gauge.min.js" > </script>
      <!-- Switch -->
      <script src = "/assets/plugins/js/switchery.min.js" > </script>
      <!--fullscreen-->
      <script src = "/assets/plugins/js/jquery.fullscreen-min.js" > </script>
      <!-- layer -->
      <script src = "/assets/layer/layer.js" > </script>

      <script src = "/assets/js/echarts.min.js" > </script>

      <script >
      $(function() {

        $.ajax({
              type: "POST",
              url: "./config/jiekou.php?act=hqxy",
              data: {
                id: 1
              },
              dataType: 'json',
              success: function(data) {
                if (data.code == 1) {
                  $('#protocol').modal('show');
                }
              }
            });

        $(".protocol").click(function() {

          var protocol = $(this).parent().prev().find("select[name='protocol']").val();

          $.ajax({
            type: "POST",
            url: "./config/jiekou.php?act=hqxys",
            data: {
              protocol: protocol
            },
            dataType: 'json',
            success: function(data) {
              if (data.code == 0) {
                window.location.reload();
              } else {
                layer.alert(data.msg);
              }

            }
          });

        })

        $(".switchery").click(function() {
          var status = $(this).prev().val() == 1 ? 0 : 1;
          var id = $(this).prev().attr("ids");
          var log = $(this).prev().attr("log");
          var qqlog = $(this).prev().attr("qqlog");
          var wxlog = $(this).prev().attr("wxlog");
          var update = $(this).prev().attr("update");
          if (log) {
            var url = './config/jiekou.php?act=log';
          };
          if (qqlog) {
            var url = './config/jiekou.php?act=logs&type=qq';
          };
          if (wxlog) {
            var url = './config/jiekou.php?act=logs&type=wx';
          };
          if (update) {
            var url = './config/jiekou.php?act=update';
          };
          if (id) {
            var url = './config/jiekou.php?act=apiStatusEdit';
          }
          $.ajax({
            url: url,
            data: {
              status: status,
              id: id
            },
            success: function(res) {}
          })
        })

        $(".deijk").click(function() {
          var id = $(this).attr("pid");
          layer.confirm('确定要删除此接口吗?', {
            icon: 3,
            title: '提示'
          }, function(index) {
            layer.close(index);
            var ii = layer.load(2, {
              shade: [0.1, '#fff']
            });
            $.ajax({
              type: "POST",
              url: "./config/jiekou.php?act=deijk",
              data: {
                id: id
              },
              dataType: 'json',
              success: function(data) {
                layer.close(ii);
                if (data.code == 0) {
                  layer.msg('删除成功!');
                  window.location.reload();
                } else {
                  layer.msg(data.msg);
                }
              }
            });
          });
        })

        $(".creat").click(function() {
          layer.confirm('确定要生成吗?', {
            icon: 3,
            title: '提示'
          }, function(index) {
            layer.close(index);
            var ii = layer.load(2, {
              shade: [0.1, '#fff']
            });
            $.ajax({
              type: "POST",
              url: "./config/jiekou.php?act=creat",
              dataType: 'json',
              success: function(data) {
                layer.close(ii);
                if (data.code == 0) {
                  layer.msg('生成成功!');
                  window.location.reload();
                }
              }
            });
          });
        })

        $(".jies").click(function() {
          var batch = $(this).attr('batch');
          layer.confirm('确定要结算吗?', {
            icon: 3,
            title: '提示'
          }, function(index) {
            layer.close(index);
            var ii = layer.load(2, {
              shade: [0.1, '#fff']
            });
            $.ajax({
              type: "POST",
              url: "./config/jiekou.php?act=jies",
              data: {
                batch: batch
              },
              dataType: 'json',
              success: function(data) {
                layer.close(ii);
                if (data.code == 0) {
                  layer.msg('结算成功!');
                  window.location.reload();
                }
              }
            });
          });
        })

        $(".transfer").click(function() {
          var batch = $(this).attr('batch');
          $('#transfer').modal('show');
          $('#transfer-name').html(`
       <a href="./?transfer&batch=${batch}&type=qqpay&transfer=1"><button type="button" class="btn btn-warning btn-block">QQ钱包</button></a>
       <a href="./?transfer&batch=${batch}&type=wxpay&transfer=1"><button type="button" class="btn btn-success btn-block" style="margin-top: 10px;">企业微信</button></a>
       <a href="./?transfer&batch=${batch}&type=alipay&transfer=1"><button type="button" class="btn btn-info btn-block" style="margin-top: 10px;">企业支付宝</button></a>
       <a href="#"><button type="button" class="btn btn-default btn-block" style="margin-top: 10px;">银行API(开发中)</button></a><hr>正在处理批次号：${batch}
       <div class="actions pull-right"><a href="./?transfer&batch=${batch}&type=pay&transfer=1">不操作转账仅处理</a></div>
        `);
        })


        $(".ddql").click(function() {

          var ks = $(this).parent().prev().find("input[name='ks-date']").val();
          var js = $(this).parent().prev().find("input[name='js-date']").val();
          $.ajax({
            type: "POST",
            url: "./config/jiekou.php?act=ddql",
            data: {
              ks: ks,
              js: js
            },
            dataType: 'json',
            success: function(data) {
              if (data.code == 1) {
                layer.msg('清理完成！');
                window.location.reload();
              } else {
                layer.alert(data.msg);
              }

            }
          });

        })


        $(".download").click(function() {
          var batch = $(this).attr('batch');
          var allmoney = $(this).attr('allmoney');
          $('#download').modal('show');
          $('#download-name').html(`
       <a href="./?csv&type=qqpay&batch=${batch}&allmoney=${allmoney}"><button type="button" class="btn btn-warning " style="margin-top: 10px;">QQ</button></a>
       <a href="./?csv&type=wxpay&batch=${batch}&allmoney=${allmoney}"><button type="button" class="btn btn-success " style="margin-top: 10px;">微信</button></a>
       <a href="./?csv&type=alipay&batch=${batch}&allmoney=${allmoney}"><button type="button" class="btn btn-info " style="margin-top: 10px;">支付宝</button></a>
       <a href="./?csv&type=bank&batch=${batch}&allmoney=${allmoney}"><button type="button" class="btn btn-default " style="margin-top: 10px;">银行</button></a>
       <a href="./?csv&type=all&batch=${batch}&allmoney=${allmoney}"><button type="button" class="btn btn-primary btn-block" style="margin-top: 10px;">类型结合下载</button></a>
        `);
        })


        $(".operate").click(function() {
          var id = $(this).attr("ids");
          var jss = $(this).attr("jss");
          layer.confirm('结算账号：' + jss + '<br>确定要处理该记录吗?', {
            icon: 3,
            title: '结算提示'
          }, function(index) {
            layer.close(index);
            var ii = layer.load(2, {
              shade: [0.1, '#fff']
            });
            $.ajax({
              type: "POST",
              url: "./config/jiekou.php?act=operate",
              data: {
                id: id
              },
              dataType: 'json',
              success: function(data) {
                layer.close(ii);
                if (data.code == 0) {
                  layer.msg('结算完成!');
                  window.location.reload();
                } else {
                  layer.msg(data.msg);
                }
              }
            });
          });
        })



        $(".bohui").click(function() {

          var id = $(this).attr("ids");
          var jss = $(this).attr("jss");
          var fee = $(this).attr("fee");
          var money = $(this).attr("money") + '元，包含手续费' + fee;

          $('#bohui').modal('show');

          $('#content').html(`
          <input type="hidden" name="id" value="${id}">
          <div class="form-group">
                <input type="email" class="form-control" value="驳回金额：${money}" disabled>
          </div>
          <div class="form-group">
                <input type="email" class="form-control" value="驳回账号：${jss}" disabled>
          </div>
          <div class="form-group">
                <textarea placeholder="驳回原因" class="layui-textarea" name="content"></textarea>
          </div>
          `);
        })
        $("#operates").click(function() {

          var id = $("input[name='id']").val();

          var content = $("textarea[name='content']").val();

          var ii = layer.load(2, {
            shade: [0.1, '#fff']
          });
          $.ajax({
            type: "POST",
            url: "./config/jiekou.php?act=operates",
            data: {
              id: id,
              content: content
            },
            dataType: 'json',
            success: function(data) {
              layer.close(ii);
              if (data.code == 0) {
                layer.msg('驳回成功!');
                window.location.reload();
              } else {
                layer.msg(data.msg);
              }
            }
          });

        })

      })

    $(".Update").click(function() {
      var type = "jc";
      $.ajax({
        type: "POST",
        url: "./config/jiekou.php?act=Update",
        data: {
          type: type
        },
        dataType: 'json',
        success: function(data) {
          layer.msg('检查更新中..', {
            icon: 16,
            shade: 0.01
          });
          if (data.code == 1) {
            layer.closeAll();
            $('#update').modal('show');
            $('#version').html('可更新版本：V ' + data.version);
            $('#names').html(`${data.name}`);
          } else {
            layer.msg(data.msg, {
              icon: 5
            });
          }
        }
      });
    })
    $("select[name=\'is_pay\']").change(function() {
      if ($(this).val() == '1') {
        $("#is_payS").css("display", "inherit");
      } else {
        $("#is_payS").css("display", "none");
      }
    });
    $("select[name=\'smrz\']").change(function() {
      if ($(this).val() == '1') {
        $("#is_smrz").css("display", "inherit");
      } else {
        $("#is_smrz").css("display", "none");
      }
    });
    $("select[name=\'type1\']").change(function() {
      if ($(this).val() == 'qqpay') {
        $("#h5").css("display", "none");
        $("#qqpay1").css("display", "inherit");
      } else {
        $("#qqpay1").css("display", "none");

      }
    });
    $("select[name=\'type1\']").change(function() {
      if ($(this).val() == 'wxpay') {
        $("#wxpay1").css("display", "inherit");
        $("#h5").css("display", "inherit");
      } else {
        $("#wxpay1").css("display", "none");

      }
    });
    $("select[name=\'type1\']").change(function() {
      if ($(this).val() == 'alipay') {
        $("#h5").css("display", "none");
        $("#alipay1").css("display", "inherit");
      } else {
        $("#alipay1").css("display", "none");

      }
    });
    $("select[name=\'type1\']").change(function() {
      if ($(this).val() == 'dmpay') {
        $("#h5").css("display", "none");
        $("#dmpay1").css("display", "inherit");
      } else {
        $("#dmpay1").css("display", "none");

      }
    });

    $("select[name=\'type1\']").change(function() {
      if ($(this).val() == 'epay') {
        $("#epay1").css("display", "inherit");
        $("#h5").css("display", "inherit");
      } else {
        $("#epay1").css("display", "none");

      }
    });
    $("select[name=\'type1\']").change(function() {
      if ($(this).val() == 'eshangpay') {
        $("#h5").css("display", "none");
        $("#eshangpay1").css("display", "inherit");
      } else {
        $("#eshangpay1").css("display", "none");

      }
    });
    $("select[name=\'type1\']").change(function() {
      if ($(this).val() == 'wftpay') {
        $("#h5").css("display", "none");
        $("#wftpay1").css("display", "inherit");
      } else {
        $("#wftpay1").css("display", "none");

      }
    });

    $("select[name=\'type2\']").change(function() {
      if ($(this).val() == '2') {
        $("#email").css("display", "inherit");
      } else {
        $("#email").css("display", "none");
      }
    });


    $("select[name=\'type\']").change(function() {
      if ($(this).val() == 'qqpay') {
        $(".wxpay").find(":input").attr("disabled", true);
        $(".alipay").find(":input").attr("disabled", true);
        $(".qqpay").find(":input").attr("disabled", false);
        $(".qqpay").css("display", "inherit");
      } else {
        $(".qqpay").css("display", "none");
      }
    });

    $("select[name=\'type\']").change(function() {
      if ($(this).val() == 'wxpay') {
        $(".qqpay").find(":input").attr("disabled", true);
        $(".alipay").find(":input").attr("disabled", true);
        $(".wxpay").find(":input").attr("disabled", false);
        $(".wxpay").css("display", "inherit");
      } else {
        $(".wxpay").css("display", "none");
      }
    });

    $("select[name=\'type\']").change(function() {
      if ($(this).val() == 'alipay') {
        $(".qqpay").find(":input").attr("disabled", true);
        $(".wxpay").find(":input").attr("disabled", true);
        $(".alipay").find(":input").attr("disabled", false);
        $(".alipay").css("display", "inherit");
      } else {
        $(".alipay").css("display", "none");
      }
    });


    function Update() {
      var ii = layer.load(2, {
        shade: [0.1, '#fff']
      });
      $.ajax({
        type: "POST",
        url: "./config/jiekou.php?act=Update",
        dataType: 'json',
        success: function(data) {
          layer.close(ii);
          if (data.code == 1) {
            $('#update').modal('hide');
            layer.alert(data.msg, {
              icon: 1
            });
          } else {
            $('#update').modal('hide');
            layer.alert(data.msg, {
              icon: 2
            });
          }
        }
      });
    }

    function userpanel(user, pass) {
      var ii = layer.load(2, {
        shade: [0.1, '#fff']
      });
      $.ajax({
        type: "POST",
        url: "./config/jiekou.php?act=userlog",
        data: {
          user: user,
          pass: pass
        },
        dataType: 'json',
        success: function(data) {
          layer.close(ii);
          if (data.code == 0) {
            window.open("/user/");
          }
        }
      });
    }

    function set() {
      var ii = layer.load(2, {
        shade: [0.1, '#fff']
      });
      $.ajax({
        type: "POST",
        url: "./config/jiekou.php?act=set",
        data: $('#form_set').serialize(),
        dataType: 'json',
        success: function(data) {
          layer.close(ii);
          if (data.code == 0) {
            layer.msg(data.msg, function(index) {
              parent.layer.closeAll();
              window.location.reload();
            });
          } else {
            layer.msg(data.msg);
          }
        }
      });
    }

    function plug() {
      var ii = layer.load(2, {
        shade: [0.1, '#fff']
      });
      $.ajax({
        type: "POST",
        url: "./config/jiekou.php?act=plug",
        data: $('#form_plug').serialize(),
        dataType: 'json',
        success: function(data) {
          layer.close(ii);
          if (data.code == 0) {
            layer.msg(data.msg, function(index) {
              parent.layer.closeAll();
              window.location.reload();
            });
          } else {
            layer.msg(data.msg);
          }
        }
      });
    }

    function plugs() {
      var ii = layer.load(2, {
        shade: [0.1, '#fff']
      });
      $.ajax({
        type: "POST",
        url: "./config/jiekou.php?act=plug&add=xg",
        data: $('#form_plugs').serialize(),
        dataType: 'json',
        success: function(data) {
          layer.close(ii);
          if (data.code == 0) {
            layer.msg(data.msg, function(index) {
              parent.layer.closeAll();
              window.location.reload();
            });
          } else {
            layer.msg(data.msg);
          }
        }
      });
    }

    function plugssc(id) {
      layer.confirm('确定要删除此插件吗?', {
        icon: 3,
        title: '提示'
      }, function(index) {
        layer.close(index);
        var ii = layer.load(2, {
          shade: [0.1, '#fff']
        });
        $.ajax({
          type: "POST",
          url: "./config/jiekou.php?act=plug&add=sc",
          data: {
            id: id
          },
          dataType: 'json',
          success: function(data) {
            layer.close(ii);
            if (data.code == 0) {
              layer.msg('删除成功!');
              window.location.reload();
            } else {
              layer.msg(data.msg);
            }
          }
        });
      });
    }

    function certify() {
      var ii = layer.load(2, {
        shade: [0.1, '#fff']
      });
      $.ajax({
        type: "POST",
        url: "./config/jiekou.php?act=certify",
        data: $('#form_certify').serialize(),
        dataType: 'json',
        success: function(data) {
          layer.close(ii);
          if (data.code == 0) {
            layer.msg(data.msg, function(index) {
              parent.layer.closeAll();
              window.location.reload();
            });
          } else {
            layer.msg(data.msg);
          }
        }
      });
    }

    function ljpz() {
      var ii = layer.load(2, {
        shade: [0.1, '#fff']
      });
      $.ajax({
        type: "POST",
        url: "./config/jiekou.php?act=ljpz",
        data: $('#form_ljpz').serialize(),
        dataType: 'json',
        success: function(data) {
          layer.close(ii);
          if (data.code == 0) {
            layer.msg(data.msg, function(index) {
              parent.layer.closeAll();
              window.location.reload();
            });
          } else {
            layer.msg(data.msg);
          }
        }
      });
    }

    function bakc() {
      var ii = layer.load(2, {
        shade: [0.1, '#fff']
      });
      $.ajax({
        type: "POST",
        url: "./config/jiekou.php?act=bakxg",
        data: $('#form_bak').serialize(),
        dataType: 'json',
        success: function(data) {
          layer.close(ii);
          if (data.code == 0) {
            layer.msg(data.msg, function(index) {
              parent.layer.closeAll();
              window.location.reload();
            });
          } else {
            layer.msg(data.msg);
          }
        }
      });
    }

    function mail() {
      var ii = layer.load(2, {
        shade: [0.1, '#fff']
      });
      $.ajax({
        type: "POST",
        url: "./config/jiekou.php?act=email",
        data: $('#form_mail').serialize(),
        dataType: 'json',
        success: function(data) {
          layer.close(ii);
          if (data.code == 0) {
            layer.msg(data.msg, function(index) {
              parent.layer.closeAll();
              window.location.reload();
            });
          } else {
            layer.msg(data.msg);
          }
        }
      });
    }

    function jies() {
      var ii = layer.load(2, {
        shade: [0.1, '#fff']
      });
      $.ajax({
        type: "POST",
        url: "./config/jiekou.php?act=jie",
        data: $('#form_jies').serialize(),
        dataType: 'json',
        success: function(data) {
          layer.close(ii);
          if (data.code == 0) {
            layer.msg(data.msg, function(index) {
              parent.layer.closeAll();
              window.location.reload();
            });
          } else {
            layer.msg(data.msg);
          }
        }
      });
    }

    function jiesali() {
      var ii = layer.load(2, {
        shade: [0.1, '#fff']
      });
      $.ajax({
        type: "POST",
        url: "./config/jiekou.php?act=jieali",
        data: $('#form_jies_ali').serialize(),
        dataType: 'json',
        success: function(data) {
          layer.close(ii);
          if (data.code == 0) {
            layer.msg(data.msg, function(index) {
              parent.layer.closeAll();
              window.location.reload();
            });
          } else {
            layer.msg(data.msg);
          }
        }
      });
    }

    function pass() {
      var ii = layer.load(2, {
        shade: [0.1, '#fff']
      });
      $.ajax({
        type: "POST",
        url: "./config/jiekou.php?act=pass",
        data: $('#form_pass').serialize(),
        dataType: 'json',
        success: function(data) {
          layer.close(ii);
          if (data.code == 0) {
            layer.msg(data.msg, function(index) {
              parent.layer.closeAll();
              window.location.reload();
            });
          } else {
            layer.msg(data.msg);
          }
        }
      });
    }


    function duan() {
      var ii = layer.load(2, {
        shade: [0.1, '#fff']
      });
      $.ajax({
        type: "POST",
        url: "./config/jiekou.php?act=duan",
        data: $('#form_duan').serialize(),
        dataType: 'json',
        success: function(data) {
          layer.close(ii);
          if (data.code == 0) {
            layer.msg(data.msg, function(index) {
              parent.layer.closeAll();
              window.location.reload();
            });
          } else {
            layer.msg(data.msg);
          }
        }
      });
    }

    function cjmb() {
      var ii = layer.load(2, {
        shade: [0.1, '#fff']
      });
      $.ajax({
        type: "POST",
        url: "./config/jiekou.php?act=cjmb",
        data: $('#form_cjmb').serialize(),
        dataType: 'json',
        success: function(data) {
          layer.close(ii);
          if (data.code == 0) {
            layer.msg(data.msg, function(index) {
              parent.layer.closeAll();
              window.location.reload();
            });
          } else {
            layer.msg(data.msg);
          }
        }
      });
    }


    function mbsc(id) {
      layer.confirm('确定要删除此模板吗?', {
        icon: 3,
        title: '提示'
      }, function(index) {
        layer.close(index);
        var ii = layer.load(2, {
          shade: [0.1, '#fff']
        });
        $.ajax({
          type: "POST",
          url: "./config/jiekou.php?act=cjmb",
          data: {
            id: id,
            type: 2
          },
          dataType: 'json',
          success: function(data) {
            layer.close(ii);
            if (data.code == 0) {
              layer.msg('删除成功!');
              window.location.reload();
            } else {
              layer.msg(data.msg);
            }
          }
        });
      });
    }

    function logout() {
      layer.confirm('确定要退出登陆吗?', {
        icon: 3,
        title: '提示'
      }, function(index) {
        layer.close(index);
        var ii = layer.load(2, {
          shade: [0.1, '#fff']
        });
        $.ajax({
          type: "POST",
          url: "./config/jiekou.php?logout",
          dataType: 'json',
          success: function(data) {
            layer.close(ii);
            layer.msg('退出成功!');
            window.location.reload();
          }
        });
      });
    }

    function jie() {
      var ii = layer.load(2, {
        shade: [0.1, '#fff']
      });
      $.ajax({
        type: "POST",
        url: "./config/jiekou.php?act=jieko",
        data: $('#form_jie').serialize(),
        dataType: 'json',
        success: function(data) {
          layer.close(ii);
          if (data.code == 0) {
            layer.msg(data.msg, function(index) {
              parent.layer.closeAll();
              window.location.reload();
            });
          } else {
            layer.msg(data.msg);
          }
        }
      });
    }

    function fsmail() {
      var ii = layer.load(2, {
        shade: [0.1, '#fff']
      });
      $.ajax({
        type: "POST",
        url: "./config/jiekou.php?act=qfa",
        data: $('#form_fsmail').serialize(),
        dataType: 'json',
        success: function(data) {
          layer.close(ii);
          if (data.code == 0) {
            layer.msg(data.msg, function(index) {
              parent.layer.closeAll();
              window.location.reload();
            });
          } else {
            layer.msg(data.msg);
          }
        }
      });
    }

    function youdei(id) {
      layer.confirm('确定要删除该记录吗?', {
        icon: 3,
        title: '提示'
      }, function(index) {
        layer.close(index);
        var ii = layer.load(2, {
          shade: [0.1, '#fff']
        });
        $.ajax({
          type: "POST",
          url: "./config/jiekou.php?act=youdei",
          data: {
            id: id
          },
          dataType: 'json',
          success: function(data) {
            layer.close(ii);
            if (data.code == 0) {
              layer.msg('删除成功!');
              window.location.reload();
            } else {
              layer.msg(data.msg);
            }
          }
        });
      });
    }

    function die_sh(id) {
      layer.confirm('确定要删除该用户吗?', {
        icon: 3,
        title: '提示'
      }, function(index) {
        layer.close(index);
        var ii = layer.load(2, {
          shade: [0.1, '#fff']
        });
        $.ajax({
          type: "POST",
          url: "./config/jiekou.php?act=delete_sh",
          data: {
            id: id
          },
          dataType: 'json',
          success: function(data) {
            layer.close(ii);
            if (data.code == 0) {
              layer.msg('删除成功!');
              window.location.reload();
            } else {
              layer.msg(data.msg);
            }
          }
        });
      });
    }

    function die_mali(id) {
      layer.confirm('确定要删除此记录吗?', {
        icon: 3,
        title: '提示'
      }, function(index) {
        layer.close(index);
        var ii = layer.load(2, {
          shade: [0.1, '#fff']
        });
        $.ajax({
          type: "POST",
          url: "./config/jiekou.php?act=del_mali",
          data: {
            id: id
          },
          dataType: 'json',
          success: function(data) {
            layer.close(ii);
            if (data.code == 0) {
              layer.msg('删除成功!');
              window.location.reload();
            } else {
              layer.msg(data.msg);
            }
          }
        });
      });
    }



    function bak() {
      var ii = layer.load(2, {
        shade: [0.1, '#fff']
      });
      $.ajax({
        type: "POST",
        url: "./config/jiekou.php?act=bak",
        data: $('#form_bak').serialize(),
        dataType: 'json',
        success: function(data) {
          layer.close(ii);
          if (data.code == 0) {
            layer.msg(data.msg, function(index) {
              parent.layer.closeAll();
              window.location.reload();
            });
          } else {
            layer.msg(data.msg);
          }
        }
      });
    }


    function edit() {
      var ii = layer.load(2, {
        shade: [0.1, '#fff']
      });
      $.ajax({
        type: "POST",
        url: "./config/jiekou.php?act=edit_submit",
        data: $('#form_edit').serialize(),
        dataType: 'json',
        success: function(data) {
          layer.close(ii);
          if (data.code == 0) {
            layer.msg(data.msg, function(index) {
              parent.layer.closeAll();
              window.location.reload();
            });
          } else {
            layer.msg(data.msg);
          }
        }
      });
    }

    function add_submit() {
      var ii = layer.load(2, {
        shade: [0.1, '#fff']
      });
      $.ajax({
        type: "POST",
        url: "./config/jiekou.php?act=add_submit",
        data: $('#form_add').serialize(),
        dataType: 'json',
        success: function(data) {
          layer.close(ii);
          if (data.code == 0) {
            layer.msg(data.msg, function(index) {
              parent.layer.closeAll();
              window.location.reload();
            });
          } else {
            layer.msg(data.msg);
          }
        }
      });
    }



    function closes() {
      var ii = layer.load(2, {
        shade: [0.1, '#fff']
      });
      $.ajax({
        type: "POST",
        url: "./config/jiekou.php?act=close",
        data: $('#form_close').serialize(),
        dataType: 'json',
        success: function(data) {
          layer.close(ii);
          if (data.code == 0) {
            layer.msg(data.msg, function(index) {
              parent.layer.closeAll();
              window.location.reload();
            });
          } else {
            layer.msg(data.msg);
          }
        }
      });
    }


    function add_down() {
      var ii = layer.load(2, {
        shade: [0.1, '#fff']
      });
      $.ajax({
        type: "POST",
        url: "./config/jiekou.php?act=addown",
        data: $('#form_down').serialize(),
        dataType: 'json',
        success: function(data) {
          layer.close(ii);
          if (data.code == 0) {
            layer.msg(data.msg, function(index) {
              parent.layer.closeAll();
              window.location.reload();
            });
          } else {
            layer.msg(data.msg);
          }
        }
      });
    }



    function add_gxm() {
      var ii = layer.load(2, {
        shade: [0.1, '#fff']
      });
      $.ajax({
        type: "POST",
        url: "./config/jiekou.php?act=upgx",
        data: $('#form_gxm').serialize(),
        dataType: 'json',
        success: function(data) {
          layer.close(ii);
          if (data.code == 0) {
            layer.msg(data.msg, function(index) {
              parent.layer.closeAll();
              window.location.reload();
            });
          } else {
            layer.msg(data.msg);
          }
        }
      });
    }


    function die_down(id) {
      layer.confirm('确定要删除此记录吗?', {
        icon: 3,
        title: '提示'
      }, function(index) {
        layer.close(index);
        var ii = layer.load(2, {
          shade: [0.1, '#fff']
        });
        $.ajax({
          type: "POST",
          url: "./config/jiekou.php?act=del_down",
          data: {
            id: id
          },
          dataType: 'json',
          success: function(data) {
            layer.close(ii);
            if (data.code == 0) {
              layer.msg('删除成功!');
              window.location.reload();
            } else {
              layer.msg(data.msg);
            }
          }
        });
      });
    }


    window.onload = function() {
      var doughnutData = [{
          value: <?php echo round($jt_wxpay,2);?>,
          color: "#1ABC9C",
          highlight: "#1ABC9C",
          label: "微信"
        }, {
          value: <?php echo round($jt_alipay,2);?>,
          color: "#1f7bb6",
          highlight: "#1f7bb6",
          label: "支付宝"
        }, {
          value: <?php echo round($jt_qqpay,2);?>,
          color: "#EDCE8C",
          highlight: "#EDCE8C",
          label: "QQ"
        }

      ];

      var ctx3 = document.getElementById("doughnut-chart-area").getContext("2d");
      window.myDoughnut = new Chart(ctx3).Doughnut(doughnutData, {
        responsive: true
      });

    };

    var opts = {
      lines: 0, // The number of lines to draw
      angle: 0, // The length of each line
      lineWidth: 0.4, // The line thickness
      pointer: {
        length: 0.75, // The radius of the inner circle
        strokeWidth: 0.042, // The rotation offset
        color: '#1D212A' // Fill color
      },
      // limitMax: 'false',   // If true, the pointer will not go past the end of the gauge
      colorStart: '#1ABC9C', // Colors
      colorStop: '#1ABC9C', // just experiment with them
      strokeColor: '#F0F3F3', // to see which ones work best for you
      // generateGradient: true
    };
    var target = document.getElementById('gauge'); // your canvas element
    var gauge = new Gauge(target).setOptions(opts); // create sexy gauge!
    gauge.maxValue = <?php echo round($zt_sum,2);?>; // set max gauge value
    // gauge.animationSpeed = 12; // set animation speed (32 is default value)
    gauge.set(<?php echo round($jt_sum,2);?>); // set actual value
    gauge.setTextField(document.getElementById("gauge-text"));

    $(document).ready(function() {
      $('#popover-left,#popover-top,#popover-bottom,#popover-right').popover()
      $('#tooltip-left,#tooltip-top,#tooltip-bottom,#tooltip-right').tooltip()
    });



    var zhexianchart = echarts.init(document.getElementById('center-zhexian'));
    var zhexianoption = {
      tooltip: {
        trigger: 'axis'
      },
      legend: {
        data: ['支付订单', '收入金额', '商户注册']
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true
      },
      toolbox: {
        feature: {
          saveAsImage: {}
        }
      },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: <?php echo json_encode($zhexiandatakey)?>
      },
      yAxis: {
        type: 'value'
      },
      series: [{
        name: '支付订单',
        type: 'line',
        stack: '总量',
        data: <?php echo json_encode($zhexiandata)?>
      }, {
        name: '收入金额',
        type: 'line',
        stack: '总量',
        data: <?php echo json_encode($zhexiandatamoney)?>
      }, {
        name: '商户注册',
        type: 'line',
        stack: '总量',
        data: <?php echo json_encode($zhexiandatauser)?>
      }]
    };
    zhexianchart.setOption(zhexianoption);

    var zhexianchart_tou = echarts.init(document.getElementById('center-zhexian-ton'));
    var zhexianoption_tou = {
      tooltip: {
        trigger: 'axis'
      },
      legend: {
        data: ['QQ钱包', '微信', '支付宝']
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true
      },
      toolbox: {
        feature: {
          saveAsImage: {}
        }
      },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: <?php echo json_encode($zhexiandata_time)?>
      },
      yAxis: {
        type: 'value'
      },
      series: [{
        name: 'QQ钱包',
        type: 'line',
        stack: '总量',
        data: <?php echo json_encode($zhexiandata_qq)?>,
        itemStyle: {
          color: '#fad733'
        }
      }, {
        name: '微信',
        type: 'line',
        stack: '总量',
        data: <?php echo json_encode($zhexiandata_wx)?>,
        itemStyle: {
          color: '#27c24c'
        }
      }, {
        name: '支付宝',
        type: 'line',
        stack: '总量',
        data: <?php echo json_encode($zhexiandata_ali)?>,
        itemStyle: {
          color: '#23b7e5'
        }
      }]
    };

    zhexianchart_tou.setOption(zhexianoption_tou);


    </script>