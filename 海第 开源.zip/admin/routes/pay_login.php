<?php
if($islogin==1){

	exit("<script language='javascript'>alert('您已登陆！');window.location.href='./';</script>");

}
?>
<!DOCTYPE html>
<html class="no-js">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>海弟支付管理系统</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <!-- Favicon -->
    <!-- Favicon -->
    <link rel="shortcut icon" href="favicon.ico" />
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="/assets/plugins/css/bootstrap.min.css">
    <!-- Fonts  -->
    <link rel="stylesheet" href="/assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="/assets/css/simple-line-icons.css">
    <!-- Custom styles for this theme -->
    <link rel="stylesheet" href="/assets/plugins/css/main.css">


</head>

<body style="background-color: #27b6af;">
    <section class="container animated fadeInUp">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div id="login-wrapper">
                    <header>
                        <div class="brand">
                            <a href="index.html" class="logo">
                                <i class="fa fa-jsfiddle"></i>
                                <span><?php echo $conf['web_name'];?></span>后台管理</a>
                        </div>
                    </header>
                    <div class="panel panel-primary">
                        <div class="panel-heading" style="border-top-left-radius: 0px; border-top-right-radius: 0px;">
                            <h3 class="panel-title">     
                           海弟支付管理系统
                        </h3>
                        </div>
                        <div class="panel-body">
                            <form class="form-horizontal" id="login" role="form">
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <input type="email" class="form-control" style="padding: 6px 30px;" name="user" placeholder="账号">
                                        <i class="fa fa-user"></i>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <input type="password" class="form-control" style="padding: 6px 30px;" name="pass" placeholder="密码">
                                        <i class="fa fa-lock"></i>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <a href="#" onclick="log()" class="btn btn-primary btn-block">登录</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
   <script src="//apps.bdimg.com/libs/jquery/1.9.1/jquery.js"></script>
   <script src="/assets/layer/layer.js"></script>
<script>
        function log(){

        $.ajax({

            type : "POST",

            url : "./config/jiekou.php?login",

            data : $('#login').serialize(),

            dataType : 'json',

            success : function(data) {
                
                layer.msg('登录中..', {
                  icon: 16
                  ,shade: 0.01
                });
                if(data.code == 0){
                  layer.msg('登录成功', {icon: 1});
                   window.setTimeout(function () {
                      window.location.href="./";
                    }, 3000);
                }else{

                    layer.msg(data.msg, {icon: 2});

                }

            }

        });
    }
</script>
</body>

</html>
