<?php 
if($islogin!=1){

    if($islogin!=2){

        exit('File not found.');
    
    }

}

$my=isset($_GET['my'])?$_GET['my']:null;

$numrows=$DB->query("SELECT count(*) from pay_bak WHERE 1")->fetchColumn();
if(isset($_GET['pagesize'])){
$pagesize=$_GET['pagesize'];
}else{
$pagesize=10;
}
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);

$list=$DB->query("SELECT * FROM pay_bak WHERE 1 order by id desc limit $offset,$pagesize")->fetchAll();

 ?>
<?php if($_GET['act']=='add'){ ?>
<section class="main-content-wrapper">
<section id="main-content" class="animated fadeInUp">
	<div class="calendar-block" style="margin-bottom: 15px;">
	    <div class="cal1">
	     <h2 style="padding: 6px 12px;"><i class="fa fa-home"></i> 首页 / 备份记录</h2>
	    </div>
	</div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">备份记录</h3>
                    <div class="actions pull-right">
                        <i class="fa fa-expand"></i>
                    </div>
                </div>

                            <div class="table-responsive">
                                    <table class="table table-striped">
                                      <thead><tr><th>排序</th><th>备份目录</th><th>备份名称</th><th>备份状态</th><th>备份时间</th></tr></thead>
                                      <tbody>
                            <?php
                            $i=0;
                            foreach($list as $res){
                            $i++;
                            echo '<tr><td>'.$i.'</td>
                                      <td>阿里云OSS/存储空间/'.$res['active'].'</td>
                                      <td>'.$res['name'].'</td>
                                      <td>'.($res['wan']==1?'<font color=green>已完成</font>':'<font color=red>未完成</font>').'</td>
                                      <td>'.$res['time'].'</td>
                                  </tr>';
                            }
                            ?>
                                      </tbody>
                                    </table>
                                  </div>

                            <div id="demo7"></div>
                            </footer>
                            <script src="/assets/layui/layui.js"></script>
                            <script>
                            layui.use(['laypage', 'layer'], function(){
                            var laypage = layui.laypage,
                            layer = layui.layer; 
                            laypage.render(
                              {
                                elem: 'demo7',
                                count: <?php echo $numrows?> ,
                                curr: <?php echo $page?> ,
                                limit:<?php echo $pagesize?>,
                                layout: ['count', 'prev', 'page', 'next', 'limit', 'refresh', 'skip'],
                                jump: function(obj,first){
                                  if(first!=true){
                                        var currentPage = obj.curr;
                                        window.location.href ="?bak&act=add&page="+currentPage+"&pagesize="+obj.limit;
                                   }
                               }
                            });
                            });
                            </script>
                    


                </div>
            </div>
        </div>
    </div>
    </section>
</section>
<?php }else{ ?>
      <section class="main-content-wrapper">
            <section id="main-content" class="animated fadeInUp">
                <div class="calendar-block" style="margin-bottom: 15px;">
                    <div class="cal1">
                     <h2 style="padding: 6px 12px;"><i class="fa fa-home"></i> 首页 / 备份配置</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title">备份信息配置</h3>
                                <div class="actions pull-right">
                                    <i class="fa fa-expand"></i>
                                </div>
                            </div>
                            <div class="panel-body">
                                <form class="form-horizontal form-border" id="form_bak" novalidate="novalidate">
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">备份功能</label>
                                        <div class="col-sm-6">
                                        <select class="form-control" name="bak_type">
                                            <option value="1" <?=$conf['bak_type']==1?"selected":""?>>开启</option>
                                            <option value="2" <?=$conf['bak_type']==2?"selected":""?>>关闭</option>
                                        </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">备份相隔时间</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" required="" name="bak_date" value="<?php echo $conf['bak_date'];?>" placeholder="10">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">阿里云OSSKeyId</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" required="" name="bak_url" value="<?php echo $conf['bak_url'];?>" placeholder="">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">阿里云OSSKeySecret</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" required="" name="bak_user" value="<?php echo $conf['bak_user'];?>" placeholder="">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">阿里云OSS访问域名</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" required="" name="bak_pwd" value="<?php echo $conf['bak_pwd'];?>" placeholder="">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">阿里云OSS存储目录</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" required="" name="bak_type2" value="<?php echo $conf['bak_type2'];?>" placeholder="">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="col-sm-offset-3 col-sm-6">
                                          <button type="button" onclick="bakc()" class="btn btn-primary">保存</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
    </section>
</section>
<?php } ?>