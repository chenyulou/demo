<?php 
if($islogin!=1){

    if($islogin!=2){

        exit('File not found.');
    
    }

}

 ?>
<section class="main-content-wrapper">
<section id="main-content" class="animated fadeInUp">
  <div class="calendar-block" style="margin-bottom: 15px;">
      <div class="cal1">
       <h2 style="padding: 6px 12px;"><i class="fa fa-home"></i> 首页 / 商户余额流向记录</h2>
      </div>
  </div>
<?php
$my=isset($_GET['my'])?$_GET['my']:null;
if($my=='search') {
  if($_GET['column']=='name'){
    $sql=" `{$_GET['column']}` like '%{$_GET['value']}%'";
  }else{
    $sql=" `{$_GET['column']}`='{$_GET['value']}'";
  }
  $numrows=$DB->query("SELECT count(*) from pay_money WHERE{$sql}")->fetchColumn();
  $con='包含 '.$_GET['value'].' 的共有 <b>'.$numrows.'</b> 条记录';
  $link='&my=search&column='.$_GET['column'].'&value='.$_GET['value'];
}else{
  $numrows=$DB->query("SELECT count(*) from pay_money WHERE 1")->fetchColumn();
  $sql=" 1";
}

$numrows=$DB->query("SELECT count(*) from pay_money WHERE{$sql}")->fetchColumn();
if(isset($_GET['pagesize'])){
$pagesize=$_GET['pagesize'];
}else{
$pagesize=10;
}
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);

$list=$DB->query("SELECT * FROM pay_money WHERE{$sql} order by id desc limit $offset,$pagesize")->fetchAll();

?>



    <div class="app-content-body ">
<div class="wrapper-md control">
<?php if(isset($msg)){?>
<div class="alert alert-info">
	<?php echo $msg?>
</div>
<?php }?>
<div class="row">
<div class="col-md-12">
<div class="panel panel-default">
<div class="panel-heading">流向记录
    <h3 class="panel-title"></h3>
    <div class="actions pull-right">
        <i class="fa fa-expand"></i>
    </div>
</div>

		<div class="panel-heading font-bold">

  <form action="" method="GET" class="form-inline"><input type="hidden" name="money" value="1"><input type="hidden" name="my" value="search">
  <div class="form-group">
    <select name="column" class="form-control">
    <option value="uid">商户ID</option>
    <option value="time">时间</option>
    </select>
  </div>
  <div class="form-group">
    <input type="text" class="form-control" name="value" placeholder="搜索内容">
  </div>
  <button type="submit" class="btn btn-primary">搜索</button>
</form>
<?php echo $con;?>
		</div>
		<div class="table-responsive">
        <table class="table table-striped">
          <thead><tr><th>排序</th><th>商户账号</th><th>流向类型</th><th>流向金额</th><th>流向后金额</th><th>流向时间</th></tr></thead>
          <tbody>
<?php
$i=0;
foreach($list as $res){
$i++;
echo '<tr><td>'.$i.'</td>
          <td>'.$res['uid'].'</td>
          <td>'.$res['name'].'</td>
          <td> <b>'.$res['money'].'</b></td>
          <td>￥ <b>'.$res['addmoney'].'</b></td>
          <td>'.$res['time'].'</td>
	  </tr>';
}
?>
		  </tbody>
        </table>
      </div>
<div id="demo7"></div>
</footer>
<script src="/assets/layui/layui.js"></script>
<script>
layui.use(['laypage', 'layer'], function(){
var laypage = layui.laypage,
layer = layui.layer; 
laypage.render(
  {
    elem: 'demo7',
    count: <?php echo $numrows?> ,
    curr: <?php echo $page?> ,
    limit:<?php echo $pagesize?>,
    layout: ['count', 'prev', 'page', 'next', 'limit', 'refresh', 'skip'],
    jump: function(obj,first){
      if(first!=true){
            var currentPage = obj.curr;
            window.location.href ="?money&page="+currentPage+"&pagesize="+obj.limit+"<?php echo $link;?>";
       }
   }
});
});
</script>
	</div>
</div>
    </div>
  </div>
</section>
</section>