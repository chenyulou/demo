<?php 
if($islogin!=1){

    if($islogin!=2){

        exit('File not found.');
    
    }

}
 ?>
<section class="main-content-wrapper">
<section id="main-content" class="animated fadeInUp">
<div class="calendar-block" style="margin-bottom: 15px;">
      <div class="cal1">
       <h2 style="padding: 6px 12px;"><i class="fa fa-home"></i> 首页 / 使用帮助</h2>
      </div>
  </div>
<div class="row">
<div class="col-md-12">
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title">使用帮助</h3>
            <div class="actions pull-right">
            <i class="fa fa-expand"></i>
            </div>
        </div>
        <div class="panel-body">

            <div class="panel-group accordion" id="accordion">

                 <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title">
                  <a class="collapsed" data-toggle="collapse" data-parent="#alioss" href="#alioss" aria-expanded="false">
                    数据库备份到阿里云OSS说明
                  </a>
                </h4>
                            </div>
                            <div id="alioss" class="panel-collapse collapse" aria-expanded="false">
                                <div class="panel-body">
                                   1.阿里云OSS对象存储地址：https://oss.console.aliyun.com/<br>
                                   2.开通购买资源后创建一个存储空间<br>
                                   3.阿里云OSS访问域名:在存储空间使用 看到 EndPoint（地域节点）这里选择第一个，在【备份配置】里面填写的时候需要添加上http://
                                </div>
                            </div>
                        </div>

                 <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title">
                  <a class="collapsed" data-toggle="collapse" data-parent="#czsm" href="#czsm" aria-expanded="false">
                    结算操作说明
                  </a>
                </h4>
                            </div>
                            <div id="czsm" class="panel-collapse collapse" aria-expanded="false">
                                <div class="panel-body">
                                   结算操作后下载文件没有内容是用户不符合结算要求，用户必须设置有名字，结算账号，余额必须大于最小结算金额
                                </div>
                            </div>
                        </div>


                <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title">
                  <a class="collapsed" data-toggle="collapse" data-parent="#cssm" href="#cssm" aria-expanded="false">
                    结算次数说明
                  </a>
                </h4>
                            </div>
                            <div id="cssm" class="panel-collapse collapse" aria-expanded="false">
                                <div class="panel-body">
                                   结算次数是指商户手动申请的次数，若超过该设置则不允许提交申请，在后台处理完后次数会添加回给商户
                                </div>
                            </div>
                        </div>

                <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title">
                  <a class="collapsed" data-toggle="collapse" data-parent="#mlxg" href="#mlxg" aria-expanded="false">
                    后台目录修改说明
                  </a>
                </h4>
                            </div>
                            <div id="mlxg" class="panel-collapse collapse" aria-expanded="false">
                                <div class="panel-body">
                                   1.目录一定要与保存数据库的一致<br>
                                   2.修改提示失败的肯定是数据库保存的目录不一致<br>
                                   3.若不一致更新程序时候一定会更新失败<br>
                                   建议不要直接修改目录
                                </div>
                            </div>
                        </div>



                 <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title">
                  <a class="collapsed" data-toggle="collapse" data-parent="#userqy" href="#userqy" aria-expanded="false">
                    彩虹原版数据迁移说明
                  </a>
                </h4>
                            </div>
                            <div id="userqy" class="panel-collapse collapse" aria-expanded="false">
                                <div class="panel-body">
                                    1，用户数据迁移，将该程序的数据库pay_user表删除，然后导入包含数据的彩虹原版数据库pay_user到该程序即可，部分二开程序的数据库如果没有修改过也可以迁移过来。<br>
                                    2，订单数据迁移，方法跟用户数据迁移的一样。
                                </div>
                            </div>
                        </div>

                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title">
                  <a class="collapsed" data-toggle="collapse" data-parent="#rzsm" href="#rzsm" aria-expanded="false">
                    商户认证说明
                  </a>
                </h4>
                            </div>
                            <div id="rzsm" class="panel-collapse collapse" aria-expanded="false">
                                <div class="panel-body">
                                    如果商户认证失败次数已达想修改用户认证次数请在数据库中修改，pay_user中的字段sj_rz,sf_rz,yh_rz这三个修改1为0就是3次机会，2是2次机会，3是1次机会，超过3则是已经超出认证次数，不能修改为1，是就代表成功！
                                </div>
                            </div>
                        </div>


                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
          <a class="collapsed" data-toggle="collapse" data-parent="#yhjk" href="#yhjk" aria-expanded="false">
            银行卡认证接口地址
          </a>
        </h4>
                    </div>
                    <div id="yhjk" class="panel-collapse collapse" aria-expanded="false">
                        <div class="panel-body">
                            <a href="https://market.aliyun.com/products/57000002/cmapi012483.html#sku=yuncode648300007">购买地址：https://market.aliyun.com/products/57000002/cmapi012483.html#sku=yuncode648300007</a>
                        </div>
                    </div>
                </div>


        <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
          <a class="collapsed" data-toggle="collapse" data-parent="#sjjk" href="#sjjk" aria-expanded="false">
            手机认证接口地址
          </a>
        </h4>
                    </div>
                    <div id="sjjk" class="panel-collapse collapse" aria-expanded="false">
                        <div class="panel-body">
                            <a href="https://market.aliyun.com/products/57000002/cmapi033611.html?spm=5176.2020520132.101.9.6ade7218jyonGo#sku=yuncode2761100001">购买地址：https://market.aliyun.com/products/57000002/cmapi033611.html?spm=5176.2020520132.101.9.6ade7218jyonGo#sku=yuncode2761100001</a>
                        </div>
                    </div>
                </div>

                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
          <a class="collapsed" data-toggle="collapse" data-parent="#shauifsm" href="#shauifsm" aria-expanded="false">
            支付率费使用说明
          </a>
        </h4>
                    </div>
                    <div id="shauifsm" class="panel-collapse collapse" aria-expanded="false">
                        <div class="panel-body">
                            默认率费设置是0.03也就是3%的率费时候，接口没有设置，商户也没有设置才会走默认的 优先级别： 商户->接口-默认  商户是第一 商户设置了则接口默认都不会走 不给商户设置率费请留空 率费设置范围 0.0001~1， 1等于100%
                        </div>
                    </div>
                </div>


                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
          <a class="collapsed" data-toggle="collapse" data-parent="#mbcj" href="#mbcj" aria-expanded="false">
            短信模板创建说明
          </a>
        </h4>
                    </div>
                    <div id="mbcj" class="panel-collapse collapse" aria-expanded="false">
                        <div class="panel-body">
                            创建模板时请先保存阿里云AppCode才能创建，签名就是短信的名称 例如：【海弟商务】 你的验证码是.... 验证码使用[code]代替，例如：你的验证码是[code]，具体信息在创建模板页面有提示 内容可直接写 你的验证码是[code]
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
          <a class="collapsed" data-toggle="collapse" data-parent="#yuecz" href="#yuecz" aria-expanded="false">
            商户余额充值说明
          </a>
        </h4>
                    </div>
                    <div id="yuecz" class="panel-collapse collapse" aria-expanded="false">
                        <div class="panel-body">
                            充值前提要在基本配置 设置好收款ID 把该ID的率费调为0 不然商户充值会扣掉率费
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" class="collapsed" aria-expanded="false">
            短信购买地址
          </a>
        </h4>
                    </div>
                    <div id="collapseOne" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                        <div class="panel-body">
                            <a href="https://market.aliyun.com/products/57126001/cmapi017136.html?spm=5176.2020520132.101.27.19177218wRL6Ef#sku=yuncode1113600000">购买地址：https://market.aliyun.com/products/57126001/cmapi017136.html?spm=5176.2020520132.101.27.19177218wRL6Ef#sku=yuncode1113600000</a>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
          <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false">
            身份实名认证接口地址
          </a>
        </h4>
                    </div>
                    <div id="collapseTwo" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                        <div class="panel-body">
                            <a href="https://market.aliyun.com/products/57000002/cmapi033894.html?spm=5176.2020520132.101.3.19177218wRL6Ef#sku=yuncode2789400001">购买地址：https://market.aliyun.com/products/57000002/cmapi033894.html?spm=5176.2020520132.101.3.19177218wRL6Ef#sku=yuncode2789400001</a>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
          <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false">
            自动更新使用说明
          </a>
        </h4>
                    </div>
                    <div id="collapseThree" class="panel-collapse collapse" aria-expanded="false">
                        <div class="panel-body">
                            自动更新需要进行监控，接口地址 域名/api.php?act=downAndunZip 监控频率最好在一分钟！
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
  </div>
</div>
</section>
</section>