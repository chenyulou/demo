<?php 
if($islogin!=1){

    if($islogin!=2){

        exit('File not found.');
    
    }

}



 ?>
        <!--main content start-->
        <section class="main-content-wrapper">
            <section id="main-content" class="animated fadeInUp">

				<div class="calendar-block" style="margin-bottom: 15px;">
				    <div class="cal1">
				     <h2 style="padding: 6px 12px;"><i class="fa fa-home"></i> 首页</h2>
				    </div>
				</div>
                <div class="row">
                    <div class="col-md-12 col-lg-6">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="panel panel-solid-success widget-mini">
                                    <div class="panel-body">
                                        <i class="icon-bar-chart" style="top: 40%;font-size: 1.5em;"></i>
                                        <span class="total text-center" style="text-align: right;"><?php echo round($sum,2);?></span>
                                        <span class="title text-center" style="text-align: right;">总收入</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="panel widget-mini">
                                    <div class="panel-body">
                                        <i class="icon-calendar" style="top: 40%;font-size: 1.5em;"></i>
                                        <span class="total text-center" style="text-align: right;"><?php echo round($jt_dd,2);?></span>
                                        <span class="title text-center" style="text-align: right;">今日订单</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="panel widget-mini">
                                    <div class="panel-body">
                                        <i class="icon-shuffle" style="top: 40%;font-size: 1.5em;"></i>
                                        <span class="total text-center" style="text-align: right;"><?php echo round($today,2);?></span>
                                        <span class="title text-center" style="text-align: right;">今日收入</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="panel panel-solid-info widget-mini">
                                    <div class="panel-body">
                                        <i class="icon-user" style="top: 40%;font-size: 1.5em;"></i>
                                        <span class="total text-center" style="text-align: right;"><?php echo round($count2,2);?></span>
                                        <span class="title text-center" style="text-align: right;">商户总数</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
                        <div class="panel panel-default browser-chart">
                            <div class="panel-heading">
                                <h3 class="panel-title">今天收入</h3>
                                <div class="actions pull-right" style="font-size: 0.813em;">
                                    <i class="fa fa-circle success-color" style="color: #27b6af;"></i> 微信  
                                    <i class="fa fa-circle warning-color" style="color: #edce8c;"></i> QQ  
                                    <i class="fa fa-circle info-color" style="color: #1f7bb6;"></i> 支付宝
                                </div>
                            </div>
                            <div class="panel-body" style="margin-bottom: 0px;">
                                <div class="row">
                                    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                        <ul>
                                            <li><i class="fa fa-circle success-color"></i> <?php echo round($jt_wxpay,2);?> 元</li>
                                            <li><i class="fa fa-circle warning-color"></i> <?php echo round($jt_qqpay,2);?> 元</li>
                                            <li><i class="fa fa-circle info-color"></i> <?php echo round($jt_alipay,2);?> 元</li>
                                        </ul>
                                    </div>
                                    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                        <div id="doughnut-canvas-holder">
                                            <canvas id="doughnut-chart-area" width="137" height="137"></canvas>
                                            <!-- <canvas id="pay_canvas" width="137" height="137"></canvas> -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title">收入对比</h3>
                                    <div class="actions pull-right" style="font-size: 0.813em;">
                                    	<i class="fa fa-circle success-color" style="color: #27b6af;"></i> 今天
                                        <i class="fa fa-circle" style="color: #999999;"></i> 昨天
                                    </div>
                            </div>
                                                                             

                            <div class="panel-body widget-gauge">
                                <canvas width="160" height="100" id="gauge" class=""></canvas>
                                <div class="goal-wrapper">
                                    <span class="gauge-value pull-left">$</span>
                                    <span id="gauge-text" class="gauge-value pull-left"><?php echo round($jt_sum,2);?></span>
                                    <span id="goal-text" class="goal-value pull-right">$<?php echo round($zt_sum,2);?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                  <div class="col-md-6">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title">订单/收入/注册统计图</h3>
                                <div class="actions pull-right">
                                    <i class="fa fa-expand"></i>
                                </div>
                            </div>
                            <div id="center-zhexian" style="width:100%;height:300px"></div>
                        </div>
                    </div>

                  <div class="col-md-6">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title">通道统计图</h3>
                                <div class="actions pull-right">
                                    <i class="fa fa-expand"></i>
                                </div>
                            </div>
                            <div id="center-zhexian-ton" style="width:100%;height:300px"></div>
                        </div>
                    </div>
                </div>



                <div class="row">
                  <div class="col-md-6">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title">商户收入排行</h3>
                                <div class="actions pull-right">
                                    <i class="fa fa-expand"></i>
                                </div>
                            </div>
                            <div class="panel-body" style="padding: 0px;">
                                <table class="table" style="margin-bottom: 0px;">
                                    <thead>
                                    <tr>
                                        <th>排序</th>
                                        <th>用户账号</th>
                                        <th>用户金额</th>
                                        <th>今日收入</th>
                                        <th>昨日收入</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $i=0;
                                        $rs=$DB->query("SELECT * FROM `pay_user` ORDER BY `money` DESC limit 5");
                                        while($res = $rs->fetch())
                                        {
                                        $i++;
                                        $order_lastday=$DB->query("SELECT sum(money) from pay_order where pid='{$res['id']}' and status = 1 and addtime >= '".$zt."' and addtime < '".$jt."'")->fetchColumn();
                                        $order_today=$DB->query("SELECT sum(money) from pay_order where pid='{$res['id']}' and status = 1 and addtime >= '".$jt."' and addtime < '".$mt."'")->fetchColumn();
                                    echo '
                                        <tr>
                                            <td>'.$i.'</td>
                                            <td>'.$res['user'].'</td>
                                            <td>'.$res['money'].' 元</td>
                                            <td>'.round($order_today,2).' 元</td>
                                            <td>'.round($order_lastday,2).' 元</td>
                                        </tr>';
                                    }?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>




                    <div class="col-md-6">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title">系统信息</h3>
                                <div class="actions pull-right">
                                    <i class="fa fa-expand"></i>
                                </div>
                            </div>
                            <div class="panel-body" style="padding: 0px;">
                                <ul class="list-group" style="margin-bottom: 0px;">
									<li class="list-group-item" style="border: 0px solid #ddd;">
										<b>PHP 版本：</b><?php echo phpversion() ?>
										<?php if(ini_get('safe_mode')) { echo '线程安全'; } else { echo '非线程安全'; } ?>
									</li>
									<li class="list-group-item" style="border: 0px solid #ddd;">
										<b>MySQL 版本：</b><?php echo $mysqlversion[0] ?>
									</li>
									
									
									<li class="list-group-item" style="border: 0px solid #ddd;">
										<b>服务器软件：</b><?php echo $_SERVER['SERVER_SOFTWARE'] ?>
									</li>
                                    <li class="list-group-item" style="border: 0px solid #ddd;">
                                        <b>POST许可：</b><?php echo ini_get('post_max_size'); ?>
                                    </li>
									<li class="list-group-item" style="border: 0px solid #ddd;">
                                        <b>程序版本：</b>v<?php echo $vin;?>
                                    </li>
									<li class="list-group-item" style="border: 0px solid #ddd;">
										<b>程序更新时间：</b><?php echo $tmie; ?>
									</li>
								</ul>
                            </div>
                        </div>
                    </div>
                </div>

                </div>
            </section>
        </section>
        <!--main content end-->
    </section>
