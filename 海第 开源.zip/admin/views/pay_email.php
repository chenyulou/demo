<?php 
if($islogin!=1){

    if($islogin!=2){

        exit('File not found.');
    
    }

}

 ?>
      <section class="main-content-wrapper">
            <section id="main-content" class="animated fadeInUp">
                <?php if(isset($_GET['jimail'])){?>
             <div class="calendar-block" style="margin-bottom: 15px;">
                    <div class="cal1">
                     <h2 style="padding: 6px 12px;"><i class="fa fa-home"></i> 首页 / 邮件发送记录</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title">邮件发送记录</h3>
                                <div class="actions pull-right">
                                    <i class="fa fa-expand"></i>
                                </div>
                            </div>
                          <div class="table-responsive">
                            <table class="table table-striped">
                              <thead><tr><th>排序</th><th>发送对象</th><th>对象Email</th><th>发送标题</th><th>发送时间</th><th>操作</th></tr></thead>
                              <tbody>
                                <?php
                                if($my=='search') {
                                $sql=" `{$_GET['column']}`='{$_GET['value']}'";
                                $numrows=$DB->query("SELECT * from pay_email WHERE{$sql}")->rowCount();
                                }else{
                                $numrows=$DB->query("SELECT * from pay_email WHERE 1")->rowCount();
                                $sql=" 1";
                                }
                                $pagesize=10;
                                $pages=intval($numrows/$pagesize);
                                if ($numrows%$pagesize)
                                {
                                $pages++;
                                }
                                if (isset($_GET['page'])){
                                $page=intval($_GET['page']);
                                }
                                else{
                                $page=1;
                                }
                                $offset=$pagesize*($page - 1);
                                $i=0;
                                $rs=$DB->query("SELECT * FROM pay_email WHERE{$sql} order by id desc limit $offset,$pagesize");
                                while($res = $rs->fetch())
                                {
                                $i++;
                                echo '<tr>
                                <td><b>'.$i.'</b></td>
                                <td>'.($res['ems']==1?'单独商户':'全部商户').'</td> 
                                <td>'.$res['uid'].'</td>
                                <td>'.$res['min'].'</td>
                                <td>'.$res['time'].'</td>
                                <td><a class="btn btn-xs btn-danger" onclick="youdei('.$res['id'].')">删除</a></td>
                                </tr>';
                                }
                                ?>
                        </tbody>
                        </table>
                       </div>
                      </div>
                    </div>
                    </div>
                </div>
                <?php }else if(isset($_GET['mail'])){?>
                <div class="calendar-block" style="margin-bottom: 15px;">
                    <div class="cal1">
                     <h2 style="padding: 6px 12px;"><i class="fa fa-home"></i> 首页 / 邮件发送</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title">邮件发送</h3>
                                <div class="actions pull-right">
                                    <i class="fa fa-expand"></i>
                                </div>
                            </div>
                            <div class="panel-body">
                                <form class="form-horizontal form-border" id="form_fsmail" novalidate="novalidate">
                                     <div class="form-group">
                                        <label class="col-sm-3 control-label">发送对象</label>
                                        <div class="col-sm-6">
                                        <select class="form-control" name="type2">
                                            <option value="1">全部商户</option>
                                            <option value="2">单独商户</option>
                                        </select>
                                        </div>
                                    </div>
                                    <div id="email" style="display:none;">
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">邮箱账号</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" name="email" required="" placeholder="haidism@qq.com">
                                        </div>
                                    </div>
                                </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">邮件标题</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" name="min" required="" placeholder="通知！">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">内容</label>
                                        <div class="col-sm-6">
                                            <textarea class="form-control" name="name" rows="12" placeholder="请输入内容"></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-offset-3 col-sm-6">
                                            <button type="button" onclick="fsmail()" class="btn btn-primary">发送</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <?php }else{?>
            	<div class="calendar-block" style="margin-bottom: 15px;">
				    <div class="cal1">
				     <h2 style="padding: 6px 12px;"><i class="fa fa-home"></i> 首页 / 邮箱配置</h2>
				    </div>
				</div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title">邮箱信息修改</h3>
                                <div class="actions pull-right">
                                    <i class="fa fa-expand"></i>
                                </div>
                            </div>
                            <div class="panel-body">
                                <form class="form-horizontal form-border" id="form_mail" novalidate="novalidate">
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">SMTP地址</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" name="mail_smtp" value="<?php echo $conf['mail_smtp'];?>" required="" placeholder="smtp.qq.com">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">SMTP端口</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" name="mail_port" value="<?php echo $conf['mail_port'];?>" required="" placeholder="465">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">邮箱账户</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" required="" name="mail_name" value="<?php echo $conf['mail_name'];?>" placeholder="haidism@qq.com">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">邮箱密码(授权码)</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" required="" name="mail_pwd" value="<?php echo $conf['mail_pwd'];?>" placeholder="123456">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-offset-3 col-sm-6">
                                            <button type="button" onclick="mail()" class="btn btn-primary">保存</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php }?>
    </section>
</section>
