<?php
header("content-Type: text/html; charset=Utf-8"); 
$batch=$_GET['batch'];
$allmoney=$_GET['allmoney'];
$type=$_GET['type'];
$data='';
if ($type=='qqpay') {
	$rs=$DB->query("SELECT * from pay_settle where batch='$batch' and type=3 order by type asc,id asc");
}elseif ($type=='wxpay') {
	$rs=$DB->query("SELECT * from pay_settle where batch='$batch' and type=2 order by type asc,id asc");
}elseif ($type=='alipay') {
	$rs=$DB->query("SELECT * from pay_settle where batch='$batch' and type=1 order by type asc,id asc");
}elseif ($type=='bank') {
	$rs=$DB->query("SELECT * from pay_settle where batch='$batch' and type=4 order by type asc,id asc");
}elseif ($type=='all') {
	$rs=$DB->query("SELECT * from pay_settle where batch='$batch' order by type asc,id asc");
}else{
   exit("<script language='javascript'>alert('抱歉！系统出错。');window.location.href='?settle';</script>");
}

$i=0;
while($row = $rs->fetch())
{
	$i++;
	$data.=$i.','.$row['batch'].','.display_type($row['type']).','.$row['account'].','.$row['username'].','.$row['money'].','.'易支付结算 '."\r\n";
}

$date=date("Ymd");
$file="排序,商户流水号,收款方式,收款账号,收款人姓名,付款金额（元）,付款理由\r\n";
$file.=$data;
if ($data=='') {
	exit("<script language='javascript'>alert('该类型的数据为空，所以不建议下载！');window.location.href='?settle';</script>");
}
$file_name='pay_'.$type.'_'.date("YmdHis").'.csv';
$file_size=strlen($file);
header("Content-Description: File Transfer");
header("Content-Type:application/force-download");
header("Content-Length: {$file_size}");
header("Content-Disposition:attachment; filename={$file_name}");
echo $file;
?>
