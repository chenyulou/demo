<?php 
if($islogin!=1){

    if($islogin!=2){

        exit('File not found.');
    
    }

}
 ?>

<?php if (isset($_GET['close'])) {?>
<section class="main-content-wrapper">
<section id="main-content" class="animated fadeInUp">
<div class="calendar-block" style="margin-bottom: 15px;">
      <div class="cal1">
       <h2 style="padding: 6px 12px;"><i class="fa fa-home"></i> 首页 / 公告发布</h2>
      </div>
  </div>
<div class="row">
<div class="col-md-12">

<div class="panel panel-default">
<div class="panel-heading">公告发布
    <h3 class="panel-title"></h3>
    <div class="actions pull-right">
        <i class="fa fa-expand"></i>
    </div>
</div>
<div class="panel-body">

<form class="form-horizontal form-border" id="form_close" novalidate="novalidate">
<div class="form-group">
    <label class="col-sm-3 control-label">公告标题</label>
    <div class="col-sm-6">
        <input type="text" class="form-control" name="title" value="" required="" placeholder="海弟易支付">
    </div>
</div>
<div class="form-group">
    <label class="col-sm-3 control-label">公告类型</label>
    <div class="col-sm-6">
    <select class="form-control" name="type">
        <option value="1">结算</option>
        <option value="2">系统</option>
        <option value="3">安全</option>
        <option value="4">紧急</option>
    </select>
    </div>
</div>

<div class="form-group">
  <label class="col-sm-3 control-label">公告内容</label>
  <div class="col-sm-6">
      <textarea class="form-control" name="name" rows="12" placeholder="Textarea"></textarea>
  </div>
</div>

<div class="form-group">
    <div class="col-sm-offset-3 col-sm-6">
        <button type="button" onclick="closes()" class="btn btn-primary">发布</button>
    </div>
</div>
</form>

</div>
</div>
</div>
</div>
</section>
</section>
<?php }else{?>
<section class="main-content-wrapper">
<section id="main-content" class="animated fadeInUp">
<div class="calendar-block" style="margin-bottom: 15px;">
      <div class="cal1">
       <h2 style="padding: 6px 12px;"><i class="fa fa-home"></i> 首页 / 公告列表</h2>
      </div>
  </div>
<div class="row">
<div class="col-md-12">


<?php if (isset($_GET['add'])) {?>

<?php

$id=intval($_GET['id']);


$row= $DB->query("SELECT * FROM pay_notice WHERE id='{$id}' limit 1")->fetch();

?>

<div class="panel panel-default">
<div class="panel-heading">公告查看
    <h3 class="panel-title"></h3>
    <div class="actions pull-right" style="width: 110px;">
        <a href="javascript:history.back(-1)"><button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#dxmb">返回上级</button></a>
    </div>
    <div class="actions pull-right">
        <i class="fa fa-expand"></i>
    </div>
</div>
<div class="panel-body">

<form class="form-horizontal form-border" id="form_down" novalidate="novalidate">
<div class="form-group">
    <label class="col-sm-3 control-label">公告标题</label>
    <div class="col-sm-6">
        <input type="text" class="form-control" name="title" value="<?php echo $row['title']?>" required="" placeholder="海弟易支付">
    </div>
</div>
<div class="form-group">
    <label class="col-sm-3 control-label">公告类型</label>
    <div class="col-sm-6">
    <select class="form-control" name="type" disabled="disabled">
        <option value="1" <?=$row['type']==1?"selected":""?>>结算</option>
        <option value="2" <?=$row['type']==2?"selected":""?>>系统</option>
        <option value="3" <?=$row['type']==3?"selected":""?>>安全</option>
        <option value="4" <?=$row['type']==4?"selected":""?>>紧急</option>
    </select>
    </div>
</div>

<div class="form-group">
  <label class="col-sm-3 control-label">公告内容</label>
  <div class="col-sm-6">
      <textarea class="form-control" name="name" rows="12" placeholder="Textarea"><?php echo $row['name'];?></textarea>
  </div>
</div>


<div class="form-group">
    <label class="col-sm-3 control-label">发布时间</label>
    <div class="col-sm-6">
        <input type="text" class="form-control" required="" name="time" value="<?php echo $row['time'];?>" disabled="disabled">
    </div>
</div>

<input type="hidden" name="id" value="<?php echo $row['id'];?>">

<div class="form-group">
    <div class="col-sm-offset-3 col-sm-6">
        <button type="button" onclick="add_down()" class="btn btn-primary">保存</button>
    </div>
</div>
</form>

</div>
</div>
<?php }else{?>


<div class="panel panel-default">
<div class="panel-heading">公告列表
    <h3 class="panel-title"></h3>
    <div class="actions pull-right">
        <i class="fa fa-expand"></i>
    </div>
</div>
<div class="panel-body">
<?php

$my=isset($_GET['my'])?$_GET['my']:null;

echo '<form action="" method="GET" class="form-inline"><input type="hidden" name="my" value="search"><input type="hidden" name="down" value="search">
  <div class="form-group">
	<select name="column" class="form-control">
     <option value="title">公告标题</option>
  </select>
  </div>
  <div class="form-group">
    <input type="text" class="form-control" name="value" placeholder="搜索内容">
  </div>
  <button type="submit" class="btn btn-primary">搜索</button>
</form></div>';

if($my=='search') {
	$sql=" `{$_GET['column']}`='{$_GET['value']}'";
	$numrows=$DB->query("SELECT * from pay_notice WHERE{$sql}")->rowCount();
	$con='包含 '.$_GET['value'].' 的共有 <b>'.$numrows.'</b> 条记录';
	$link='&my=search&column='.$_GET['column'].'&value='.$_GET['value'];
}else{
	$numrows=$DB->query("SELECT * from pay_notice WHERE 1")->rowCount();
	$sql=" 1";
}
echo $con;
?>
      <div class="table-responsive">
        <table class="table table-striped">
          <thead><tr><th>排序</th><th>公告标题</th><th>公告类型</th><th>发布时间</th><th>操作</th></tr></thead>
          <tbody>
<?php
if(isset($_GET['pagesize'])){
$pagesize=$_GET['pagesize'];
}else{
$pagesize=10;
}
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);
$i=0;
$rs=$DB->query("SELECT * FROM pay_notice WHERE{$sql} order by id desc limit $offset,$pagesize");
while($res = $rs->fetch())
{
$i++;
echo '<tr>
<td><b>'.$i.'</b></td>
<td>'.$res['title'].'</td>
<td>'.disdown_type($res['type']).'</td>
<td>'.$res['time'].'</td>
<td><a href="?down&add&id='.$res['id'].'" class="btn btn-xs btn-info">查看</a>&nbsp;
<a href="#" class="btn btn-xs btn-danger" onclick="die_down('.$res['id'].')">删除</a>
</tr>';
}
?>
          </tbody>
        </table>
      </div>
<div id="demo7"></div>
</footer>
<script src="/assets/layui/layui.js"></script>
<script>
layui.use(['laypage', 'layer'], function(){
var laypage = layui.laypage,
layer = layui.layer; 
laypage.render(
  {
    elem: 'demo7',
    count: <?php echo $numrows?> ,
    curr: <?php echo $page?> ,
    limit:<?php echo $pagesize?>,
    layout: ['count', 'prev', 'page', 'next', 'limit', 'refresh', 'skip'],
    jump: function(obj,first){
      if(first!=true){
            var currentPage = obj.curr;
            window.location.href ="?down&page="+currentPage+"&pagesize="+obj.limit+"<?php echo $link;?>";
       }
   }
});
});
</script>
    </div>
  </div>
<?php }?>
</div>
</div>
</section>
</section>
<?php }?>
