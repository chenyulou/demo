<?php 
if($islogin!=1){

    if($islogin!=2){

        exit('File not found.');
    
    }

}

 ?>

<section class="main-content-wrapper">
<section id="main-content" class="animated fadeInUp">
<div class="calendar-block" style="margin-bottom: 15px;">
    <div class="cal1">
     <h2 style="padding: 6px 12px;"><i class="fa fa-home"></i> 首页 / 结算操作</h2>
    </div>
</div>
<div class="row">
<div class="col-md-12">
<div class="panel panel-default">
<div class="panel-heading">结算操作
    <h3 class="panel-title"></h3>
    <div class="actions pull-right" style="width: 110px;">
          <button type="button" class="btn btn-info btn-xs creat">立即生成列表</button>
     </div>
    <div class="actions pull-right">
        <i class="fa fa-expand"></i>
    </div>
</div>
	<div class="table-responsive">
		<table class="table table-striped">
          <thead><tr><th>排序</th><th>批次号</th><th>总金额</th><th>生成时间</th><th>类型统计</th><th>状态</th><th>操作</th><th>CSV</th></tr></thead>
          <tbody>
			<?php
      $numrows=$DB->query("SELECT count(*) from pay_batch WHERE 1")->fetchColumn();
      if(isset($_GET['pagesize'])){
      $pagesize=$_GET['pagesize'];
      }else{
      $pagesize=10;
      }
      $pages=intval($numrows/$pagesize);
      if ($numrows%$pagesize)
      {
       $pages++;
       }
      if (isset($_GET['page'])){
      $page=intval($_GET['page']);
      }
      else{
      $page=1;
      }
      $offset=$pagesize*($page - 1);
			$i=0;
			$rs=$DB->query("SELECT * FROM pay_batch WHERE 1 order by time desc limit $offset,$pagesize");
			while($res = $rs->fetch())
			{
			$i++;
			echo '<tr>
			<td>'.$i.'</td>
			<td><b>'.$res['batch'].'</b></td>
			<td>'.$res['allmoney'].'</td>
			<td>'.$res['time'].'</td>
			<td>QQ('.batchTotal($res['batch'],'3').':'.batchTotals($res['batch'],'3').')&nbsp;&nbsp; 微信('.batchTotal($res['batch'],'2').':'.batchTotals($res['batch'],'2').') &nbsp;&nbsp;支付宝('.batchTotal($res['batch'],'1').':'.batchTotals($res['batch'],'1').') &nbsp;&nbsp;银行('.batchTotal($res['batch'],'4').':'.batchTotals($res['batch'],'4').')</td>
			<td>'.($res['status']==1?'<font color=green>已完成</font>':'<font color=red>未完成</font>').'</td>

			<td>'.($res['status']==1?'<a href="#" class="btn btn-xs btn-info transfer" batch="'.$res['batch'].'" style="background-color: #edce8c;">转账</a>':'
				<a href="#" class="btn btn-xs btn-info jies" batch="'.$res['batch'].'">处理</a>').'</td>
			<td>
			<a href="#" batch='.$res['batch'].' allmoney='.$res['allmoney'].'" class="download"><i class="icon-arrow-down"></i></a>
			</td>
			</tr>';
			}
			?>
		  </tbody>
        </table>
    </div>
    <div id="demo7"></div>
    </footer>
    <script src="/assets/layui/layui.js"></script>
    <script>
    layui.use(['laypage', 'layer'], function(){
    var laypage = layui.laypage,
    layer = layui.layer; 
    laypage.render(
      {
        elem: 'demo7',
        count: <?php echo $numrows?> ,
        curr: <?php echo $page?> ,
        limit:<?php echo $pagesize?>,
        layout: ['count', 'prev', 'page', 'next', 'limit', 'refresh', 'skip'],
        jump: function(obj,first){
          if(first!=true){
                var currentPage = obj.curr;
                window.location.href ="?settle&page="+currentPage+"&pagesize="+obj.limit+"<?php echo $link;?>";
           }
       }
    });
    });
    </script>

        </div>
		<div class="panel-footer">
          <span class="fa fa-exclamation-circle"></span> 结算提示：类型统计中()里面的数据解释【 第一个数值是有多少用户使用该类型结算，第二个则是已结算了多少个用户 】<br/>
		  <span class="fa fa-exclamation-circle"></span> 转账提示：结算之前请先确认【处理】，使用在线转账工具请在【系统配置->结算配置->右上角的转账接口】处配置好相关信息,若不用工具转账请【点击转账->提示页选择不操作转账仅处理】，当你手动转账完成即可在里面进行修改一个结算状态。
        </div>
      </div>
    </div>
  </div>
</section>
</section>

<!-- Form Modal -->
<div class="modal fade" id="transfer" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
             <h4 class="modal-title" id="myModalLabel"><i class="icon-shuffle"></i>&nbsp;转账提示</h4>
              </div>
               <div class="modal-body">
               <h4>请选择转账类型</h4><hr/>
				<div id="transfer-name"></div>
              </div>
        </div>
    </div>
</div>
<!-- End Form Modal -->

<!-- Form Modal -->
<div class="modal fade" id="download" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
             <h4 class="modal-title" id="myModalLabel"><i class="icon-arrow-down"></i>&nbsp;CSV下载提示</h4>
              </div>
               <div class="modal-body">
               <h4>请根据自己的需求下载CSV类型</h4><hr/>
				<div id="download-name"></div>
              </div>
        </div>
    </div>
</div>
<!-- End Form Modal -->