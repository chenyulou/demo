<?php 
if($islogin!=1){

    if($islogin!=2){

        exit('File not found.');
    
    }

}

 ?>
<section class="main-content-wrapper">
<section id="main-content" class="animated fadeInUp">
    <div class="calendar-block" style="margin-bottom: 15px;">
    <div class="cal1">
     <h2 style="padding: 6px 12px;"><i class="fa fa-home"></i> 首页 / 更新记录</h2>
    </div>
</div>

<div class="row">
<div class="col-md-2 col-sm-12" id="compose-wrapper">
<div class="panel">
    <aside class="panel-body">
        <a href="#" class="btn btn-primary btn-block Update">检查更新</a>
        <ul class="nav nav-pills nav-stacked compose-nav">
            <li class="active">
                <a>
                 <i class="fa fa-inbox"></i> 当前版本：V 4.03
                  <span class="label label-primary label-circle pull-right inbox-notification" style="background-color: #b91d1a;">新</span>
                </a>
            </li>
            <li>
                <a> <i class="fa fa-star-o"></i> 更新次数：102 次
                </a>
            </li>
            <li>
                <a> <i class="fa fa-history"></i> 开发时间：2017/9</a>
            </li>
            <li>
                <a> <i class="fa fa-bookmark-o"></i> 开发者：海弟君</a>
            </li>
            <li>
                <a> <i class="fa fa-question-circle"></i> 个人开发必有BUG哦！</a>
            </li>
        </ul>
    </aside>
</div>
</div>
<div class="col-md-10 col-sm-12" id="compose-wrapper">
<section class="panel  timeline-post">
    <div class="panel-body">
        <ul>
            <li>
             <div class="date">
                    <span>11/25</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 4.03</h4>
                <p>
                更新内容：<br>
                1.修复已知BUG
                </p>
            </li>
            <li>
             <div class="date">
                    <span>11/25</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 4.02</h4>
                <p>
                更新内容：<br>
                1.修复已知BUG
                </p>
            </li>
            <li>
             <div class="date">
                    <span>11/24</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 4.01</h4>
                <p>
                更新内容：<br>
                1.修复已知BUG
                </p>
            </li>
            <li>
             <div class="date">
                    <span>11/23</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 4.0</h4>
                <p>
                更新内容：<br>
                1.优化后台UI<br>
                2.优化商户中心UI<br>
                3.优化支付收银页UI<br>
                4.支持通道转换支付(用户无法使用该通道时可更换其他支付方式)<br>
                5.修正商户找回密码操作<br>
                6.修正没有接口时支付卡得要命<br>
                7.修正后台接口管理<br>
                8.修正驳回结算时没有记录到余额流向<br>
                9.修复若干BUG
                </p>
            </li>
             <li>
             <div class="date">
                    <span>11/16</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.9.3</h4>
                <p>
                更新内容：<br>
                1.修复已知BUG<br>
                2.新增驳回填写原因
                </p>
            </li>
            <li>
             <div class="date">
                    <span>11/03</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.9.1</h4>
                <p>
                更新内容：<br>
                1.修复了支付宝，QQ接口添加失败的兼容性<br>
                2.整改支付宝当面付回调逻辑，解决前期版本被用POST方式刷金额<br>
                3.优化了你可能知道或者不知道的问题
                </p>
            </li>
             <li>
             <div class="date">
                    <span>11/02</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.9.0</h4>
                <p>
                更新内容：<br>
                1.修复了你可能知道或者不知道的问题<br>
                2.新增了你可能知道或者不知道的功能<br>
                3.优化了你可能知道或者不知道的页面
                </p>
            </li>
            <li>
             <div class="date">
                    <span>10/16</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.8.9</h4>
                <p>
                更新内容：<br>
                1.更正QQ登陆文件，上次更新替换成测试文件<br>
                2.添加快捷登录开关【基本配置】中<br>
                3.修复部分己知BUG
                </p>
            </li>
        	<li>
             <div class="date">
                    <span>10/09</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.8.8.1</h4>
                <p>
                更新内容：<br>
                1.修复部分己知BUG
                </p>
            </li>
            <li>
             <div class="date">
                    <span>10/09</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.8.8</h4>
                <p>
                更新内容：<br>
                1.优化后台ui<br>
                2.修复部分己知BUG
                </p>
            </li>
        	 <li>
             <div class="date">
                    <span>10/05</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.8.7.4</h4>
                <p>
                更新内容：<br>
                1.修复部分己知BUG
                </p>
            </li>
             <li>
             <div class="date">
                    <span>10/05</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.8.7.3</h4>
                <p>
                更新内容：<br>
                1.修复商户首页空白
                </p>
            </li>
            <li>
             <div class="date">
                    <span>10/04</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.8.7.2</h4>
                <p>
                更新内容：<br>
                1.修复部分己知BUG
                </p>
            </li>
            <li>
             <div class="date">
                    <span>10/03</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.8.7.1</h4>
                <p>
                更新内容：<br>
                1.修复部分己知BUG
                </p>
            </li>
            <li>
             <div class="date">
                    <span>10/01</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.8.7</h4>
                <p>
                更新内容：<br>
                1.已花大量时间对回调处理结构调整(解决经常不回调，不通知问题，可能还有操作，因没接口测试，只测试了小薇扫码、微信扫码、QQ扫码、当面付扫码)其他自测，有问题反馈。<br>
                2.优化前台、后台UI<br>
                3.新增回备份功能(使用阿里云OSS对象存储)<br>
                4.在订单列表中添加了【接口ID】，在使用轮询可知是哪个接口支付。<br>
                5.深度调整后台【结算操作】，可分类型下载CSV、类型统计、可不使用转账一键操作结算状态(对手动转账结算方式有着很大帮助)。
                6.修复部分己知BUG
                </p>
            </li>
            <li>
             <div class="date">
                    <span>9/07</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.8.6</h4>
                <p>
                更新内容：<br>
                新增后台订单/收入/注册统计图<br>
                优化订单、结算分页<br>
                优化程序更新流程（不使用指令操作更新了，改用后台检查更新操作）<br>
                修复部分己知BUG
                </p>
            </li>
            <li>
             <div class="date">
                    <span>9/01</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.8.5</h4>
                <p>
                更新内容：<br>
                针对接口支付不回调、空白、appid出错等问题排查，自己测试无异常。<br>
                若是自己修改导致程序有问题的，别打扰我没空<br>
                有bog请直接留言，谢谢！<br>
                更新【使用帮助】请认真阅读<br>
                修复部分己知BUG
                </p>
            </li>

            <li>
             <div class="date">
                    <span>8/31</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.8.4</h4>
                <p>
                更新内容：<br>
                修复部分己知BUG
                </p>
            </li>
            <li>
             <div class="date">
                    <span>8/30</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.8.3</h4>
                <p>
                更新内容：<br>
                修复部分己知BUG
                </p>
            </li>
            <li>
             <div class="date">
                    <span>8/29</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.8.2</h4>
                <p>
                更新内容：<br>
                商户中心UI<br>
                新增微信扫码登录<br>
                新增商户找回密码<br>
                新增商户支付密码找回密码<br>
                优化实名认证流程<br>
                优化商户信息修改<br>
                优化商户手机，邮箱更换绑定流程<br>
                优化商户中心订单、结算、余额流向记录，采用Ajax异步查询<br>
                新增商户收入统计表图<br>
                修复身份认证失败问题<br>
                修复商户自结提交数据有误问题<br>
                新增易通商户接口（微信）<a href="https://www.1eet.cn/i/0032TN">申请</a><br>
                新增威富通接口（微信）<br>
                新增插件发布功能<br>
                对接口管理整改（添加接口在列表中选择）<br>
                修复部分己知BUG
                </p>
            </li>
            <li>
             <div class="date">
                    <span>7/22</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.724</h4>
                <p>
                更新内容：<br>
                更新使用帮助<br>
                修复部分己知BUG
                </p>
            </li>
            <li>
             <div class="date">
                    <span>7/21</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.723</h4>
                <p>
                更新内容：<br>
                新添QQ群url配置<br>
                新添商户自结审核<br>
                修复部分己知BUG
                </p>
            </li>
              <li>
             <div class="date">
                    <span>7/18</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.722</h4>
                <p>
                更新内容：<br>
                优化后台结算记录<br>
                优化程序更新功能<br>
                优化订单不可重复<br>
                修复部分己知BUG
                </p>
            </li>
                 <li>
             <div class="date">
                    <span>7/15</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.721</h4>
                <p>
                更新内容：<br>
                添加支付选择页面(若要测试请使用SDK财付通支付)<br>
                修复后台开启身份、银行认证失败<br>
                优化商户信息修改QQ不能相同防止【扫码登陆】<br>
                修复部分己知BUG
                </p>
            </li>
                <li>
             <div class="date">
                    <span>7/14</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.720</h4>
                <p>
                更新内容：<br>
                修复微信JSAPI支付无法获取OpenID<br>
                优化易支付对接易支付回调<br>
                修复部分己知BUG
                </p>
            </li>
        <li>
             <div class="date">
                    <span>7/12</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.719</h4>
                <p>
                更新内容：<br>
                修复开启单权限无法支付<br>
                添加【认证配置】 在系统管理查看，使用前先看说明<br>
                修复部分BUG
                </p>
            </li>

            <li>
             <div class="date">
                    <span>7/10</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.718</h4>
                <p>
                更新内容：<br>
                整改商户协议提示<br>
                修复商户有钱不能提现<br>
                修复部分BUG
                </p>
            </li>

            <li>
             <div class="date">
                    <span>7/10</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.717</h4>
                <p>
                更新内容：<br>
                新增短信验证码登陆<br>
                对实名认证功能完善<br>
                新增商户余额流向记录<br>
                商户中心UI整改<br>
                修复部分BUG
                </p>
            </li>

         <li>
             <div class="date">
                    <span>6/25</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.716</h4>
                <p>
                更新内容：<br>
                修复微支付回调<br>
                修复商户中心的公告管理信息查看以及查看更多<br>
                修复修复商户中心订单搜索问题<br>
                对于部分用户需要添加自动生成结算列表，监控地址api.php?act=cron<br>
                修复部分BUG
                </p>
            </li>


            <li>
             <div class="date">
                    <span>6/24</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.715</h4>
                <p>
                更新内容：<br>
                添加微支付接口<a href="http://wpaym.cn/aff/K8TUg485hLSx1IEmwuL8YHq">申请</a><br>
                添加QQ扫码登陆<br>
                修复后台管理订单查询问题<br>
                修复部分BUG
                </p>
            </li>
            
            <li>
             <div class="date">
                    <span>6/21</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.714</h4>
                <p>
                更新内容：<br>
                优化微信H5支付逻辑<br>
                优化商户注册密码验证<br>
                添加 转账接口配置 系统管理->结算配->结算接口<br>
                </p>
            </li>

        <li>
             <div class="date">
                    <span>6/20</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.713</h4>
                <p>
                更新内容：<br>
                优化支付逻辑<br>
                修复备份测试！<br>
                添加 拦截配置<br>
                修复结算csv文件下载<br>
                修复对接易支付会出现跳转不同配置通道<br>
                商户转账无反应问题
                </p>
            </li>
        
        <li>
             <div class="date">
                    <span>6/20</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.712</h4>
                <p>
                更新内容：<br>
                优化商户注册<br>
                修复部分BUG！
                </p>
            </li>


             <li>
             <div class="date">
                    <span>6/19</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.711</h4>
                <p>
                更新内容：<br>
                更新使用帮助<br>
                优化更新功能！
                </p>
            </li>


              <li>
             <div class="date">
                    <span>6/19</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.710</h4>
                <p>
                更新内容：<br>
                修复通道率费问题<br>
                修复部分BUG
                </p>
            </li>


            <li>
             <div class="date">
                    <span>6/17</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.79</h4>
                <p>
                更新内容：<br>
                修复支付宝当面付回调<br>
                修复后台管理修改密码失败<br>
                修复用户添加失败<br>
                修复结算页面空白<br>
                优化支付接口使用<br>
                添加【使用帮助】管理页<br>
                这些失败的错误都是赶时间没注意搞错了
                </p>
            </li>


          <li>
             <div class="date">
                    <span>6/16</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.78</h4>
                <p>
                更新内容：<br>
                优化结算处理<br>
                添加公告发布管理<br>
                修复大部分BUG
                </p>
            </li>


           <li>
             <div class="date">
                    <span>6/15</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.77</h4>
                <p>
                更新内容：<br>
                优化接口列表<br>
                添加独立通道率费设置<br>
                修复部分BUG
                </p>
            </li>


            <li>
             <div class="date">
                    <span>6/14</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.76</h4>
                <p>
                更新内容：<br>
                添加邮箱HTML模板<br>
                添加回后台直接进入商户操作面板功能<br>
                优化后台首页排行榜操作功能<br>
                优化后台文件防止他人直接访问文件进行修改数据<br>
                修复部分BUG
                </p>
            </li>


            <li>
             <div class="date">
                    <span>6/13</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.75</h4>
                <p>
                更新内容：<br>
                添加更新提醒->菜单页->更新提示按钮<br>
                添加后台登录通知->菜单页->登录提醒按钮<br>
                优化更新功能！
                </p>
            </li>


            <li>
               <div class="date">
                    <span>6/12</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.74</h4>
                <p>
                更新内容：<br>
                商户中心添加协议同意！<br>
                对商户数据进行更新！<br>
                对后台统计图数据更新！
                </p>
            </li>


             <li>
                <div class="date">
                    <span>6/11</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.73</h4>
                <p>
                更新内容：<br>
                对POST GET过虑！
                </p>
            </li>


            <li>
                <div class="date">
                    <span>6/10</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.72</h4>
                <p>
                更新内容：<br>
                添加更新记录功能！
                </p>
            </li>


           <li>
                <div class="date">
                    <span>6/09</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.71</h4>
                <p>
                更新内容：<br>
                优化更新，添加备份，修复部分bug
                </p>
            </li>


            <li>
                <div class="date">
                    <span>6/08</span>
                    <span class="small">时间</span>
                </div>
                <h4>更新版本：v 3.70</h4>
                <p>
                更新内容：<br>无
                </p>
            </li>
        </ul>
      </div>
    </div>
   </div>
</section>
</section>

<!-- Form Modal -->
<div class="modal fade" id="update" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                 <h4 class="modal-title" id="myModalLabel"><i class="fa fa-upload"></i> 程序升级</h4>
                  </div>
                   <div class="modal-body">
                   <h2><center><div id="version"></div></center></h2><hr/>
                   <p>更新内容： <div id="names"></div> </p>
                  </div>
                 <div class="modal-footer">
                <button type="button" onclick="Update()" class="btn btn-primary">确定更新</button>
            </div>
        </div>
    </div>
</div>
<!-- End Form Modal -->