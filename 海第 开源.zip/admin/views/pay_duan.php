<?php 
if($islogin!=1){

    if($islogin!=2){

        exit('File not found.');
    
    }

}

 ?>
      <section class="main-content-wrapper">
            <section id="main-content" class="animated fadeInUp">
            	<div class="calendar-block" style="margin-bottom: 15px;">
				    <div class="cal1">
				     <h2 style="padding: 6px 12px;"><i class="fa fa-home"></i> 首页 / 短信配置修改</h2>
				    </div>
				</div>
                <div class="row">
                  <div class="col-md-12">
                     <div class="panel panel-default">
                      <?php if(isset($_GET['edit'])){?>
                            <div class="panel-heading">
                                <h3 class="panel-title">短信模板列表</h3>
                                <div class="actions pull-right" style="width: 150px;">
                                    <a href="?duan"><button type="button" class="btn btn-info btn-xs">返回修改</button></a>
                                </div>
                                <div class="actions pull-right" style="width: 90px;">
                                    <button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#dxmb">创建模板</button>
                                </div>
                                <div class="actions pull-right">
                                    <i class="fa fa-expand"></i>
                                </div>
                            </div>
                            <div class="panel-body" style="padding: 0px;">
                              <div class="table-responsive">
                                    <table class="table table-striped" style="margin-bottom: 0px;">
                                      <thead><tr><th>排序</th><th>模板编号</th><th>模板签名</th><th>通知手机号</th><th>申请时间</th><th>状态</th><th>操作</th></tr></thead>
                                      <tbody>
                            <?php
                                $row=$DB->query("select * from pay_duan where tnum<>'' limit 1")->fetch();

                                $host = "https://ali-sms.showapi.com";
     
                                $path = "/searchTemplate";
                               
                                $method = "GET";//请求方式

                                $appcode = $conf['dx_code'];//阿里云——>云市场——>已购买的服务列表——AppCode

                                $tNum=$row['tnum'];//模板编号T170317004554

                                $headers = array();

                                array_push($headers, "Authorization:APPCODE " . $appcode);

                                $querys = "tNum=".$tNum;//查询


                                $bodys = "";
                                $url = $host . $path . "?" . $querys;

                                $curl = curl_init();
                                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
                                curl_setopt($curl, CURLOPT_URL, $url);
                                curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
                                curl_setopt($curl, CURLOPT_FAILONERROR, false);
                                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                                //curl_setopt($curl, CURLOPT_HEADER, true);
                                if (1 == strpos("$".$host, "https://"))
                                {
                                    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
                                    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
                                }
                                $data=curl_exec($curl);
                                $arr=json_decode($data,true);

                                $i=-1;

                            foreach($arr['showapi_res_body']['templates'] as $i=>$values){
                               echo "<tr>";
                               echo "<td>{$i}</td>";
                               echo "<td>{$values['tNum']}</td>";
                               echo "<td>{$values['title']}</td>";
                               echo "<td>{$values['notiPhone']}</td>";
                               echo "<td>{$values['ct']}</td>";
                               echo "<td>{$values['remark']}</td>";
                               echo "<td><a class='btn btn-xs btn-danger' onclick='mbsc(\"{$values['tNum']}\")'>删除</a></td>";
                               echo "</tr>";
                            }
                            ?>
                                      </tbody>
                                    </table>
                                  </div>
                              </div>
                      <?php }else{?>
                            <div class="panel-heading">
                                <h3 class="panel-title">短信配置修改</h3>
                                <div class="actions pull-right" style="width: 150px;">
                                    <a href="?duan&edit"><button type="button" class="btn btn-info btn-xs">模板列表</button></a>
                                </div>
                                <div class="actions pull-right" style="width: 90px;">
                                    <button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#dxmb">创建模板</button>
                                </div>
                                <div class="actions pull-right">
                                    <i class="fa fa-expand"></i>
                                </div>
                            </div>
                              <div class="panel-body">
                                <form class="form-horizontal form-border" id="form_duan" novalidate="novalidate">
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">阿里云AppCode</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" name="dx_code" value="<?php echo $conf['dx_code'];?>" required="" placeholder="阿里云—>云市场—>已购买的服务列表">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">登录模板编号</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" name="dx_mb_log" value="<?php echo $conf['dx_mb_log'];?>" required="" placeholder="T170317004555">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">注册模板编号</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" required="" name="dx_mb_reg" value="<?php echo $conf['dx_mb_reg'];?>" placeholder="T170317004555">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">提现模板编号</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" required="" name="dx_mb_tix" value="<?php echo $conf['dx_mb_tix'];?>" placeholder="T170317004555">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">找回模板编号</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" required="" name="dx_mb_zhu" value="<?php echo $conf['dx_mb_zhu'];?>" placeholder="T170317004555">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">验证码模板编号</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" required="" name="dx_mb_code" value="<?php echo $conf['dx_mb_code'];?>" placeholder="T170317004555">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="col-sm-offset-3 col-sm-6">
                                            <button type="button" onclick="duan()" class="btn btn-primary">保存</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                     <?php }?>
                    </div>
                </div>
    </section>
</section>
<!-- Form Modal -->
<div class="modal fade" id="dxmb" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel">短信模板创建</h4>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" id="form_cjmb" role="form">
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-3 control-label">短信签名</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="name" placeholder="海弟商务">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputPassword3" class="col-sm-3 control-label">通知手机号</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="phone" placeholder="可留空">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">模板内容</label>
                        <div class="col-sm-6">
                            <textarea class="form-control" name="text" rows="7" placeholder="例如：你注册的验证码是[code]，十分钟内有效。建议在30个字节内"></textarea>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" onclick="cjmb()" class="btn btn-primary">创建</button>
            </div>
        </div>
    </div>
</div>
<!-- End Form Modal -->