<?php 
if($islogin!=1){

    if($islogin!=2){

        exit('File not found.');
    
    }

}

 ?>
<section class="main-content-wrapper">
    <section id="main-content" class="animated fadeInUp">

<?php if(isset($_GET['add'])){?>


<div class="calendar-block" style="margin-bottom: 15px;">
<div class="cal1">
<h2 style="padding: 6px 12px;"><i class="fa fa-home"></i> 首页 / 接口列表</h2>
</div>
</div>

<div class="row row-sm text-center">
<div class="col-md-4 col-lg-4 col-xs-4" style="padding-right: 5px;">
    <div class="panel panel-solid-success widget-mini">
        <div class="panel-body" style="background: #edce8c;">
            <span class="total text-center"><?php echo round($count_qq,2);?></span>
            <span class="title text-center" style="font-size: 0.7em;">QQ接口数量</span>
        </div>
    </div>
</div>

<div class="col-md-4 col-lg-4 col-xs-4" style="padding-right: 5px;padding-left: 5px;">
    <div class="panel panel-solid-success widget-mini">
        <div class="panel-body" style="background: #53c455;">
            <span class="total text-center"><?php echo round($count_wx,2);?></span>
            <span class="title text-center" style="font-size: 0.7em;">微信接口数量</span>
        </div>
    </div>
</div>

<div class="col-md-4 col-lg-4 col-xs-4" style="padding-left: 5px;">
    <div class="panel panel-solid-success widget-mini">
        <div class="panel-body" style="background: #1ddbef;">
            <span class="total text-center" ><?php echo round($count_ali,2);?></span>
            <span class="title text-center" style="font-size: 0.7em;">支付宝接口数量</span>
        </div>
    </div>
</div>
</div>


<div class="row">

<div class="col-md-12">
<div class="panel panel-default">
<div class="panel-heading">
<h3 class="panel-title">接口列表</h3>
<div class="actions pull-right">
    <i class="fa fa-expand"></i>
</div>
</div>
      <div class="table-responsive">
        <table class="table table-striped">
          <thead><tr><th>排序</th><th>接口ID</th><th>接口名称</th><th>接口类型</th><th>接口标识</th><th>接口率费</th><th>接口状态</th><th>操作</th></tr></thead>
          <tbody>
            <?php
            $i=0;
            $rs=$DB->query("SELECT * FROM pay_jie WHERE 1  ORDER BY `id` ASC");
            while($res = $rs->fetch())
            {
                $i++;
                echo '<tr>
                <td><b>'.$i.'</b></td>
                <td>'.$res['id'].'</td>
                <td>'.$res['name'].'</td>
                <td>'.$res['api_name'].'</td>
                <td>'.$res['api_type'].'</td>
                <td>'.$res['api_shaui'].'</td>
                <td>'.($res['status']==1?'<input type="checkbox" ids='.$res["id"].' value='.$res["status"].' class="js-switch jkzt" checked id="check1" />':'<input type="checkbox" class="js-switch jkzt" value='.$res["status"].' ids='.$res["id"].' id="check2" />').'</td>
                <td><a href="?pei&edit&id='.$res['id'].'" class="btn btn-xs btn-info">编辑</a>&nbsp;<a class="btn btn-xs btn-danger deijk" pid='.$res['id'].'>删除</a></td>
                </tr>';
            }
            ?>
            </tbody>
            </table>
        </div>
        </div>
        </div>
    </div>
</div>

<!-- ########################################################接口修改处################################################################## -->

<?php }else if(isset($_GET['edit'])){ $rows = $DB->query("select * from pay_jie where id='{$_GET['id']}' limit 1")->fetch();?>


<div class="calendar-block" style="margin-bottom: 15px;">
<div class="cal1">
 <h2 style="padding: 6px 12px;"><i class="fa fa-home"></i> 首页 / 接口修改</h2>
</div>
</div>
<div class="row">
<div class="col-md-12">
<div class="panel panel-default">
<div class="panel-heading">
<h3 class="panel-title">接口信息修改</h3>
<div class="actions pull-right" style="width: 110px;">
    <a href="javascript:history.back(-1)"><button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#dxmb">返回上级</button></a>
</div>
    <div class="actions pull-right">
        <i class="fa fa-expand"></i>
    </div>
</div>
        <div class="panel-body">
            <form class="form-horizontal form-border" id="form_jie" novalidate="novalidate">

                <div class="form-group">
                    <label class="col-sm-3 control-label">接口ID</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" required="" value="<?php echo $rows['id'];?>" disabled>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-3 control-label">接口类型</label>
                    <div class="col-sm-6">
                    <select class="form-control" name="type1" disabled="disabled">
                        <option value="qqpay" <?=$rows['api_name']=='qqpay'?"selected":""?>>QQ</option>
                        <option value="wxpay" <?=$rows['api_name']=='wxpay'?"selected":""?>>微信</option>
                        <option value="alipay" <?=$rows['api_name']=='alipay'?"selected":""?>>支付宝</option>
                    </select>
                    </div>
                </div>


                <div class="form-group">
                    <label class="col-sm-3 control-label">接口商家</label>
                    <div class="col-sm-6">
                    <select class="form-control" name="type1" disabled="disabled">
                        <option value="qqpay" <?=$rows['api_type']=='qqpay'?"selected":""?>>QQ</option>
                        <option value="wxpay" <?=$rows['api_type']=='wxpay'?"selected":""?>>微信</option>
                        <option value="alipay" <?=$rows['api_type']=='alipay'?"selected":""?>>支付宝</option>
                        <option value="alipay" <?=$rows['api_type']=='dmpay'?"selected":""?>>支付宝当面付</option>
                        <option value="epay" <?=$rows['api_type']=='epay'?"selected":""?>>易支付</option>
                        <option value="eshangpay" <?=$rows['api_type']=='eshangpay'?"selected":""?>>微信小薇</option>
                        <option value="wftpay" <?=$rows['api_type']=='wftpay'?"selected":""?>>威富通</option>
                    </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-3 control-label">接口名称</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" required="" name="name" value="<?php echo $rows['name'];?>" placeholder="必须填写">
                    </div>
                </div>


                <?php if($rows['api_type']=='qqpay'){?>
                <div class="form-group">
                    <label class="col-sm-3 control-label">QQ钱包商户号</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" required="" name="mch_qq_id" value="<?php echo $rows['api_appid'];?>" placeholder="">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label">QQ钱包API密钥</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" required="" name="mch_qq_key" value="<?php echo $rows['api_key'];?>" placeholder="">
                    </div>
                </div>
            <?php }?>




               <?php if($rows['api_type']=='wxpay'){?>
                <div class="form-group">
                    <label class="col-sm-3 control-label">支付H5选用</label>
                    <div class="col-sm-6">
                    <select class="form-control" name="h5type">
                        <option value="0">请选择</option>
                        <option value="1" <?=$rows['donlx']=='1'?"selected":""?>>只用H5</option>
                    </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label">微信商户APPID</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" required="" name="mch_wx_id" value="<?php echo $rows['api_appid'];?>" placeholder="">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label">微信商户MCHID</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" required="" name="mch_wx_hid" value="<?php echo $rows['api_mck'];?>" placeholder="">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label">微信商户KEY</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" required="" name="mch_wx_key" value="<?php echo $rows['api_key'];?>" placeholder="">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label">微信商户APPSECRET</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" required="" name="mch_wx_sec" value="<?php echo $rows['api_callback'];?>" placeholder="">
                    </div>
                </div>
            <?php }?>



                <?php if($rows['api_type']=='alipay'){?>
                <div class="form-group">
                    <label class="col-sm-3 control-label">支付宝合作者id</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" required="" name="mch_ali_id" value="<?php echo $rows['api_appid'];?>" placeholder="">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label">支付宝收款账户</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" required="" name="mch_ali_hid" value="<?php echo $rows['api_mck'];?>" placeholder="">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label">支付宝安全效验码</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" required="" name="mch_ali_key" value="<?php echo $rows['api_key'];?>" placeholder="">
                    </div>
                </div>
            <?php }?>



            <?php if($rows['api_type']=='dmpay'){?>
                <div class="form-group">
                    <label class="col-sm-3 control-label">支付宝应用ID</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" required="" name="mch_d_id" value="<?php echo $rows['api_appid'];?>" placeholder="">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label">支付宝公钥</label>
                    <div class="col-sm-6">
                        <textarea class="form-control" name="mch_d_gy" rows="8" placeholder=""><?php echo $rows['api_mck'];?></textarea>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label">支付宝私钥</label>
                    <div class="col-sm-6">
                        <textarea class="form-control" name="mch_d_sy" rows="12" placeholder=""><?php echo $rows['api_callback'];?></textarea>
                    </div>
                </div>
            <?php }?>



             <?php if($rows['api_type']=='epay'){?>
                <div class="form-group">
                    <label class="col-sm-3 control-label">支付H5选用</label>
                    <div class="col-sm-6">
                    <select class="form-control" name="h5type">
                        <option value="0">请选择</option>
                        <option value="1" <?=$rows['donlx']=='1'?"selected":""?>>只用H5</option>
                    </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label">易支付ID</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" required="" name="mch_e_id" value="<?php echo $rows['api_appid'];?>"  placeholder="">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label">易支付KEY</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" required="" name="mch_e_key" value="<?php echo $rows['api_key'];?>" placeholder="">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label">易支付接口URL</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" required="" name="mch_e_url" value="<?php echo $rows['api_mck'];?>"  placeholder="">
                    </div>
                </div>
            <?php }?>



             <?php if($rows['api_type']=='eshangpay'){?>
                <div class="form-group">
                    <label class="col-sm-3 control-label">接口ID</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" required="" name="mch_y_id" value="<?php echo $rows['api_appid'];?>" placeholder="">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label">接口KEY</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" required="" name="mch_y_key" value="<?php echo $rows['api_key'];?>" placeholder="">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label">接口URL</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" required="" name="mch_y_url" value="<?php echo $rows['api_callback'];?>" placeholder="">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label">接口SECRET</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" required="" name="mch_y_sec" value="<?php echo $rows['api_mck'];?>" placeholder="">
                    </div>
                </div>
                
                <?php }?>

                <?php if($rows['api_type']=='wftpay'){?>
                <div class="form-group">
                    <label class="col-sm-3 control-label">威富通商户号</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" required="" name="mch_wft_id" value="<?php echo $rows['api_appid'];?>" placeholder="">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label">威富通密钥</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" required="" name="mch_wft_key" value="<?php echo $rows['api_key'];?>" placeholder="">
                    </div>
                </div>
                <?php }?>

                <div class="form-group">
                    <label class="col-sm-3 control-label">通道率费</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" required="" name="mch_shaui" value="<?php echo $rows['api_shaui'];?>" placeholder="0.03等于3%率费，若不收取则0">
                    </div>
                </div>
                <input type="hidden" name="id" value="<?php echo $rows['id'];?>">
                <input type="hidden" name="date" value="2"> 
                <input type="hidden" name="type1" value="<?php echo $rows['api_type'];?>">
                <div class="form-group">
                    <div class="col-sm-offset-3 col-sm-6">
                        <button type="button" onclick="jie()" class="btn btn-primary">保存</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
</div>


<!-- ####################################################接口添加处############################################################# -->


<?php }else{?>
<div class="calendar-block" style="margin-bottom: 15px;">
<div class="cal1">
<h2 style="padding: 6px 12px;"><i class="fa fa-home"></i> 首页 / 接口添加</h2>
</div>
</div>
<div class="row">
<div class="col-md-12">
<div class="panel panel-default">
<div class="panel-heading">
    <h3 class="panel-title">接口添加</h3>
    <div class="actions pull-right">
        <i class="fa fa-expand"></i>
    </div>
</div>
<div class="panel-body">
    <form class="form-horizontal form-border" id="form_jie" novalidate="novalidate">
    <!--QQ接口-->

     <div class="form-group">
            <label class="col-sm-3 control-label">接口类型</label>
            <div class="col-sm-6">
            <select class="form-control" name="type">
                <option value="">请选择</option>
                <option value="qqpay">QQ支付</option>
                <option value="wxpay">微信支付</option>
                <option value="alipay">支付宝支付</option>
            </select>
            </div>
        </div>

     <div class="form-group qqpay"  style="display:none;">
            <label class="col-sm-3 control-label">接口商家</label>
            <div class="col-sm-6">
            <select class="form-control" name="type1">
                <option value="">请选择</option>
                <option value="qqpay">官方QQ</option>
                <option value="epay">易支付</option>
            </select>
            </div>
        </div>

        <div class="form-group wxpay"  style="display:none;">
            <label class="col-sm-3 control-label">接口商家</label>
            <div class="col-sm-6">
            <select class="form-control" name="type1">
                <option value="">请选择</option>
                <option value="wxpay">官方微信</option>
                <option value="epay">易支付</option>
                <option value="eshangpay">易商户</option>
                <option value="wftpay">威富通</option>
            </select>
            </div>
        </div>

        <div class="form-group alipay"  style="display:none;">
            <label class="col-sm-3 control-label">接口商家</label>
            <div class="col-sm-6">
            <select class="form-control" name="type1">
                <option value="">请选择</option>
                <option value="alipay">官方支付宝</option>
                <option value="dmpay">支付宝当面付</option>
                <option value="epay">易支付</option>
            </select>
            </div>
        </div>

        <div id="h5" style="display:none;">
        <div class="form-group">
            <label class="col-sm-3 control-label">支付H5选用</label>
            <div class="col-sm-6">
            <select class="form-control" name="h5type">
                <option value="0">请选择</option>
                <option value="1">只用H5</option>
            </select>
            </div>
        </div>
       </div>

        <div class="form-group">
            <label class="col-sm-3 control-label">接口名称</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="name" placeholder="必须填写">
            </div>
        </div>


    <!-- QQ接口 -->

        <div id="qqpay1" style="display:none;">
        <div class="form-group">
            <label class="col-sm-3 control-label">QQ钱包商户号</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="mch_qq_id" placeholder="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">QQ钱包API密钥</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="mch_qq_key" placeholder="">
            </div>
        </div>
    </div>

    <!--微信接口-->
        
        <div id="wxpay1" style="display:none;">
        <div class="form-group">
            <label class="col-sm-3 control-label">微信商户APPID</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="mch_wx_id" placeholder="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">微信商户MCHID</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="mch_wx_hid"  placeholder="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">微信商户KEY</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="mch_wx_key"  placeholder="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">微信商户APPSECRET</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="mch_wx_sec"  placeholder="">
            </div>
        </div>
    </div>

    <!--支付宝接口-->
    
        <div id="alipay1" style="display:none;">
        <div class="form-group">
            <label class="col-sm-3 control-label">支付宝合作者id</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="mch_ali_id" placeholder="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">支付宝收款账户</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="mch_ali_hid" placeholder="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">支付宝安全效验码</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="mch_ali_key" placeholder="">
            </div>
        </div>
    </div>

    <!-- 易支付接口 -->
     <div id="epay1" style="display:none;">
        <div class="form-group">
            <label class="col-sm-3 control-label">易支付ID</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="mch_e_id"  placeholder="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">易支付KEY</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="mch_e_key" placeholder="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">易支付接口URL</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="mch_e_url"  placeholder="">
            </div>
        </div>
    </div>

    <!-- 易商户接口 -->
     <div id="eshangpay1" style="display:none;">
        <div class="form-group">
            <label class="col-sm-3 control-label">易商户ID</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="mch_y_id"  placeholder="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">易商户KEY</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="mch_y_key"  placeholder="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">易商户接口URL</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="mch_y_url"  placeholder="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">易商户接口SECRET</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="mch_y_sec"  placeholder="">
            </div>
        </div>
        
    </div>
<!-- 威富通接口 -->
    <div id="wftpay1" style="display:none;">
        <div class="form-group">
            <label class="col-sm-3 control-label">威富通商户号</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="mch_wft_id"  placeholder="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">威富通密钥</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="mch_wft_key"  placeholder="">
            </div>
        </div>
    </div>


    <!-- 支付宝当面付 -->
    <div id="dmpay1" style="display:none;">
        <div class="form-group">
            <label class="col-sm-3 control-label">支付宝应用ID</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="mch_d_id"  placeholder="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">支付宝公钥</label>
            <div class="col-sm-6">
                <textarea class="form-control" name="mch_d_gy" rows="8" placeholder=""></textarea>
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">支付宝私钥</label>
            <div class="col-sm-6">
                <textarea class="form-control" name="mch_d_sy" rows="12" placeholder=""></textarea>
            </div>
        </div>
    </div>

    <!-- 接口率费 -->
     <div class="form-group">
            <label class="col-sm-3 control-label">接口率费</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="mch_shaui" placeholder="0.03等于3%率费，若不收取则0">
            </div>
        </div>
         <input type="hidden" name="date" value="1"> 
        <div class="form-group">
            <div class="col-sm-offset-3 col-sm-6">
                <button type="button" onclick="jie()" class="btn btn-primary">保存</button>
            </div>
        </div>
    </form>
</div>
</div>
</div>
</div>
<?php }?>
        </section>
    </section>

