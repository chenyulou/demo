<?php 
if($islogin!=1){

    if($islogin!=2){

        exit('File not found.');
    
    }

}

 ?>
<section class="main-content-wrapper">
  <section id="main-content" class="animated fadeInUp">
    <div class="row">
      <div class="col-md-12">
        <div class="panel panel-default">
          <div class="panel-heading">商户列表
            <h3 class="panel-title"></h3>
              <div class="actions pull-right">
                  <i class="fa fa-expand"></i>
              </div>
          </div>
<div class="panel-body">
<?php

$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='add')
{

    echo '<div class="panel-body">';

    echo '<form action="" id="form_add" method="POST">

      <div class="form-group">
        <label>商户账号:</label><br>
        <input type="text" class="form-control" name="user" value="" required>
      </div>

      <div class="form-group">
        <label>商户密码:</label><br>
        <input type="text" class="form-control" name="pwd" value="" required>
      </div>

    <div class="form-group">
      <label>结算方式:</label><br><select class="form-control" name="settle_id">
        '.($conf['stype_1']?'<option value="1">支付宝</option>':null).'
        '.($conf['stype_2']?'<option value="2">微信</option>':null).'
        '.($conf['stype_3']?'<option value="3">QQ钱包</option>':null).'
        '.($conf['stype_4']?'<option value="4">银行卡</option>':null).'
      </select>
    </div>
    
    <div class="form-group">
      <label>结算账号:</label><br>
      <input type="text" class="form-control" name="account" value="" required>
    </div>

    <div class="form-group">
      <label>结算账号姓名:</label><br>
      <input type="text" class="form-control" name="username" value="" required>
    </div>

    <div class="form-group">
      <label>网站域名:</label><br>
      <input type="text" class="form-control" name="url" value="" placeholder="可留空">
    </div>

    <div class="form-group">
      <label>邮箱:</label><br>
      <input type="text" class="form-control" name="email" value="" placeholder="可留空">
    </div>

    <div class="form-group">
      <label>ＱＱ:</label><br>
      <input type="text" class="form-control" name="qq" value="" placeholder="可留空">
    </div>

    <div class="form-group">
      <label>是否结算:</label><br><select class="form-control" name="type"><option value="1">是</option><option value="2">否</option></select>
    </div>
<div class="form-group">
      <label>QQ支付权限:</label><br><select class="form-control" name="qqpay">
        <option value="1">开通</option>
        <option value="2">关闭</option>
      </select>
    </div>
<div class="form-group">
      <label>微信支付权限:</label><br><select class="form-control" name="wxpay">
        <option value="1">开通</option>
       <option value="2">关闭</option>
      </select>
    </div>
<div class="form-group">
      <label>支付宝支付权限:</label><br><select class="form-control" name="alipay">
        <option value="1">开通</option>
        <option value="2">关闭</option>
      </select>
    </div>
<div class="form-group">
      <label>微信H5权限:</label><br><select class="form-control" name="wxh5pay">
        <option value="1">开通</option>
        <option value="2">关闭</option>
      </select>
    </div>
    <div class="form-group">
      <label>QQ通道率费:</label><br>
      <input type="text" class="form-control" name="rate_qq" value="" placeholder="0.03等于3%率费，若不收取则空">
    </div>


    <div class="form-group">
      <label>微信通道率费:</label><br>
      <input type="text" class="form-control" name="rate_wx" value="" placeholder="0.03等于3%率费，若不收取则空">
    </div>

        <div class="form-group">
      <label>支付宝通道率费:</label><br>
      <input type="text" class="form-control" name="rate_ali" value="" placeholder="0.03等于3%率费，若不收取则空">
    </div>

        <div class="form-group">
      <label>微信H5通道率费:</label><br>
      <input type="text" class="form-control" name="rate_wxh5" value="" placeholder="0.03等于3%率费，若不收取则空">
    </div>
    <div class="form-group">
      <label>账号状态:</label><br><select class="form-control" name="active"><option value="1">激活</option><option value="0">封禁</option></select>
    </div>

    <input type="button" class="btn btn-primary btn-block" onclick="add_submit()" value="确定添加"></form>';


}

elseif($my=='edit')

{
      $id=$_GET['id'];

      $row=$DB->query("select * from pay_user where id='$id' limit 1")->fetch();



      echo '<div class="panel-body">';

      echo '<form action="" id="form_edit" method="POST">

      <input type="hidden" name="id" value="'.$row['id'].'">

      <div class="form-group">
        <label>商户账号:</label><br>
        <input type="text" class="form-control" name="user" value="'.$row['user'].'" required>
      </div>

      <div class="form-group">
        <label>商户密码:</label><br>
        <input type="text" class="form-control" name="pwd" value="'.$row['pwd'].'" required>
      </div>

      <div class="form-group">
        <label>结算方式:</label><br><select class="form-control" name="settle_id">
          '.($conf['stype_1']?'<option value="1" '.($row['settle_id']==1?"selected":null).'>支付宝</option>':null).'
          '.($conf['stype_2']?'<option value="2" '.($row['settle_id']==2?"selected":null).'>微信</option>':null).'
          '.($conf['stype_3']?'<option value="3" '.($row['settle_id']==3?"selected":null).'>QQ钱包</option>':null).'
          '.($conf['stype_4']?'<option value="4" '.($row['settle_id']==4?"selected":null).'>银行卡</option>':null).'
        </select>
      </div>

      <div class="form-group">
        <label>结算账号:</label><br>
        <input type="text" class="form-control" name="account" value="'.$row['account'].'" required>
      </div>

      <div class="form-group">
        <label>结算账号姓名:</label><br>
        <input type="text" class="form-control" name="username" value="'.$row['username'].'" required>
      </div>

      <div class="form-group">
        <label>商户余额:</label><br>
        <input type="text" class="form-control" name="money" value="'.$row['money'].'" required>
      </div>

      <div class="form-group">
        <label>网站域名:</label><br>
        <input type="text" class="form-control" name="url" value="'.$row['url'].'" placeholder="可留空">
      </div>

      <div class="form-group">
        <label>邮箱:</label><br>
        <input type="text" class="form-control" name="email" value="'.$row['email'].'" placeholder="可留空">
      </div>

      <div class="form-group">
        <label>ＱＱ:</label><br>
        <input type="text" class="form-control" name="qq" value="'.$row['qq'].'" placeholder="可留空">
      </div>

      <div class="form-group">
        <label>手机号:</label><br>
        <input type="text" class="form-control" name="phone" value="'.$row['phone'].'" placeholder="可留空">
      </div>';
      ?>

      <div class="form-group">
        <label>是否结算:</label><br><select class="form-control" name="type"><option value="1" <?=$row['type']==1?"selected":""?>>是</option><option value="2" <?=$row['type']==2?"selected":""?>>否</option></select>
      </div>
  
    <div class="form-group">
          <label>QQ支付权限:</label><br><select class="form-control" name="qqpay" default="'.$row['qqpay'].'">
            <option value="1" <?=$row['qqpay']==1?"selected":""?>>开通</option>
            <option value="2" <?=$row['qqpay']==2?"selected":""?>>关闭</option>
          </select>
        </div>
    <div class="form-group">
          <label>微信支付权限:</label><br><select class="form-control" name="wxpay" default="'.$row['wxpay'].'">
            <option value="1" <?=$row['wxpay']==1?"selected":""?>>开通</option>
            <option value="2" <?=$row['wxpay']==2?"selected":""?>>关闭</option>
          </select>
        </div>
    <div class="form-group">
          <label>支付宝支付权限:</label><br><select class="form-control" name="alipay" default="'.$row['alipay'].'">
            <option value="1" <?=$row['alipay']==1?"selected":""?>>开通</option>
            <option value="2" <?=$row['alipay']==2?"selected":""?>>关闭</option>
          </select>
        </div>
    <div class="form-group">
          <label>微信H5权限:</label><br><select class="form-control" name="wxh5pay" default="'.$row['wxh5pay'].'">
            <option value="1" <?=$row['wxh5pay']==1?"selected":""?>>开通</option>
            <option value="2" <?=$row['wxh5pay']==2?"selected":""?>>关闭</option>
          </select>
        </div>
            <div class="form-group">
      <label>QQ通道率费:</label><br>
      <input type="text" class="form-control" name="rate_qq" value="<?php echo $row['rate_qq'];?>" placeholder="0.03等于3%率费，若不收取则空">
    </div>


    <div class="form-group">
      <label>微信通道率费:</label><br>
      <input type="text" class="form-control" name="rate_wx" value="<?php echo $row['rate_wx'];?>" placeholder="0.03等于3%率费，若不收取则空">
    </div>

        <div class="form-group">
      <label>支付宝通道率费:</label><br>
      <input type="text" class="form-control" name="rate_ali" value="<?php echo $row['rate_ali'];?>" placeholder="0.03等于3%率费，若不收取则空">
    </div>

        <div class="form-group">
      <label>微信H5通道率费:</label><br>
      <input type="text" class="form-control" name="rate_wxh5" value="<?php echo $row['rate_wxh5'];?>" placeholder="0.03等于3%率费，若不收取则空">
    </div>

      <div class="form-group">
        <label>账号状态:</label><br><select class="form-control" name="active"><option value="1" <?=$row['active']==1?"selected":""?>>激活</option><option value="0" <?=$row['active']==0?"selected":""?>>封禁</option></select>
      </div>
<?php
     echo ' 
      <input type="button" class="btn btn-primary btn-block" onclick="edit()" value="确定修改"></form>';

      echo '
      <script>
      var items = $("select[default]");
      for (i = 0; i < items.length; i++) {
      	$(items[i]).val($(items[i]).attr("default")||0);
      }
      </script>';
}
else
{

echo '<form action="" method="GET" class="form-inline">
<input type="hidden" name="ulist" value="search">
<input type="hidden" name="my" value="search">
  <div class="form-group">
	<select name="column" class="form-control"><option value="id">商户号</option><option value="key">密钥</option><option value="account">结算账号</option><option value="username">结算姓名</option><option value="url">域名</option><option value="qq">QQ</option><option value="phone">手机号码</option><option value="email">邮箱</option></select>
  </div>
  <div class="form-group">
    <input type="text" class="form-control" name="value" placeholder="搜索内容">
  </div>
  <button type="submit" class="btn btn-primary">搜索</button>
</form></div>';

if($my=='search') {
	$sql=" `{$_GET['column']}`='{$_GET['value']}'";
	$numrows=$DB->query("SELECT * from pay_user WHERE{$sql}")->rowCount();
	$con='包含 '.$_GET['value'].' 的共有 <b>'.$numrows.'</b> 个商户';
	$link='&my=search&column='.$_GET['column'].'&value='.$_GET['value'];
}else{
	$numrows=$DB->query("SELECT * from pay_user WHERE 1")->rowCount();
	$sql=" 1";
}
echo $con;
?>
      <div class="table-responsive">
        <table class="table table-striped">
          <thead><tr><th>商户号</th><th>账号</th><th>余额</th><th>结算账号</th><th>姓名</th><th>域名</th><th>添加时间</th><th>状态</th><th>操作</th></tr></thead>
          <tbody>
<?php
if(isset($_GET['pagesize'])){
$pagesize=$_GET['pagesize'];
}else{
$pagesize=10;
}
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);

$rs=$DB->query("SELECT * FROM pay_user WHERE{$sql} order by id desc limit $offset,$pagesize");
while($res = $rs->fetch())
{
echo '<tr>
<td><b>'.$res['id'].'</b></td>
<td>'.$res['user'].'</td>
<td>'.$res['money'].'</td>
<td>'.$res['account'].' </td>
<td> '.$res['username'].'</td>
<td>'.$res['url'].' </td>
<td> '.$res['addtime'].'</td>
<td>'.($res['active']==1?'<font color=green>正常</font>':'<font color=red>封禁</font>').'</td>
<td>
<a class="btn btn-xs btn-info Users" style="background-color: #8bc34a;" onclick="userpanel(\''.$res['user'].'\',\''.$res['pwd'].'\')">面板</a>&nbsp;
<a href="?ulist&my=edit&id='.$res['id'].'" class="btn btn-xs btn-info">编辑</a>&nbsp;
<a href="#" class="btn btn-xs btn-danger" style="color: #ffffff;" onclick="die_sh('.$res['id'].')">删除</a>
</td></tr>';
}
?>
          </tbody>
        </table>
      </div>
<div id="demo7"></div>
</footer>
<script src="/assets/layui/layui.js"></script>
<script>
layui.use(['laypage', 'layer'], function(){
var laypage = layui.laypage,
layer = layui.layer; 
laypage.render(
  {
    elem: 'demo7',
    count: <?php echo $numrows?> ,
    curr: <?php echo $page?> ,
    limit:<?php echo $pagesize?>,
    layout: ['count', 'prev', 'page', 'next', 'limit', 'refresh', 'skip'],
    jump: function(obj,first){
      if(first!=true){
            var currentPage = obj.curr;
            window.location.href ="?ulist&page="+currentPage+"&pagesize="+obj.limit;
       }
   }
});
});
</script>
<?php } ?>
    </div>
  </div>
</div>
</div>
</section>
</section>