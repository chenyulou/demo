<?php 
if($islogin!=1){

    if($islogin!=2){

        exit('File not found.');
    
    }

}

?>      <section class="main-content-wrapper">
<section id="main-content" class="animated fadeInUp">
<div class="calendar-block" style="margin-bottom: 15px;">
<div class="cal1">
<h2 style="padding: 6px 12px;"><i class="fa fa-home"></i> 首页 / 结算配置修改</h2>
</div>
</div>
<div class="row">
<div class="col-md-12">


<?php if(isset($_GET['qq'])){?>

<div class="panel panel-default">
<div class="panel-heading">
    <h3 class="panel-title">QQ钱包企业付款接口配置</h3>
    <div class="actions pull-right" style="width: 150px;">
        <a href="?jieadd"><button type="button" class="btn btn-info btn-xs">返回</button></a>
    </div>
    <div class="actions pull-right" style="width: 110px;">
    <div class="btn-group">
                <button type="button" class="btn btn-info btn-xs dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    转账接口 <span class="caret"></span>
                </button>
                <ul class="dropdown-menu" role="menu" style="min-width: 10px;">
                    <li><a href="?jieadd&qq">QQ</a>
                    </li>
                    <li><a href="?jieadd&wx">微信</a>
                    </li>
                    <li><a href="?jieadd&ali">支付宝</a>
                    </li>
                </ul>
            </div>
        </div>
    <div class="actions pull-right">
        <i class="fa fa-expand"></i>
    </div>
</div>
<?php 

$rs=$DB->query("select * from pay_jie where api_type='zzqq' limit 1")->fetch();

 ?>
<div class="panel-body">
    <form class="form-horizontal form-border" id="form_jie" novalidate="novalidate">
        <?php
        if($rs){
        echo '<input type="hidden" name="id" value="'.$rs['id'].'">';
        echo '<input type="hidden" name="date" value="2">';
        }else{
        echo '<input type="hidden" name="date" value="1">';
        }
        ?>
         <input type="hidden" name="type1" value="zzqq"> 
        <div class="form-group">
            <label class="col-sm-3 control-label">QQ钱包商户号</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="mch_qq_id" value="<?php echo $rs['api_appid'];?>" required="" placeholder="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">QQ钱包商户API私密</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="mch_qq_key" value="<?php echo $rs['api_key'];?>" required="" placeholder="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">企业付款-操作员ID</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="mch_qq_hid" value="<?php echo $rs['api_mck'];?>" required="" placeholder="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">企业付款-操作员密码</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="mch_qq_pwd" value="<?php echo $rs['api_callback'];?>" required="" placeholder="">
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-offset-3 col-sm-6">
                <button type="button" onclick="jie()" class="btn btn-primary">保存</button>
            </div>
        </div>
    </form>
</div>
</div>
</div>
</div>
</section>
</section>


<?php }else if(isset($_GET['wx'])){?>

<div class="panel panel-default">
<div class="panel-heading">
    <h3 class="panel-title">微信企业付款接口配置</h3>
    <div class="actions pull-right" style="width: 150px;">
        <a href="?jieadd"><button type="button" class="btn btn-info btn-xs">返回</button></a>
    </div>
    <div class="actions pull-right" style="width: 110px;">
    <div class="btn-group">
                <button type="button" class="btn btn-info btn-xs dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    转账接口 <span class="caret"></span>
                </button>
                <ul class="dropdown-menu" role="menu" style="min-width: 10px;">
                    <li><a href="?jieadd&qq">QQ</a>
                    </li>
                    <li><a href="?jieadd&wx">微信</a>
                    </li>
                    <li><a href="?jieadd&ali">支付宝</a>
                    </li>
                </ul>
            </div>
        </div>
    <div class="actions pull-right">
        <i class="fa fa-expand"></i>
    </div>
</div>
<?php 

$rs=$DB->query("select * from pay_jie where api_type='zzwx' limit 1")->fetch();

 ?>
<div class="panel-body">
    <form class="form-horizontal form-border" id="form_jie" novalidate="novalidate">
       <?php
        if($rs){
        echo '<input type="hidden" name="id" value="'.$rs['id'].'">';
        echo '<input type="hidden" name="date" value="2">';
        }else{
        echo '<input type="hidden" name="date" value="1">';
        }
        ?>
         <input type="hidden" name="type1" value="zzwx"> 
        <div class="form-group">
            <label class="col-sm-3 control-label">微信商户APPID</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="mch_wx_id" value="<?php echo $rs['api_appid'];?>" required="" placeholder="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">微信商户MCHID</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="mch_wx_hid" value="<?php echo $rs['api_key'];?>" required="" placeholder="">
            </div>
        </div>
         <div class="form-group">
            <label class="col-sm-3 control-label">微信商户KEY</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="mch_wx_key" value="<?php echo $rs['api_mck'];?>" required="" placeholder="">
            </div>
        </div>
         <div class="form-group">
            <label class="col-sm-3 control-label">微信商户APPSECRET</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="mch_wx_sec" value="<?php echo $rs['api_callback'];?>" required="" placeholder="">
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-offset-3 col-sm-6">
                <button type="button" onclick="jie()" class="btn btn-primary">保存</button>
            </div>
        </div>
    </form>
</div>
</div>
</div>
</div>
</section>
</section>

<?php }else if(isset($_GET['ali'])){?>
<div class="panel panel-default">
<div class="panel-heading">
    <h3 class="panel-title">支付宝单转账接口配置</h3>
    <div class="actions pull-right" style="width: 150px;">
        <a href="?jieadd"><button type="button" class="btn btn-info btn-xs">返回</button></a>
    </div>
    <div class="actions pull-right" style="width: 110px;">
    <div class="btn-group">
                <button type="button" class="btn btn-info btn-xs dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    转账接口 <span class="caret"></span>
                </button>
                <ul class="dropdown-menu" role="menu" style="min-width: 10px;">
                    <li><a href="?jieadd&qq">QQ</a>
                    </li>
                    <li><a href="?jieadd&wx">微信</a>
                    </li>
                    <li><a href="?jieadd&ali">支付宝</a>
                    </li>
                </ul>
            </div>
        </div>
    <div class="actions pull-right">
        <i class="fa fa-expand"></i>
    </div>
</div>

<div class="panel-body">
    <form class="form-horizontal form-border" id="form_jies_ali" novalidate="novalidate">
        <div class="form-group">
            <label class="col-sm-3 control-label">支付宝应用ID</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="alipay_appid" value="<?php echo $conf['alipay_appid'];?>" required="" placeholder="请输入支付宝应用ID">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">支付宝私钥</label>
            <div class="col-sm-6">
                <textarea class="form-control" name="privatekey" rows="12" placeholder="请输入支付宝公钥"><?php echo $conf['privatekey'];?></textarea>
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-offset-3 col-sm-6">
                <button type="button" onclick="jiesali()" class="btn btn-primary">保存</button>
            </div>
        </div>
    </form>
</div>
</div>
</div>
</div>
</section>
</section>

<?php }else{ ?>




<div class="panel panel-default">
<div class="panel-heading">
    <h3 class="panel-title">结算配置修改</h3>
    <div class="actions pull-right" style="width: 110px;">
    <div class="btn-group">
                <button type="button" class="btn btn-info btn-xs dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    转账接口 <span class="caret"></span>
                </button>
                <ul class="dropdown-menu" role="menu" style="min-width: 10px;">
                    <li><a href="?jieadd&qq">QQ</a>
                    </li>
                    <li><a href="?jieadd&wx">微信</a>
                    </li>
                    <li><a href="?jieadd&ali">支付宝</a>
                    </li>
                </ul>
            </div>
        </div>
    <div class="actions pull-right">
        <i class="fa fa-expand"></i>
    </div>
</div>
<div class="panel-body">
    <form class="form-horizontal form-border" id="form_jies" novalidate="novalidate">
        <div class="form-group">
            <label class="col-sm-3 control-label">用户手动结算</label>
            <div class="col-sm-6">
            <select class="form-control" name="settle_open">
                <option value="1" <?=$conf['settle_open']==1?"selected":""?>>开启</option>
                <option value="2" <?=$conf['settle_open']==2?"selected":""?>>关闭</option>
            </select>
            </div>
        </div>
                <div class="form-group">
            <label class="col-sm-3 control-label">用户结算费率</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="settle_rate" value="<?php echo $conf['settle_rate'];?>" placeholder="0.03就是3%率费">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">用户申请结算次数</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="settle_every" value="<?php echo $conf['settle_every'];?>" required="" placeholder="不懂设置看使用帮助">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">结算最小金额</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="settle_money" value="<?php echo $conf['settle_money'];?>" required="" placeholder="10">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">结算最大金额</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="settle_money_max" value="<?php echo $conf['settle_money_max'];?>" required="" placeholder="1000">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">结算手续费最小</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="settle_fee_min" value="<?php echo $conf['settle_fee_min'];?>" placeholder="1">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">结算手续费最大</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="settle_fee_max" value="<?php echo $conf['settle_fee_max'];?>" placeholder="50">
            </div>
        </div>


        <div class="form-group">
            <label class="col-sm-3 control-label">QQ结算通道</label>
            <div class="col-sm-6">
            <select class="form-control" name="stype_3">
                <option value="1" <?=$conf['stype_3']==1?"selected":""?>>开启</option>
                <option value="0" <?=$conf['stype_3']==0?"selected":""?>>关闭</option>
            </select>
            </div>
        </div>

        <div class="form-group">
            <label class="col-sm-3 control-label">微信结算通道</label>
            <div class="col-sm-6">
            <select class="form-control" name="stype_2">
                <option value="1" <?=$conf['stype_2']==1?"selected":""?>>开启</option>
                <option value="0" <?=$conf['stype_2']==0?"selected":""?>>关闭</option>
            </select>
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">支付宝结算通道</label>
            <div class="col-sm-6">
            <select class="form-control" name="stype_1">
                <option value="1" <?=$conf['stype_1']==1?"selected":""?>>开启</option>
                <option value="0" <?=$conf['stype_1']==0?"selected":""?>>关闭</option>
            </select>
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">银行卡结算通道</label>
            <div class="col-sm-6">
            <select class="form-control" name="stype_4">
                <option value="1" <?=$conf['stype_4']==1?"selected":""?>>开启</option>
                <option value="0" <?=$conf['stype_4']==0?"selected":""?>>关闭</option>
            </select>
            </div>
           </div>
          <div>
         </div>
        <div class="form-group">
            <div class="col-sm-offset-3 col-sm-6">
                <button type="button" onclick="jies()" class="btn btn-primary">保存</button>
            </div>
        </div>
    </form>
</div>
</div>
</div>
</div>
</section>
</section>
<?php }?>