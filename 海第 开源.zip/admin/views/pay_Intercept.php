<?php 
if($islogin!=1){

    if($islogin!=2){

        exit('File not found.');
    
    }

}

 ?>
      <section class="main-content-wrapper">
            <section id="main-content" class="animated fadeInUp">
            	<div class="calendar-block" style="margin-bottom: 15px;">
				    <div class="cal1">
				     <h2 style="padding: 6px 12px;"><i class="fa fa-home"></i> 首页 / 拦截配置</h2>
				    </div>
				</div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title">拦截配置</h3>
                                <div class="actions pull-right">
                                    <i class="fa fa-expand"></i>
                                </div>
                            </div>
                            <div class="panel-body">
                                <form class="form-horizontal form-border" id="form_ljpz" novalidate="novalidate">
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">POST拦截</label>
                                        <div class="col-sm-6">
                                        <select class="form-control" name="postlj">
                                            <option value="0" <?=$conf['postlj']==0?"selected":""?>>关闭</option>
                                            <option value="1" <?=$conf['postlj']==1?"selected":""?>>开启</option>
                                            
                                        </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">GET拦截</label>
                                        <div class="col-sm-6">
                                        <select class="form-control" name="getlj">
                                            <option value="0" <?=$conf['getlj']==0?"selected":""?>>关闭</option>
                                            <option value="1" <?=$conf['getlj']==1?"selected":""?>>开启</option>
                                            
                                        </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">cookie拦截</label>
                                        <div class="col-sm-6">
                                        <select class="form-control" name="cookielj">
                                        <option value="0" <?=$conf['cookielj']==0?"selected":""?>>关闭</option>
                                            <option value="1" <?=$conf['cookielj']==1?"selected":""?>>开启</option>
                                            
                                        </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">支付拦截</label>
                                        <div class="col-sm-6">
                                        <select class="form-control" name="paylj">
                                             <option value="0" <?=$conf['paylj']==0?"selected":""?>>关闭</option>
                                            <option value="1" <?=$conf['paylj']==1?"selected":""?>>开启</option>
                                        </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">拦截内容</label>
                                        <div class="col-sm-6">
                                            <textarea class="form-control" name="ljname" rows="12" placeholder="测试,会员,小直播"><?php echo $conf['ljname'];?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-offset-3 col-sm-6">
                                            <button type="button" onclick="ljpz()" class="btn btn-primary">保存</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
    </section>
</section>
