<?php 
if($islogin!=1){

    if($islogin!=2){

        exit('File not found.');
    
    }

}

 ?>
      <section class="main-content-wrapper">
            <section id="main-content" class="animated fadeInUp">
            	<div class="calendar-block" style="margin-bottom: 15px;">
				    <div class="cal1">
				     <h2 style="padding: 6px 12px;"><i class="fa fa-home"></i> 首页 / 信息修改</h2>
				    </div>
				</div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title">基本信息修改</h3>
                                <div class="actions pull-right">
                                    <i class="fa fa-expand"></i>
                                </div>
                            </div>
                            <div class="panel-body">
                                <form class="form-horizontal form-border" id="form_set" novalidate="novalidate">
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">网站名称</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" name="name" value="<?php echo $conf['web_name']?>" required="" placeholder="海弟易支付">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">网站域名</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" name="url" value="<?php echo $conf['local_domain']?>" required="" placeholder="haidism.cn">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">后台目录</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" name="adminurl" value="<?php echo $conf['adminurl']?>" required="" placeholder="admin">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">客服QQ</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" required="" name="qq" value="<?php echo $conf['web_qq']?>" placeholder="1532332928">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">QQ群url:</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" required="" name="qqgroup" value="<?php echo $conf['qqgroup']?>" placeholder="https://jq.qq.com/?_wv=1027&k=58oyz5x">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">充值收费ID</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" required="" name="web_id" value="<?php echo $conf['web_id']?>" placeholder="1000">
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">商户注册</label>
                                        <div class="col-sm-6">
                                        <select class="form-control" name="is_reg">
                                            <option value="1" <?=$conf['is_reg']==1?"selected":""?>>开启</option>
                                            <option value="2" <?=$conf['is_reg']==2?"selected":""?>>关闭</option>
                                        </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">注册方式</label>
                                        <div class="col-sm-6">
                                        <select class="form-control" name="verifytype">
                                            <option value="1" <?=$conf['verifytype']==1?"selected":""?>>手机</option>
                                            <option value="2" <?=$conf['verifytype']==2?"selected":""?>>邮箱</option>
                                        </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">余额转账</label>
                                        <div class="col-sm-6">
                                        <select class="form-control" name="yuezz">
                                            <option value="1" <?=$conf['yuezz']==1?"selected":""?>>开启</option>
                                            <option value="2" <?=$conf['yuezz']==2?"selected":""?>>关闭</option>
                                        </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">老用户绑定</label>
                                        <div class="col-sm-6">
                                        <select class="form-control" name="lyhbd">
                                            <option value="1" <?=$conf['lyhbd']==1?"selected":""?>>开启</option>
                                            <option value="2" <?=$conf['lyhbd']==2?"selected":""?>>关闭</option>
                                        </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">通道收费</label>
                                        <div class="col-sm-6">
                                        <select class="form-control" name="is_pay">
                                            <option value="1" <?=$conf['is_pay']==1?"selected":""?>>是</option>
                                            <option value="2" <?=$conf['is_pay']==2?"selected":""?>>否</option>
                                        </select>
                                        </div>
                                    </div>

                                    
                                    <div id="is_payS" style="display:<?=$conf['is_pay']==1?"inherit":"none"?>">
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">QQ通道费用</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" required="" name="is_qqpay" value="<?php echo $conf['is_qqpay']?>" placeholder="1.00">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">微信通道费用</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" required="" name="is_wxpay" value="<?php echo $conf['is_wxpay']?>" placeholder="2.00">
                                        </div>
                                    </div>
                                      <div class="form-group">
                                        <label class="col-sm-3 control-label">微信H5通道费用</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" required="" name="is_wxh5" value="<?php echo $conf['is_wxh5']?>" placeholder="2.00">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">支付宝通道费用</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" required="" name="is_alipay" value="<?php echo $conf['is_alipay']?>" placeholder="3.00">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                        <label class="col-sm-3 control-label">默认通道API率费(%)</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" required="" name="money_rate" value="<?php echo $conf['money_rate']?>" placeholder="0.03等于3%率费，若不收取则0">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">快捷登录</label>
                                        <div class="col-sm-6">
                                            QQ: 
                                            <?php if($conf['qq_login']==1){?>
                                            <input  type="checkbox" value="<?php echo $conf['qq_login'];?>" qqlog="qq" class="js-switch" checked id="check1" />
                                            <?php }else{?>
                                            <input  type="checkbox" value="<?php echo $conf['qq_login'];?>" qqlog="qq" class="js-switch" id="check2" />
                                            <?php } ?>
                                            微信： 
                                            <?php if($conf['wx_login']==1){?>
                                            <input  type="checkbox" value="<?php echo $conf['qq_login'];?>" wxlog="wx" class="js-switch" checked id="check1" />
                                            <?php }else{?>
                                            <input  type="checkbox" value="<?php echo $conf['wx_login'];?>" wxlog="wx" class="js-switch" id="check2" />
                                            <?php } ?>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">程序更新码</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" name="gxm" value="<?php echo $conf['gxm']?>" required="">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">访问协议</label>
                                        <div class="col-sm-6">
                                        <select class="form-control" name="protocol">
                                            <option value="http" <?=$conf['protocol']=='http'?"selected":""?>>http</option>
                                            <option value="https" <?=$conf['protocol']=='https'?"selected":""?>>https</option>
                                        </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-offset-3 col-sm-6">
                                            <button type="button" onclick="set()" class="btn btn-primary">保存</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
    </section>
</section>
