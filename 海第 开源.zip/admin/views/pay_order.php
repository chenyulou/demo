<?php 
if($islogin!=1){

    if($islogin!=2){

        exit('File not found.');
    
    }

}

 ?>
<section class="main-content-wrapper">
<section id="main-content" class="animated fadeInUp">

<div class="row">
<div class="col-md-12">
<div class="panel panel-default">
<div class="panel-heading">订单列表
    <h3 class="panel-title"></h3>
     <div class="actions pull-right" style="width: 80px;">
           <button type="button" class="btn btn-success btn-trans btn-xs" data-toggle="modal" data-target="#formModal">清理</button>
         </div>
    <div class="actions pull-right">
        <i class="fa fa-expand"></i>
    </div>
</div>
<div class="panel-body">
<?php

$my=isset($_GET['my'])?$_GET['my']:null;

echo '<form action="" method="GET" class="form-inline"><input type="hidden" name="order" value="1"><input type="hidden" name="my" value="search">
  <div class="form-group">
	  <select name="column" class="form-control">
    <option value="trade_no">订单号</option>
    <option value="out_trade_no">商户订单号</option>
    <option value="pid">商户号</option>
    <option value="name">商品名称</option>
    <option value="money">金额</option>
    </select>
  </div>
  <div class="form-group">
    <input type="text" class="form-control" name="value" placeholder="搜索内容">
  </div>
  <button type="submit" class="btn btn-primary">搜索</button>
</form></div>';


if($my=='search') {
	if($_GET['column']=='name'){
		$sql=" `{$_GET['column']}` like '%{$_GET['value']}%'";
	}else{
		$sql=" `{$_GET['column']}`='{$_GET['value']}'";
	}
	$numrows=$DB->query("SELECT count(*) from pay_order WHERE{$sql}")->fetchColumn();
	$link='&my=search&column='.$_GET['column'].'&value='.$_GET['value'];
}else{
	$numrows=$DB->query("SELECT count(*) from pay_order WHERE 1")->fetchColumn();
	$sql=" 1";
}

?>

      <div class="table-responsive">
        <table class="table table-striped">
          <thead><tr><th>订单号/商户订单号</th><th>商户号/网站域名</th><th>商品名称/金额</th><th>支付方式/提交IP</th><th>创建时间/完成时间</th><th>接口ID</th><th>支付状态</th></tr></thead>
          <tbody>
<?php
if(isset($_GET['pagesize'])){
$pagesize=$_GET['pagesize'];
}else{
$pagesize=10;
}
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);

$rs=$DB->query("SELECT * FROM pay_order WHERE{$sql} order by trade_no desc limit $offset,$pagesize");
while($res = $rs->fetch())
{
	$url=creat_callback($res);
	$domain=!empty($res['domain'])?$res['domain']:getdomain($res['notify_url']);
echo '<tr>
<td><b><a href="'.$url['notify'].'" title="支付通知" target="_blank" rel="noreferrer">'.$res['trade_no'].'</a></b><br/>'.$res['out_trade_no'].'</td>
<td>'.$res['pid'].'<br/>'.getdomain($res['notify_url']).'<a href="//'.getdomain($res['notify_url']).'" style="color: #40a4e5;"> 访问</a> </td>
<td>'.$res['name'].'<br/>￥'.$res['money'].'</td><td>'.$res['type'].'<br/>'.$res['ip'].'</td>
<td>'.$res['addtime'].'<br/>'.$res['endtime'].'</td>
<td>'.$res['type_id'].'</td>
<td>'.($res['status']==1?'<font color=green>已完成</font>':'<font color=blue>未完成</font>').'</td></tr>';
}
?>
          </tbody>
        </table>
      </div>
<div id="demo7"></div>
</footer>
<script src="/assets/layui/layui.js"></script>
<script>
layui.use(['laypage', 'layer'], function(){
var laypage = layui.laypage,
layer = layui.layer; 
laypage.render(
  {
    elem: 'demo7',
    count: <?php echo $numrows?> ,
    curr: <?php echo $page?> ,
    limit:<?php echo $pagesize?>,
    layout: ['count', 'prev', 'page', 'next', 'limit', 'refresh', 'skip'],
    jump: function(obj,first){
      if(first!=true){
            var currentPage = obj.curr;
            window.location.href ="?order&page="+currentPage+"&pagesize="+obj.limit+"<?php echo $link;?>";
       }
   }
});
});
</script>
</div>

</section>
</section>
<div class="modal fade" id="formModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title" id="myModalLabel">未支付订单清理</h4>
                </div>
                <div class="modal-body">
                    <form class="form-horizontal" role="form">
                        <div class="form-group">
                            <label for="inputEmail3" class="col-sm-2 control-label">从(时间段)</label>
                            <div class="col-sm-10">
                                <input type="date" class="form-control" name="ks-date" placeholder="">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputPassword3" class="col-sm-2 control-label">至(时间段)</label>
                            <div class="col-sm-10">
                                <input type="date" class="form-control" name="js-date" placeholder="">
                            </div>
                        </div>
                        注意：请勿选择今天的日期，不然会导致正在操作支付的支付完不回调，商户余额不到账等等影响
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">取消</button>
                    <button type="button" class="btn btn-primary ddql" style="margin-bottom: 0;">确定</button>
                </div>
            </div>
        </div>
    </div>