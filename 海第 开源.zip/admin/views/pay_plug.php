<?php 
if($islogin!=1){

    if($islogin!=2){

        exit('File not found.');
    
    }

}
$row=$DB->query("select * from pay_plug where id='{$_GET['id']}' limit 1")->fetch();
$list=$DB->query("SELECT * FROM `pay_plug` ORDER BY `id` ASC")->fetchAll();
 ?>
<section class="main-content-wrapper">
    <section id="main-content" class="animated fadeInUp">
    	<div class="calendar-block" style="margin-bottom: 15px;">
		    <div class="cal1">
		     <h2 style="padding: 6px 12px;"><i class="fa fa-home"></i> 首页 / 插件管理</h2>
		    </div>
		</div>
		<div class="row">

<?php if($_GET['add']==1){?>

<div class="col-md-12">
<div class="panel panel-default">
<div class="panel-body">
    <form class="form-horizontal form-border" id="form_plugs" novalidate="novalidate">
    	<input type="hidden" name="id" value="<?php echo $row['id'];?>">
        <div class="form-group">
            <label class="col-sm-3 control-label">插件名称</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="name" value="<?php echo $row['name'];?>" required="" placeholder="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">插件LOGO</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="img" value="<?php echo $row['logimg'];?>" required="" placeholder="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">插件语言类型</label>
            <div class="col-sm-6">
            <select class="form-control" name="type">
                <option value="PHP" <?=$row['type']=='PHP'?"selected":""?>>PHP</option>
                <option value="Java" <?=$row['type']=='Java'?"selected":""?>>Java</option>
                <option value="C#" <?=$row['type']=='C#'?"selected":""?>>C#</option>
                <option value="Python" <?=$row['type']=='Python'?"selected":""?>>Python</option>
                <option value="其他" <?=$row['type']=='其他'?"selected":""?>>其他</option>
            </select>
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">插件作者</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="author" value="<?php echo $row['author'];?>" placeholder="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">插件介绍</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="title" value="<?php echo $row['title'];?>" placeholder="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">插件下载地址</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="download" value="<?php echo $row['download'];?>" placeholder="">
            </div>
        </div>

        <div class="form-group">
            <div class="col-sm-offset-3 col-sm-6">
                <button type="button" onclick="plugs()" class="btn btn-primary">保存</button>
                 <a href="javascript:history.back(-1)"><button type="button" class="btn btn-primary">返回</button></a>
            </div>
        </div>
    </form>
</div>
</div>
</div>

<?php }else if(isset($_GET['add'])){?>

<div class="col-md-12">
<div class="panel panel-default">
<div class="panel-body">
    <form class="form-horizontal form-border" id="form_plug" novalidate="novalidate">
        <div class="form-group">
            <label class="col-sm-3 control-label">插件名称</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="name" value="" required="" placeholder="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">插件LOGO</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="img" value="" required="" placeholder="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">插件语言类型</label>
            <div class="col-sm-6">
            <select class="form-control" name="type">
                <option value="PHP">PHP</option>
                <option value="Java">Java</option>
                <option value="C#">C#</option>
                <option value="Python">Python</option>
                <option value="其他">其他</option>
            </select>
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">插件作者</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="author" value="" placeholder="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">插件介绍</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="title" value="" placeholder="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">插件下载地址</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" required="" name="download" value="" placeholder="">
            </div>
        </div>

        <div class="form-group">
            <div class="col-sm-offset-3 col-sm-6">
                <button type="button" onclick="plug()" class="btn btn-primary">保存</button>
            </div>
        </div>
    </form>
</div>
</div>
</div>


<?php }else{?>

<?php foreach($list as $res){ ?>
<div class="col-md-6">
    <section class="panel">
        <div class="panel-body profile-wrapper">
            <div class="col-md-3">
                <div class="text-center">
                    <img src="<?php echo $res['logimg'];?>" alt="" class="img-circle" style="width: 140px;">
                </div>
            </div><hr>
                <div class="profile-info">
                    <h1><?php echo $res['name'];?></h1>
                    <span class="text-muted">发布时间：<?php echo $res['time'];?></span>
                    <p>
                        语言：<?php echo $res['type'];?> | 作者：<?php echo $res['author'];?>
                    </p>
                    <div class="connect">
                        <a href="?plug&add=1&id=<?php echo $res['id'];?>"><button type="button" class="btn btn-success btn-trans"><span class="fa fa-pencil-square-o"></span> 编辑</button></a>
                        <button type="button" onclick="plugssc(<?php echo $res['id'];?>)" class="btn btn-danger btn-trans"><span class="fa fa-times"></span>删除</button>
                    </div>
                </div>
       
        </div>
    </section>
</div>
<?php } }?>
</div>
</section>
</section>