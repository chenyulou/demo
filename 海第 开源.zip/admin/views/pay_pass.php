<?php 
if($islogin!=1){

    if($islogin!=2){

        exit('File not found.');
    
    }

}

 ?>
      <section class="main-content-wrapper">
            <section id="main-content" class="animated fadeInUp">
            	<div class="calendar-block" style="margin-bottom: 15px;">
				    <div class="cal1">
				     <h2 style="padding: 6px 12px;"><i class="fa fa-home"></i> 首页 / 管理密码修改</h2>
				    </div>
				</div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title">管理密码修改</h3>
                                <div class="actions pull-right">
                                    <i class="fa fa-expand"></i>
                                </div>
                            </div>
                            <div class="panel-body">
                                <form class="form-horizontal form-border" id="form_pass" novalidate="novalidate">
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">管理账号</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" name="user" value="<?php echo $conf['user'];?>" placeholder="账号">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">管理旧密码</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" name="jpass" placeholder="旧密码">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">管理新密码</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" name="xpass" placeholder="新密码">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-offset-3 col-sm-6">
                                            <button type="button" onclick="pass()" class="btn btn-primary">保存</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
    </section>
</section>
