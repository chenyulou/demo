<?php 
if($islogin!=1){

    if($islogin!=2){

        exit('File not found.');
    
    }

}

 ?>
<section class="main-content-wrapper">
<section id="main-content" class="animated fadeInUp">
<div class="row">
<div class="col-md-12">
<div class="panel panel-default">
<div class="panel-heading">结算审核
    <h3 class="panel-title"></h3>
    <div class="actions pull-right">
        <i class="fa fa-expand"></i>
    </div>
</div>
<div class="panel-body">
<?php

$my=isset($_GET['my'])?$_GET['my']:null;

echo '<form action="" method="GET" class="form-inline"><input type="hidden" name="my" value="search"><input type="hidden" name="operate" value="search">
  <div class="form-group">
	<select name="column" class="form-control"><option value="pid">商户号</option><option value="type">结算方式</option><option value="account">结算账号</option><option value="username">姓名</option></select>
  </div>
  <div class="form-group">
    <input type="text" class="form-control" name="value" placeholder="搜索内容">
  </div>
  <button type="submit" class="btn btn-primary">搜索</button>
</form></div>';

if($my=='search') {
	$sql=" `{$_GET['column']}`='{$_GET['value']}'";
	$numrows=$DB->query("SELECT * from pay_settle WHERE status=3 and{$sql}")->rowCount();
	$con='包含 '.$_GET['value'].' 的共有 <b>'.$numrows.'</b> 条记录';
	$link='&my=search&column='.$_GET['column'].'&value='.$_GET['value'];
}else{
	$numrows=$DB->query("SELECT * from pay_settle WHERE status=3 and 1")->rowCount();
	$sql=" 1";
}
echo $con;
?>
      <div class="table-responsive">
        <table class="table table-striped">
          <thead><tr><th>排序</th><th>商户号</th><th>结算方式</th><th>结算账号</th><th>姓名</th><th>申请金额</th><th>应结金额</th><th>手续费</th><th>申请时间</th><th>操作</th></tr></thead>
          <tbody>
<?php
if(isset($_GET['pagesize'])){
$pagesize=$_GET['pagesize'];
}else{
$pagesize=10;
}
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);
$i=0;
$rs=$DB->query("SELECT * FROM pay_settle WHERE status=3 and{$sql} order by id desc limit $offset,$pagesize");
while($res = $rs->fetch())
{
$i++;
echo '<tr>
<td><b>'.$i.'</b></td>
<td>'.$res['pid'].'</td>
<td>'.display_type($res['type']).'</td>
<td>'.$res['account'].'</td>
<td>'.$res['username'].'</td>
<td>'.$res['allmoney'].'</td>
<td>'.$res['money'].'</td>
<td>'.$res['fee'].'</td>
<td>'.$res['time'].'</td>
<td>
<a class="btn btn-xs btn-info operate" ids='.$res['id'].' jss='.$res['account'].'  style="background-color: #8bc34a;">结算</a>&nbsp;
<a href="#" ids='.$res['id'].' jss='.$res['account'].' money='.$res['allmoney'].' fee='.$res['fee'].' class="btn btn-xs btn-info bohui" style="background-color: #e25d5d;">驳回</a>

</td></tr>';
}
?>
          </tbody>
        </table>
      </div>
<div id="demo7"></div>
</footer>
<script src="/assets/layui/layui.js"></script>
<script>
layui.use(['laypage', 'layer'], function(){
var laypage = layui.laypage,
layer = layui.layer; 
laypage.render(
  {
    elem: 'demo7',
    count: <?php echo $numrows?> ,
    curr: <?php echo $page?> ,
    limit:<?php echo $pagesize?>,
    layout: ['count', 'prev', 'page', 'next', 'limit', 'refresh', 'skip'],
    jump: function(obj,first){
      if(first!=true){
            var currentPage = obj.curr;
            window.location.href ="?operate&page="+currentPage+"&pagesize="+obj.limit;
       }
   }
});
});
</script>
    </div>
  </div>
</div>
</div>
</section>
</section>
<!-- Form Modal -->
<div class="modal fade" id="bohui" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                 <h4 class="modal-title" id="myModalLabel"> 结算驳回</h4>
                  </div>
                   <div class="modal-body">
                    
                   <div id="content"></div>
                  </div>
                 <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="operates">确定操作</button>
            </div>
        </div>
    </div>
</div>
<!-- End Form Modal -->