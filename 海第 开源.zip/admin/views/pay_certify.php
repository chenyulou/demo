<?php 
if($islogin!=1){

    if($islogin!=2){

        exit('File not found.');
    
    }

}

 ?>
      <section class="main-content-wrapper">
            <section id="main-content" class="animated fadeInUp">
            	<div class="calendar-block" style="margin-bottom: 15px;">
				    <div class="cal1">
				     <h2 style="padding: 6px 12px;"><i class="fa fa-home"></i> 首页 / 认证信息修改</h2>
				    </div>
				</div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title">认证信息修改</h3>
                                <div class="actions pull-right">
                                    <i class="fa fa-expand"></i>
                                </div>
                            </div>
                            <div class="panel-body">
                                <form class="form-horizontal form-border" id="form_certify" novalidate="novalidate">
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">实名认证</label>
                                        <div class="col-sm-6">
                                        <select class="form-control" name="smrz">
                                            <option value="0" <?=$conf['smrz']==0?"selected":""?>>关闭</option>
                                            <option value="1" <?=$conf['smrz']==1?"selected":""?>>开启</option>
                                        </select>
                                        </div>
                                    </div>
                                    <div id="is_smrz" style="display:<?=$conf['smrz']==1?"inherit":"none"?>">
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">手机认证</label>
                                        <div class="col-sm-6">
                                        <select class="form-control" name="sjrz">
                                            <option value="0" <?=$conf['sjrz']==0?"selected":""?>>关闭</option>
                                            <option value="1" <?=$conf['sjrz']==1?"selected":""?>>开启</option>
                                        </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">手机认证AppCode</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" name="shourz" value="<?php echo $conf['shourz']?>" required="">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">身份认证</label>
                                        <div class="col-sm-6">
                                        <select class="form-control" name="sfrz">
                                            <option value="0" <?=$conf['sfrz']==0?"selected":""?>>关闭</option>
                                            <option value="1" <?=$conf['sfrz']==1?"selected":""?>>开启</option>
                                        </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">身份认证AppCode</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" name="sfyz_code" value="<?php echo $conf['sfyz_code']?>" required="">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">银行认证</label>
                                        <div class="col-sm-6">
                                        <select class="form-control" name="yhrz">
                                            <option value="0" <?=$conf['yhrz']==0?"selected":""?>>关闭</option>
                                            <option value="1" <?=$conf['yhrz']==1?"selected":""?>>开启</option>
                                        </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">银行认证AppCode</label>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" required="" name="yhkrz_code" value="<?php echo $conf['yhkrz_code']?>">
                                        </div>
                                    </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-offset-3 col-sm-6">
                                            <button type="button" onclick="certify()" class="btn btn-primary">保存</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
    </section>
</section>
