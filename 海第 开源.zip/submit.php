<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <title>支付中心</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <style>
	  body{
/*	    margin: auto;
	    position: absolute;
	    width: 100%;
	    height: 100%;
	    border: 0;
	    padding: 0;*/
	  }
	  iframe{
	    width: 100%;
	    height: 100%;
	    padding: 0;
	    margin: -3px;
	    border: 0;
	  }
  </style>
</head>
<body>

<?php
if($_SERVER['HTTP_USER_AGENT']=='Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1)')exit;
if(isset($_GET['pid'])){
	$queryArr=$_GET;
	$is_defend=true;
}elseif(isset($_POST['pid'])){
	$queryArr=$_POST;
}else{
	@header('Content-Type: text/html; charset=UTF-8');
	
	exit('你还未配置支付接口商户！');
}

require './includes/common.php';

@header('Content-Type: text/html; charset=UTF-8');

if(isset($_GET['default'])){

$type=daddslashes($_GET['type']);
$trade_no=daddslashes($_GET['trade_no']);
$userrow=$DB->query("SELECT * FROM pay_user WHERE id='{$_GET['pid']}' limit 1")->fetch();
if(!$userrow)sysmsg('PID不存在！');
}else{	

$prestr=createLinkstring(argSort(paraFilter($queryArr)));
$pid=intval($queryArr['pid']);
if(empty($pid))sysmsg('PID不存在');
$userrow=$DB->query("SELECT * FROM pay_user WHERE id='{$pid}' limit 1")->fetch();
$wxh5pay=$userrow['wxh5pay'];
if(!md5Verify($prestr, $queryArr['sign'], $userrow['key']))sysmsg('签名校验失败，请返回重试！');

if($conf['paylj']==1){
$arr=explode(",",$conf['ljname']);
		$content = htmlspecialchars($queryArr['name']); 
		foreach ($arr as $v) { 
		    if (false !== strstr($content, $v))sysmsg('本次支付己被终止(检测到商品带有敏感词)');

   }
}




$uid=daddslashes($queryArr['uid']);
$type=daddslashes($queryArr['type']);
$out_trade_no=daddslashes($queryArr['out_trade_no']);
$notify_url=strip_tags(daddslashes($queryArr['notify_url']));
$return_url=strip_tags(daddslashes($queryArr['return_url']));
$name=strip_tags(daddslashes($queryArr['name']));
$money=daddslashes($queryArr['money']);
$sitename=urlencode(base64_encode(daddslashes($queryArr['sitename'])));

if(empty($uid)){$uid==0;}
if(empty($out_trade_no))sysmsg('订单号(out_trade_no)不能为空');
if(empty($notify_url))sysmsg('通知地址(notify_url)不能为空');
if(empty($return_url))sysmsg('回调地址(return_url)不能为空');
if(empty($name))sysmsg('商品名称(name)不能为空');
if(empty($money))sysmsg('金额(money)不能为空');
if($money<=0 || !is_numeric($money) || !preg_match('/^[0-9.]+$/', $money))sysmsg('金额不合法');
if($money>1000)sysmsg('超出最大限额');
if(!preg_match('/^[a-zA-Z0-9.\_\-|]+$/',$out_trade_no))sysmsg('订单号(out_trade_no)格式不正确');

$trade_no=date("YmdHis").rand(11111,99999);
$domain=getdomain($notify_url);

$row=$DB->query("SELECT * FROM pay_order WHERE trade_no='{$trade_no}' limit 1")->fetch();
if($row)sysmsg('订单号不可重复，请返回来源地重新发起请求！');

}
if($userrow['active']==0)sysmsg('商户已封禁，无法支付！');
if($type=='qqpay' && $userrow['qqpay']!=1)sysmsg('该商户尚未购买QQ支付权限，暂时无法支付！');
if($type=='wxpay' && $userrow['wxpay']!=1)sysmsg('该商户尚未购买微信支付权限，暂时无法支付！');
if($type=='alipay' && $userrow['alipay']!=1)sysmsg('该商户尚未购买支付宝支付权限，暂时无法支付！');



if(isset($_GET['default'])){

$DB->exec("update `pay_order` set `type` ='{$type}' where `trade_no`='$trade_no'");

}else{

if(!$DB->query("insert into `pay_order` (`trade_no`,`out_trade_no`,`notify_url`,`return_url`,`type`,`uid`,`pid`,`addtime`,`name`,`money`,`domain`,`ip`,`status`) values ('".$trade_no."','".$out_trade_no."','".$notify_url."','".$return_url."','".$type."','".$uid."','".$pid."','".$date."','".$name."','".$money."','".$domain."','".$clientip."','0')"))exit('创建订单失败，请返回重试！');

}
if($type=='alipay'){

require './content/alipay.php';

}elseif($type=='wxpay'){

require './content/wxpay.php';

}else if($type=='qqpay'){

require './content/qqpay.php';

}else{
	
require './content/default.php';

}

?>
</body>
</html>