-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- 主机： localhost
-- 生成日期： 2019-11-02 16:52:37
-- 服务器版本： 5.7.26-log
-- PHP 版本： 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `pay`
--

-- --------------------------------------------------------

--
-- 表的结构 `pay_accoun`
--

CREATE TABLE `pay_accoun` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL COMMENT '转账商户',
  `pid` int(11) NOT NULL COMMENT '收款商户',
  `money` decimal(10,2) NOT NULL COMMENT '转/收金额',
  `note` varchar(500) NOT NULL COMMENT '备注',
  `status` int(11) NOT NULL COMMENT '状态',
  `time` datetime NOT NULL COMMENT '时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pay_admin`
--

CREATE TABLE `pay_admin` (
  `id` int(11) NOT NULL,
  `user` varchar(20) NOT NULL COMMENT '管理账号',
  `pwd` varchar(30) NOT NULL COMMENT '管理密码',
  `local_domain` varchar(30) DEFAULT NULL COMMENT '平台域名',
  `web_name` varchar(20) DEFAULT NULL COMMENT '网站名称',
  `web_qq` varchar(10) DEFAULT NULL COMMENT '站长QQ',
  `qqgroup` varchar(100) DEFAULT NULL COMMENT 'QQ加群URL',
  `web_id` varchar(10) DEFAULT NULL COMMENT '充值收费ID',
  `web_log` int(11) DEFAULT NULL COMMENT '商户登陆方式',
  `wxtransfer_desc` varchar(50) DEFAULT NULL COMMENT '微信企业付款说明',
  `payer_show_name` varchar(50) DEFAULT NULL COMMENT '支付宝付款方显示姓名',
  `alipay_appid` varchar(32) DEFAULT NULL COMMENT '支付宝转账应用APPID',
  `privatekey` varchar(2500) DEFAULT NULL COMMENT '支付宝转账公钥',
  `money_rate` varchar(10) DEFAULT NULL COMMENT '默认支付分成比例',
  `settle_money` varchar(10) DEFAULT NULL COMMENT '提现最小金额',
  `settle_money_max` varchar(10) DEFAULT NULL COMMENT '提现最大金额',
  `settle_every` varchar(10) DEFAULT NULL COMMENT '每次可结',
  `settle_rate` varchar(10) DEFAULT NULL COMMENT '结算费率',
  `settle_fee_min` varchar(10) DEFAULT NULL COMMENT '结算手续费最小',
  `settle_fee_max` varchar(10) DEFAULT NULL COMMENT '结算手续费最大',
  `is_reg` int(11) DEFAULT NULL COMMENT '是否开启商户注册',
  `is_pay` int(11) DEFAULT NULL COMMENT '通道收费',
  `is_qqpay` decimal(10,2) DEFAULT NULL COMMENT 'QQ通道费用',
  `is_wxpay` decimal(10,2) DEFAULT NULL COMMENT '微信通道费用',
  `is_wxh5` decimal(10,2) DEFAULT NULL COMMENT '微信H5权限费用',
  `is_alipay` decimal(10,2) DEFAULT NULL COMMENT '支付宝通道费用',
  `settle_open` int(11) DEFAULT NULL COMMENT '是否开启商户自结',
  `verifytype` int(11) DEFAULT NULL COMMENT '验证码获取方式',
  `stype_1` int(11) DEFAULT NULL COMMENT '是否开启支付宝结算',
  `stype_2` int(11) DEFAULT NULL COMMENT '是否开启微信结算',
  `stype_3` int(11) DEFAULT NULL COMMENT '是否开启QQ钱包结算',
  `stype_4` int(11) DEFAULT NULL COMMENT '是否开启银行卡结算',
  `mail_smtp` varchar(30) DEFAULT NULL COMMENT 'SMTP地址',
  `mail_port` int(11) DEFAULT NULL COMMENT 'SMTP端口',
  `mail_name` varchar(30) DEFAULT NULL COMMENT '邮箱账号',
  `mail_pwd` varchar(50) DEFAULT NULL COMMENT '邮箱密码（授权码）',
  `fie_qq` decimal(10,2) DEFAULT NULL COMMENT 'QQ权限费用',
  `fie_wx` decimal(10,2) DEFAULT NULL COMMENT '微信权限费用',
  `fie_ali` decimal(10,2) DEFAULT NULL COMMENT '支付宝权限费用',
  `dx_code` varchar(32) DEFAULT NULL COMMENT '阿里云AppCode',
  `dx_mb_log` varchar(15) DEFAULT NULL COMMENT '登录模板编号',
  `dx_mb_reg` varchar(15) DEFAULT NULL COMMENT '注册模板编号',
  `dx_mb_tix` varchar(15) DEFAULT NULL COMMENT '提现模板编号',
  `dx_mb_zhu` varchar(15) DEFAULT NULL COMMENT '找回模板编号',
  `dx_mb_code` varchar(15) DEFAULT NULL COMMENT '验证码模板编号',
  `bak_type` int(11) DEFAULT NULL COMMENT '备份功能',
  `bak_type2` varchar(30) DEFAULT NULL COMMENT '阿里云OSS存储目录',
  `bak_date` varchar(30) DEFAULT NULL COMMENT '备份相隔时间',
  `bak_url` varchar(30) DEFAULT NULL COMMENT '阿里云OSSKeyId',
  `bak_user` varchar(30) DEFAULT NULL COMMENT '阿里云OSSKeySecret',
  `bak_pwd` varchar(50) DEFAULT NULL COMMENT '阿里云OSS访问域名',
  `CAPTCHA_ID` varchar(150) DEFAULT NULL COMMENT '极限验证码id',
  `PRIVATE_KEY` varchar(150) DEFAULT NULL COMMENT '极限验证码key',
  `Login` int(11) DEFAULT NULL COMMENT '登录提醒',
  `gxdate` int(11) DEFAULT NULL COMMENT '更新提醒',
  `gxm` varchar(50) DEFAULT NULL COMMENT '更新码',
  `postlj` int(11) DEFAULT NULL COMMENT 'POST拦截',
  `getlj` int(11) DEFAULT NULL COMMENT 'GET拦截',
  `cookielj` int(11) DEFAULT NULL COMMENT 'cookie拦截',
  `paylj` int(11) DEFAULT NULL COMMENT '支付拦截',
  `ljname` varchar(1000) DEFAULT NULL COMMENT '拦截内容',
  `smrz` int(11) DEFAULT NULL COMMENT '实名认证',
  `shourz` varchar(64) DEFAULT NULL COMMENT '手机认证AppCode',
  `sfyz_code` varchar(64) DEFAULT NULL COMMENT '身份认证AppCode	',
  `yhkrz_code` varchar(64) DEFAULT NULL COMMENT '银行认证AppCode',
  `sjrz` int(11) DEFAULT NULL COMMENT '手机认证',
  `sfrz` int(11) DEFAULT NULL COMMENT '身份认证',
  `yhrz` int(11) DEFAULT NULL COMMENT '银行认证',
  `adminurl` varchar(30) DEFAULT NULL COMMENT '后台目录',
  `qq_login` int(11) DEFAULT NULL COMMENT 'QQ登录',
  `wx_login` int(11) DEFAULT NULL COMMENT '微信登陆',
  `yuezz` int(11) DEFAULT NULL COMMENT '余额转账',
  `lyhbd` int(11) DEFAULT NULL COMMENT '老用户绑定'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `pay_admin`
--

INSERT INTO `pay_admin` (`id`, `user`, `pwd`, `local_domain`, `web_name`, `web_qq`, `qqgroup`, `web_id`, `web_log`, `wxtransfer_desc`, `payer_show_name`, `alipay_appid`, `privatekey`, `money_rate`, `settle_money`, `settle_money_max`, `settle_every`, `settle_rate`, `settle_fee_min`, `settle_fee_max`, `is_reg`, `is_pay`, `is_qqpay`, `is_wxpay`, `is_wxh5`, `is_alipay`, `settle_open`, `verifytype`, `stype_1`, `stype_2`, `stype_3`, `stype_4`, `mail_smtp`, `mail_port`, `mail_name`, `mail_pwd`, `fie_qq`, `fie_wx`, `fie_ali`, `dx_code`, `dx_mb_log`, `dx_mb_reg`, `dx_mb_tix`, `dx_mb_zhu`, `dx_mb_code`, `bak_type`, `bak_type2`, `bak_date`, `bak_url`, `bak_user`, `bak_pwd`, `CAPTCHA_ID`, `PRIVATE_KEY`, `Login`, `gxdate`, `gxm`, `postlj`, `getlj`, `cookielj`, `paylj`, `ljname`, `smrz`, `shourz`, `sfyz_code`, `yhkrz_code`, `sjrz`, `sfrz`, `yhrz`, `adminurl`, `qq_login`, `wx_login`, `yuezz`, `lyhbd`) VALUES
(1, 'admin', '12345', 'pay.haidism.cn', '海弟易支付', '1532332928', 'https://jq.qq.com/?_wv=1027&amp;k=54EMuzn', '1000', 1, '海弟易支付结算', '海弟商务', '1', NULL, '98', '1', '10', '3', '0.03', '0.1', '10', 1, 2, '1.00', '2.00', '3.00', '3.00', 1, 1, 1, 1, 1, 1, 'smtp.mxhichina.com', 465, 'admin@tmd.red', '123456', '1.00', '2.00', '3.00', '', '', '', '', '', '', 0, '0', '10', '', '', '', 'b31335edde91b2f98dacd393f6ae6de8', '170d2349acef92b7396c7157eb9d8f47', 0, 1, '', 1, 1, 1, 1, '', 0, '', '', '', 0, 0, 0, 'admin', 0, 0, 0, 2);

-- --------------------------------------------------------

--
-- 表的结构 `pay_bak`
--

CREATE TABLE `pay_bak` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `time` datetime NOT NULL,
  `active` varchar(30) NOT NULL,
  `wan` varchar(50) NOT NULL DEFAULT '未上传'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pay_batch`
--

CREATE TABLE `pay_batch` (
  `batch` varchar(20) NOT NULL,
  `allmoney` decimal(10,2) NOT NULL,
  `time` datetime DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pay_duan`
--

CREATE TABLE `pay_duan` (
  `id` int(11) NOT NULL,
  `name` varchar(20) DEFAULT NULL COMMENT '短信签名',
  `tnum` varchar(20) DEFAULT NULL COMMENT '模板编号',
  `phone` varchar(11) DEFAULT NULL COMMENT '通知手机号',
  `text` varchar(100) DEFAULT NULL COMMENT '模板内容',
  `time` datetime DEFAULT NULL COMMENT '创建时间',
  `active` int(11) DEFAULT NULL COMMENT '审核状态'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pay_email`
--

CREATE TABLE `pay_email` (
  `id` int(11) NOT NULL,
  `uid` varchar(30) DEFAULT NULL COMMENT '对象Email',
  `name` varchar(500) DEFAULT NULL COMMENT '发送内容',
  `time` datetime DEFAULT NULL COMMENT '发送时间',
  `ems` int(11) NOT NULL COMMENT '发送对象',
  `min` varchar(50) DEFAULT NULL COMMENT '发送标题'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pay_jie`
--

CREATE TABLE `pay_jie` (
  `id` int(11) NOT NULL,
  `api_name` varchar(10) DEFAULT NULL COMMENT '接口名称',
  `api_type` varchar(11) DEFAULT NULL COMMENT '接口类型',
  `api_appid` varchar(50) DEFAULT NULL COMMENT '接口ID',
  `api_key` varchar(50) DEFAULT NULL COMMENT '接口密钥',
  `api_mck` varchar(2000) DEFAULT NULL COMMENT '通用字段',
  `api_callback` varchar(2000) DEFAULT NULL COMMENT '通用字段',
  `status` int(11) DEFAULT '0' COMMENT '接口状态',
  `api_shaui` varchar(20) DEFAULT NULL COMMENT '通道率费',
  `donlx` int(11) DEFAULT NULL COMMENT '微信通道H5'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pay_log`
--

CREATE TABLE `pay_log` (
  `id` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `date` datetime NOT NULL,
  `city` varchar(20) DEFAULT NULL,
  `data` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pay_money`
--

CREATE TABLE `pay_money` (
  `id` int(11) NOT NULL,
  `uid` varchar(20) NOT NULL COMMENT '商户ID',
  `name` varchar(20) NOT NULL COMMENT '流向类型',
  `money` varchar(10) NOT NULL COMMENT '流向余额',
  `addmoney` varchar(10) NOT NULL COMMENT '流向后余额',
  `time` datetime NOT NULL COMMENT '流向时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pay_notice`
--

CREATE TABLE `pay_notice` (
  `id` int(11) NOT NULL,
  `title` varchar(30) NOT NULL COMMENT '标题',
  `type` varchar(20) NOT NULL COMMENT '类型',
  `name` varchar(500) NOT NULL COMMENT '内容',
  `time` timestamp NOT NULL COMMENT '时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pay_order`
--

CREATE TABLE `pay_order` (
  `trade_no` varchar(64) NOT NULL,
  `out_trade_no` varchar(64) NOT NULL,
  `notify_url` varchar(64) DEFAULT NULL,
  `return_url` varchar(64) DEFAULT NULL,
  `type` varchar(20) NOT NULL,
  `buyer` varchar(30) DEFAULT NULL,
  `uid` varchar(20) DEFAULT '0',
  `pid` int(11) NOT NULL,
  `addtime` datetime DEFAULT NULL,
  `endtime` datetime DEFAULT NULL,
  `name` varchar(64) NOT NULL,
  `money` varchar(32) NOT NULL,
  `domain` varchar(32) DEFAULT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `type_id` varchar(20) DEFAULT NULL COMMENT '接口id'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pay_plug`
--

CREATE TABLE `pay_plug` (
  `id` int(11) NOT NULL,
  `type` varchar(20) DEFAULT NULL COMMENT '类型',
  `name` varchar(20) DEFAULT NULL COMMENT '名称',
  `logimg` varchar(200) DEFAULT NULL COMMENT 'logo照片',
  `title` varchar(300) DEFAULT NULL COMMENT '介绍内容',
  `author` varchar(5) DEFAULT NULL COMMENT '插件作者',
  `download` varchar(400) DEFAULT NULL COMMENT '下载地址',
  `time` datetime DEFAULT NULL COMMENT '发布时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pay_regcode`
--

CREATE TABLE `pay_regcode` (
  `id` int(11) NOT NULL,
  `type` int(1) NOT NULL DEFAULT '0',
  `code` varchar(32) NOT NULL,
  `email` varchar(32) DEFAULT NULL,
  `time` int(11) NOT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `trade_no` varchar(32) DEFAULT NULL,
  `data` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pay_settle`
--

CREATE TABLE `pay_settle` (
  `id` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `batch` varchar(20) NOT NULL,
  `type` int(1) NOT NULL DEFAULT '1',
  `username` varchar(10) NOT NULL,
  `account` varchar(32) NOT NULL,
  `money` decimal(10,2) NOT NULL,
  `allmoney` decimal(10,2) NOT NULL,
  `fee` decimal(10,2) NOT NULL,
  `time` datetime DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `transfer_status` int(1) NOT NULL DEFAULT '0',
  `transfer_result` varchar(64) DEFAULT NULL,
  `transfer_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pay_user`
--

CREATE TABLE `pay_user` (
  `id` int(11) NOT NULL,
  `user` varchar(30) NOT NULL COMMENT '账号',
  `pwd` varchar(30) NOT NULL COMMENT '密码',
  `key` varchar(32) NOT NULL COMMENT '私密',
  `account` varchar(32) DEFAULT NULL COMMENT '结算号',
  `accounts` varchar(10) DEFAULT NULL COMMENT '行业类型',
  `username` varchar(32) DEFAULT NULL COMMENT '姓名',
  `alipay_appid` varchar(30) DEFAULT NULL,
  `alipay_uid` varchar(32) DEFAULT NULL,
  `qq_uid` varchar(32) DEFAULT NULL,
  `qq_name` varchar(50) DEFAULT NULL COMMENT 'QQ名称',
  `money` decimal(10,2) NOT NULL COMMENT '余额',
  `settle_id` int(1) NOT NULL DEFAULT '1' COMMENT '结算方式',
  `email` varchar(32) DEFAULT NULL COMMENT '邮箱号',
  `phone` varchar(20) DEFAULT NULL COMMENT '手机号',
  `qq` varchar(20) DEFAULT NULL COMMENT 'QQ',
  `wxid` varchar(32) DEFAULT NULL COMMENT '微信openid',
  `wx_name` varchar(50) DEFAULT NULL COMMENT '微信名称',
  `url` varchar(64) DEFAULT NULL COMMENT '域名',
  `addtime` datetime DEFAULT NULL COMMENT '注册时间',
  `apply` int(1) NOT NULL DEFAULT '0',
  `level` int(1) NOT NULL DEFAULT '1',
  `type` int(1) NOT NULL DEFAULT '0',
  `active` int(1) NOT NULL DEFAULT '0',
  `rate_qq` varchar(8) DEFAULT NULL COMMENT 'QQ通道率费',
  `rate_wx` varchar(8) DEFAULT NULL COMMENT '微信通道率费',
  `rate_ali` varchar(8) DEFAULT NULL COMMENT '支付宝通道率费',
  `rate_wxh5` varchar(8) DEFAULT NULL COMMENT '微信H5通道率费',
  `qqpay` int(11) DEFAULT '0' COMMENT 'QQ权限状态',
  `wxpay` int(11) DEFAULT '0' COMMENT '微信权限状态',
  `alipay` int(11) DEFAULT '0' COMMENT '支付宝权限状态',
  `wxh5pay` int(11) DEFAULT NULL COMMENT '微信H5权限',
  `zfmm` int(11) DEFAULT '123456' COMMENT '支付密码',
  `sfzhm` varchar(18) DEFAULT NULL COMMENT '身份证号码',
  `xieyi` int(11) DEFAULT NULL COMMENT '协议同意',
  `sj_rz` int(11) DEFAULT NULL COMMENT '手机认证',
  `sf_rz` int(11) DEFAULT NULL COMMENT '身份认证',
  `yh_rz` int(11) DEFAULT NULL COMMENT '银行认证',
  `Bank` varchar(18) DEFAULT NULL COMMENT '银行卡号'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转储表的索引
--

--
-- 表的索引 `pay_accoun`
--
ALTER TABLE `pay_accoun`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `pay_admin`
--
ALTER TABLE `pay_admin`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `pay_bak`
--
ALTER TABLE `pay_bak`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `pay_batch`
--
ALTER TABLE `pay_batch`
  ADD PRIMARY KEY (`batch`);

--
-- 表的索引 `pay_duan`
--
ALTER TABLE `pay_duan`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `pay_email`
--
ALTER TABLE `pay_email`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `pay_jie`
--
ALTER TABLE `pay_jie`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `pay_log`
--
ALTER TABLE `pay_log`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `pay_money`
--
ALTER TABLE `pay_money`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `pay_notice`
--
ALTER TABLE `pay_notice`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `pay_order`
--
ALTER TABLE `pay_order`
  ADD PRIMARY KEY (`trade_no`),
  ADD KEY `pid` (`pid`),
  ADD KEY `out_trade_no` (`pid`,`out_trade_no`);

--
-- 表的索引 `pay_plug`
--
ALTER TABLE `pay_plug`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `pay_regcode`
--
ALTER TABLE `pay_regcode`
  ADD PRIMARY KEY (`id`),
  ADD KEY `code` (`code`);

--
-- 表的索引 `pay_settle`
--
ALTER TABLE `pay_settle`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pid` (`pid`);

--
-- 表的索引 `pay_user`
--
ALTER TABLE `pay_user`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `pay_accoun`
--
ALTER TABLE `pay_accoun`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `pay_admin`
--
ALTER TABLE `pay_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 使用表AUTO_INCREMENT `pay_bak`
--
ALTER TABLE `pay_bak`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `pay_duan`
--
ALTER TABLE `pay_duan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `pay_email`
--
ALTER TABLE `pay_email`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `pay_jie`
--
ALTER TABLE `pay_jie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `pay_log`
--
ALTER TABLE `pay_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `pay_money`
--
ALTER TABLE `pay_money`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `pay_notice`
--
ALTER TABLE `pay_notice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `pay_plug`
--
ALTER TABLE `pay_plug`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `pay_regcode`
--
ALTER TABLE `pay_regcode`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `pay_settle`
--
ALTER TABLE `pay_settle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `pay_user`
--
ALTER TABLE `pay_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10000;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
